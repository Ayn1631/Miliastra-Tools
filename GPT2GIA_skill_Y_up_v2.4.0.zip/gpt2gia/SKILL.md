---
name: gpt2gia
description: 先按完整十四章模板生成建模 Prompt 并等待用户确认，再从文字描述、单张参考图或多视图实际构建由标准基元拼合而成的低模三维元件档案，支持长方体、球体、平面、三/五棱柱、三/五棱锥、圆柱、圆锥、线框长方体与线框圆柱，并执行图片多视角融合、遮挡关系推断、真实比例恢复、通用/机械设备拆解、场景坐标、前中远景、重复物件、文字/贴图参考和基元优先级规划，生成组件数据、装配意图、网页预览、真实截图、验证报告和工程 ZIP。用于 GPT2GIA、基元拼合建模、Blockbench/YSM 参考建模，以及角色、生物、载具、机械设备、建筑、家具、道具或场景的结构化建模；不得用二维生成图片替代三维元件档案。
---

# GPT2GIA

先交付可审阅的完整建模 Prompt，等待用户明确确认，再把目标建成可复用的多基元三维元件档案。

## 首次调用的停止点

**没有针对当前 Prompt 的真实用户确认时，本轮只生成、保存、展示 Prompt 与技术契约，然后停止。不得初始化模型、创建组件、生成预览或打包模型。**

这属于第 0 阶段的正确交付，不受后文“不得只交提示词”的最终成果限制。模板中“实际完成”“开始建模”等文字描述的是确认后的目标，不能触发当前轮越过确认阶段。收到用户修改意见时，修订 Prompt 并重新提交审核；不得把“帮我建模”的初始任务请求当作对尚未展示的 Prompt 的确认。

用户只要求维护本 Skill、替换模板或编写提示词时，仅完成所请求的文件工作，不启动三维建模。

## 不可变边界

- 权威交付物是 `components.json` 与 `assembly.json`，不是 `.gia`；不要实现或伪造 GIA 编码、模板标定或回读。
- 仅使用目录中登记的 11 种标准基元。默认自适应选择基元；只有用户明确要求时才限制为纯长方体、体素或指定子集。“压缩基元数量”不等于“只使用长方体”。
- 统一右手 Y-up：X 左右、Y 高度、Z 进深，地面在 XZ 平面；禁止继承旧 Z-up 模板、固定四位小数或 0.01 量化规则。
- `references/template.prompt.md` 是用户提供的《异世界浮空魔法学院外景》完整参考模板，保持原文。生成新任务 Prompt 时继承十四章架构与细节层级，按当前任务改写主体和内容，不擅自把学院、魔法、外景限定套到其他对象上。
- 当前任务的明确约束决定基元集合、主题与预算；Prompt 和 `prompt_contract.json` 必须一致，得到用户确认后共同成为执行依据。未经重新确认不得改动已确认约束。
- 所有基元的 `position` 都表示该基元自身的几何中心。平移、旋转和缩放均围绕几何中心执行；不得按角点、底面中心或包围盒最小点补偿位置。
- `scale` 是三个局部轴上的完整尺寸/尺度，不是半尺寸；保持连续浮点数，不默认量化。对于线框，它调整框架路径大小，不调整线条截面：**线厚不随缩放改变**，实际线厚数值未知时不得猜测。
- 完整细圆环优先评估 1 个压扁的 `10009011`；完整同色细矩形框优先评估 1 个压扁的 `10009010`，不要默认长方体分段拼合。先满足轮廓、固有线厚、颜色与功能；需要粗实体、缺边或不同边厚时才采用适合的替代方案并说明。
- 压扁使用有限正尺度，不能写零尺度。线框始终是空心轮廓，不能充当实心面、厚环带或可调截面的构件。内置固定像素线宽仅是未标定示意，不等于游戏的实际固定线厚。
- 多图输入必须先建立跨视图语义对应、轮廓约束和冲突处理，不能逐图独立猜测后平均。
- 没有可靠标尺、规格或相机标定时，只能恢复相对比例并标记 `relative_only`；不得伪称真实米制尺寸。
- 默认遵守低模约束：轮廓与大平面优先、平涂色块、显式组件/颜色/LOD 预算、禁止像素噪点与无理由细分。
- 参考图片只能用于观察几何、比例、颜色与构图。禁止调用图像生成工具制作或替代最终模型、预览图或检查图。
- 截图必须由本次三维档案的内置预览代码真实渲染。优先捕获网页预览；没有浏览器可执行文件时，可用同一 `viewer.js` 的无界面 Canvas 后端。两者都必须在日志中记录后端。无法运行任一真实渲染后端时，明确返回阻塞状态，不得降级为画图。

开始前必须完整读取 [template.prompt.md](references/template.prompt.md)、[template-usage.md](references/template-usage.md)、[prompt-workflow.md](references/prompt-workflow.md)，再阅读 [primitive-contract.md](references/primitive-contract.md) 、[primitive-recipes.md](references/primitive-recipes.md)、[primitive-recipes.prompt.md](references/primitive-recipes.prompt.md) 与 [low-poly-style.md](references/low-poly-style.md)。有任何图片参考时读取 [reference-reconstruction.md](references/reference-reconstruction.md)。构建场景、多物件构图或带重复物件、文字、标志、纹理参考的目标时读取 [scene-planning.md](references/scene-planning.md)。对象属于载具、机器、机器人、工具或工业设备时必须读取 [mechanical-decomposition.md](references/mechanical-decomposition.md)。遇到角色、曲面、外壳、线框或复杂装配时读取 [modeling-strategy.md](references/modeling-strategy.md)。执行验收时读取 [validation-guide.md](references/validation-guide.md)。

## 标准基元

| ID | 名称 |
|---|---|
| `10009001` | 长方体 |
| `10009002` | 球体 |
| `10009003` | 平面 |
| `10009004` | 三棱柱 |
| `10009005` | 五棱柱 |
| `10009006` | 三棱锥 |
| `10009007` | 五棱锥 |
| `10009008` | 圆柱 |
| `10009009` | 圆锥 |
| `10009010` | 线框长方体 |
| `10009011` | 线框圆柱 |

选择能直接表达局部形状的最简单基元。基元选择必须先做硬性适配筛选，再按所属组的 `primitive_priority` 从高到低选择；只有更低优先级能显著改善轮廓、连接、厚度或几何意图时才允许越级，并在组说明中记录理由。不要因“细节丰富”机械地切成密集小格，也不要用少量不匹配的大体块抹掉决定辨识度的结构。

## 先查基元复用技巧

| 目标形状 | 首选技巧 | 数量与边界 |
|---|---|---|
| 细圆环 / 椭圆环 | `10009011` 局部 Y 压扁，再旋转 | 1 个；大小可变，线厚不随缩放改变 |
| 同色细矩形框 | `10009010` 沿一轴压扁 | 1 个替代适用的四边拼框；不是实心矩形面 |
| 箱形 / 圆柱形细护框 | 直接使用匹配的原生线框 | 1 个；不能替代实体外壳或任意粗梁 |
| 有厚度的圆盘、薄板 | 压扁实体圆柱、长方体 | 保留实体语义；圆盘没有中心孔 |
| 椭球、楔面、尖顶 | 球体非均匀缩放、棱柱、锥体 | 用合适大基元，避免小块采样 |

选择前核对允许子集、截面/线厚、轮廓、开口、颜色和接口。详细尺寸、方向、反例与 epsilon 边界见 [primitive-recipes.md](references/primitive-recipes.md)。

## 必须生成的档案

```text
<project_name>/
├─ components.json
├─ assembly.json
├─ scene_plan.json
├─ reference_analysis.json
├─ decomposition.json
├─ style_profile.json
├─ manifest.json
├─ primitive_catalog.json
├─ validation.json
├─ fragmentation.json
├─ build_log.jsonl
├─ self_check.md
├─ summary.md
├─ prompt.md
├─ prompt_contract.json
├─ prompt_state.json
├─ prompt_log.jsonl
├─ schemas/
├─ preview/
│  ├─ index.html
│  ├─ viewer.js
│  ├─ styles.css
│  └─ scene_data.js
└─ screenshots/
   ├─ step_XX_<group_id>.png
   ├─ final_perspective.png
   ├─ final_front.png
   ├─ final_right.png
   ├─ final_back.png
   ├─ final_top_or_isometric.png
   └─ contact_sheet.png
```

最终再生成 `<project_name>.zip`。详细字段见 [archive-contract.md](references/archive-contract.md)。

## 执行流程

### 0. 生成完整建模 Prompt，等待用户确认

1. 完整读取新模板和使用规则，结合当前任务生成 `draft_prompt.md`。保留一至十四章，逐章写出具体目标、结构、分区、细节、禁项、执行顺序和验收条件；不得压成几条摘要。非适用内容必须改写成该对象的对应模块并说明，不要留下空标题。
2. 在技术约束中写明 Y-up、连续浮点、允许基元及选择策略、尺寸与接口、基元合并策略、能力限制和输出格式。将 `primitive-recipes.prompt.md` 的适用内容编入第二章；允许线框时必须说明压扁成环/框、线厚不随缩放改变和固定像素预览未标定。新任务契约保留默认 `wireframe_policy`；无环框任务说明不适用，不强行添加。高精度场景按任务制定数量预算，不能把初始化占位值 200 当作最终上限。
3. 创建技术契约。默认是全部 11 类基元；限制基元或明确数量上限时，先编辑契约文件。运行以下命令只创建规划文件，不创建模型或预览：

```bash
python3 "$SKILL_DIR/scripts/prompt_workflow.py" prepare <project_name> --output <parent_dir> --prompt <draft_prompt.md>
# 有任务专用契约时，在命令末尾增加 --contract <task_contract.json>。
```

4. 给用户提供生成的 `prompt.md` 和 `prompt_contract.json` 的实际文件链接，并用简短说明询问是否确认或需要修改。本轮到此结束，状态必须为 `awaiting_user_confirmation`。
5. 用户对当前版本明确确认后，才按 [prompt-workflow.md](references/prompt-workflow.md) 记录真实消息原文、消息引用与两个当前文件哈希。禁止编造用户回复、伪造引用、自己写 approved 或用初始建模请求自批。
6. 用户要求修改时使用 `revise`。Prompt 或契约任一字节变动都会使旧哈希不匹配，必须重新展示并确认。已初始化工程重新确认后还需 `sync-manifest`，不自动改动已有组件。

**脚本门禁用于防止正常流程跳步，不是用户身份认证或防篡改安全边界。它不能证明本地录入的回复确实来自用户，也不能阻止绕过内置脚本直接写文件。执行宿主仍须核对真实对话。**

### 1. 初始化工程

仅在第 0 阶段获批后运行。初始化接纳已有的规划文件目录，拒绝覆盖已存在的模型；不再要求获批规划目录为空。

确定项目名、目标尺寸、风格、允许基元、必保留结构和参考视图。非阻塞信息不足时采用合理假设并写入 `manifest.json` 与 `summary.md`，不得改动已确认的关键约束。初始化从已确认技术契约读取允许基元、表达模式和可选数量上限。

```bash
python3 "$SKILL_DIR/scripts/init_archive.py" <project_name> --output <parent_dir>
```

不得临场重写预览器、Schema 或报告模板；使用技能内置资源。

### 2. 先融合参考、推断遮挡并恢复比例

在创建任何组件前完成 `reference_analysis.json`：

1. 登记每张图片的来源标签、视角、投影、可靠度和主体范围；文字输入使用 `text_only`。
2. 多图输入建立共享 `landmark_id`，记录各视图的可见性与归一化坐标，生成三维融合地标和逐视图轮廓约束。
3. 视图间比例、轮廓或细节冲突必须写入 `conflicts`，用可靠度、几何一致性或保留歧义解决。
4. 对每张图建立 `occluder_group_id → occluded_group_id` 遮挡图；隐藏结构只能依据其他视图、对称、可见延续、机械模板或保守未知处理。
5. 优先使用用户尺寸、制造规格或标准件恢复真实比例；弱标尺使用 `absolute_estimated`；没有标尺时设置 `relative_only`，只保留轴向比例约束。
6. 将决定组件的融合地标写入组件 `evidence_ids`，保持证据可追溯。

不得用单张透视图的像素长度直接推断真实米数。详细规则见 [reference-reconstruction.md](references/reference-reconstruction.md)。

### 3. 做场景坐标规划

在创建任何组件前完成 `scene_plan.json`：

1. 确定世界原点、地面高度、场景包围盒与真实尺度参照。
2. 建立主相机位置、观察目标、视场角、主视线和构图中心。
3. 为主要物件建立命名锚点与空间区域，所有位置必须能追溯到锚点、区域或明确尺寸。
4. 单体项目至少建立 `subject` 深度层；环境或多物件场景必须规划前景、中景、远景，并声明各层距离范围、职责、细节等级和所属组。
5. 不得从第一个物件开始连续累加坐标，也不得靠渲染器自动居中代替场景布局。

详细字段、距离定义和场景/单体差异见 [scene-planning.md](references/scene-planning.md)。

场景的 `scale_reference` 必须与 `reference_analysis.scale_recovery` 一致；若后者为 `relative_only`，不得把前者写成已知真实尺寸。

### 4. 先拆解对象与机械设备

完成 `decomposition.json`：

- 非机械对象使用 `generic_object`，仍按系统、模块、子装配、零件和细节组织。
- 机械对象选择 `vehicle_aircraft`、`rotary_machine`、`robot_actuated`、`industrial_equipment`、`handheld_tool` 或 `custom_mechanical`。
- 依据功能、运动、接口、维护、接缝与轮廓断点拆解；每个装配组必须由唯一的最具体节点认领。
- 机械对象至少具有 `system → module → part` 层级，并记录壳体、框架、执行器、传动、轴、管线、传感器、控制与安全等机械角色。
- 相对运动、嵌套或能量/流体连接必须记录接口；旋转/滑动接口必须给出轴，未知时不得猜测限位。

机械模板只提供最简结构先验，不能覆盖可靠多视图证据。详见 [mechanical-decomposition.md](references/mechanical-decomposition.md)。

### 5. 声明重复物件与表面内容策略

先审核参考中的重复物件、文字、标志、图案和贴图，再建模：

- 重复物件必须在 `repeat_policy` 中明确标记为 `not_present` 或 `planned`。若为 `planned`，声明原型实例、实例成员、排列方式、间距、随机种子、可变化参数与不可变化特征；不要手工复制后让重复规律隐含在坐标里。
- 表面内容必须在 `surface_content_policy` 中明确标记为 `not_present` 或 `planned`。若为 `planned`，逐项选择基元文字、色块几何、简化符号、主色平面或有理由的省略。
- 纯基元档案不支持真实位图贴图或 UV。需要逐字可读或保持语义的近景文字时使用基元笔画；低显著度远景内容才允许简化或省略。用户明确要求精确位图时返回格式能力阻塞，不得用整张参考图贴平面冒充三维建模。

### 6. 声明几何意图、基元优先级与低模预算

先编辑 `assembly.json`，再创建组件。每个组必须选择一个角色：

- `volume`：实体主体。
- `shell`：覆盖或包围主体的外壳。
- `surface`：有意开放的表面。
- `frame`：有意稀疏的框架。
- `connector`：负责连接的结构。
- `detail`：附着或明确悬浮的局部细节。

同时声明 `closure`、`continuity`、`attachment`、允许基元、基元优先级和基元预算。`primitive_priority` 必须是 `allowed_template_ids` 的完整有序排列：第一个是该组默认首选，后续是逐级备选。不得把所有目标统一假设为封闭外壳；验证必须服从声明的几何意图。

建模前将 `style_profile.json.status` 改为 `planned`，明确：

- 风格模式、轮廓语言、曲面处理和对称策略。
- 全局组件上限、调色板上限、主结构最低占比与细节最高占比。
- 与每个深度层一一对应的 LOD 预算。
- 每个组的主结构/次结构/连接/细节职责和组件/颜色上限。
- 禁止均匀小格、像素噪点、无理由细分、隐藏细节和用长方体密集采样可直接表达的曲面。

### 7. 从场景到物件、从大到小建模

场景先按“远景大体量 → 中景主体 → 前景遮挡与引导 → 重复实例 → 表面内容”建立空间关系；每个物件再按“整体轮廓 → 主体体量 → 中型结构 → 连接与转折 → 高价值细节”推进：

1. 依照融合地标、恢复比例、拆解节点、场景锚点、区域与深度层放置组。
2. 用少量合适的大基元建立比例和主轮廓。
3. 先查基元复用技巧，再按 `primitive_priority` 用棱柱、棱锥、圆柱、圆锥、球体或平面直接表达斜面、渐缩、圆弧、管道和薄片；适合的完整细圆环/矩形框优先用压扁线框。固有线厚不适合等原因必须写入 `primitive_priority_notes`，不得通过缩放假装改变线厚。
4. 建立连续关系、接触关系和覆盖关系。
5. 依据重复规则展开实例；只变化已允许的平移、旋转、缩放和色彩参数。
6. 最后才加入颜色分区、表情、文字、符号、纹样、机械缝或小装饰。
7. 删除被完全遮挡且无功能、重复、可无损合并、低于投影阈值或对轮廓没有贡献的组件。

每个组件只使用一个 `#RRGGBB` 纯色。多色结构拆成多个有语义的组件；不要用随机散色或噪点增加数量。

### 8. 每组闭环验证

每完成一个组，依次运行：

```bash
python3 "$SKILL_DIR/scripts/build_scene_data.py" <project_dir>
python3 "$SKILL_DIR/scripts/analyze_fragmentation.py" <project_dir>
python3 "$SKILL_DIR/scripts/validate_archive.py" <project_dir>
node "$SKILL_DIR/scripts/capture_views.mjs" <project_dir> --step <group_id>
```

用图像查看工具实际检查生成的 `step_XX_<group_id>.png`，再决定是否修改。不要根据 JSON 自行想象预览效果。

出现以下任一现象必须修正：

- 基元与局部形状明显不匹配。
- 大量相同尺寸组件沿固定步长排列。
- 全部组件尺寸近似，缺少大、中、小层次。
- 声明连续的组断裂、悬浮或存在非设计缝隙。
- `shell` 未满足声明的覆盖/封闭意图。
- 可删除或合并的组件仍大量存在。
- 多视图轮廓、比例、朝向或辨识特征偏离参考。
- 多图没有共享地标、轮廓约束或视图冲突处理，或组件无法追溯到融合证据。
- 同一视图遮挡关系矛盾/循环，或隐藏结构依赖无依据想象。
- 声称真实尺度却没有标尺，或实际包围盒与恢复尺寸/比例超差。
- 机械设备没有功能层级、接口、运动轴或唯一组归属。
- 总组件、颜色、组级预算或深度层 LOD 超限；细节占比压过主结构。
- 场景边界与实际组件不一致，组件不属于任何锚点/区域或深度层。
- 环境场景的前、中、远景职责混淆，所有物件投影尺寸或细节密度趋同。
- 重复物件没有原型/实例规则，或超出声明的变化范围。
- 高显著度文字、符号或贴图语义被随意省略、伪造或整图替代。
- 实际使用更低优先级基元，却没有可验证的轮廓、连接或拓扑收益。

### 9. 最终预览与人工判定

运行最终视图：

```bash
python3 "$SKILL_DIR/scripts/build_scene_data.py" <project_dir>
node "$SKILL_DIR/scripts/capture_views.mjs" <project_dir> --final
```

逐张查看正、右、背、俯视/等距和透视截图。将 `validation.json` 中的人工检查从 `pending` 改为 `passed` 或 `failed`，写清证据和修改。人工检查至少覆盖：

- `REPRESENTATION_MISMATCH`
- `INTENT_COVERAGE_FAILURE`
- `SILHOUETTE_MISMATCH`
- `MULTIVIEW_FUSION_INCOMPLETE`
- `OCCLUSION_INFERENCE_CONFLICT`
- `REAL_SCALE_UNSUPPORTED`
- `DECOMPOSITION_CONTRACT_ERROR`
- `LOW_POLY_STYLE_VIOLATION`
- `SCENE_COORDINATE_MISMATCH`
- `DEPTH_HIERARCHY_COLLAPSE`
- `REPETITION_CONTRACT_ERROR`
- `SURFACE_CONTENT_MISMATCH`
- `PRIMITIVE_PRIORITY_VIOLATION`
- `OUTPUT_SUBSTITUTION`

最多自动修正 5 轮。仍不合格则保留档案并标记 `FAILED_VALIDATION`，禁止伪称完成。

### 10. 严格验收与打包

```bash
python3 "$SKILL_DIR/scripts/prompt_workflow.py" check <project_dir>
python3 "$SKILL_DIR/scripts/validate_archive.py" <project_dir> --strict
python3 "$SKILL_DIR/scripts/verify_artifacts.py" <project_dir> --strict
python3 "$SKILL_DIR/scripts/package_archive.py" <project_dir>
```

只有全部命令成功、`self_check.md` 的最终状态为 `PASSED`，并且 ZIP 确实存在时才宣布完成。

## 通用错误分类

不得为某个飞船、角色或单次事故编写专用补丁。使用以下通用错误码：

- `REPRESENTATION_MISMATCH`：基元类型不适合目标局部形状。
- `OVER_FRAGMENTATION`：低价值微型组件过多。
- `GRID_FRAGMENTATION`：规则栅格式重复拆分。
- `SCALE_HIERARCHY_COLLAPSE`：缺少大、中、小结构层级。
- `INTENT_COVERAGE_FAILURE`：未满足覆盖、封闭或开放意图。
- `DISCONNECTED_ASSEMBLY`：应连续或连接的装配断裂。
- `REDUNDANT_PRIMITIVES`：重复、无贡献或可无损合并。
- `TRANSFORM_CONTRACT_ERROR`：中心、旋转、缩放或坐标语义不一致。
- `MULTIVIEW_FUSION_INCOMPLETE`：多图缺少共享地标、轮廓约束、融合结果或冲突处理。
- `OCCLUSION_INFERENCE_CONFLICT`：逐视图遮挡图矛盾、循环，或隐藏几何缺少可信依据。
- `REAL_SCALE_UNSUPPORTED`：绝对尺寸无可靠标尺、实际尺寸/比例超差，或相对尺度被伪装成米制。
- `DECOMPOSITION_CONTRACT_ERROR`：对象/机械层级、组归属、接口、角色或运动轴缺失/矛盾。
- `LOW_POLY_STYLE_VIOLATION`：组件、色彩、细节占比或深度 LOD 超预算，或违反低模形状语言。
- `SCENE_PLAN_INCOMPLETE`：缺少世界坐标、尺度、相机、锚点或区域规划。
- `SCENE_COORDINATE_MISMATCH`：组件、组边界或锚点与声明的场景坐标不一致。
- `DEPTH_HIERARCHY_COLLAPSE`：前中远层级缺失、顺序错误、职责混淆或细节密度趋同。
- `REPETITION_CONTRACT_ERROR`：重复集合缺少原型、实例成员、排列或变化约束。
- `SURFACE_CONTENT_MISMATCH`：文字、符号、图案或贴图参考未按显著度和可读性处理。
- `PRIMITIVE_PRIORITY_VIOLATION`：基元优先级缺失、非法或无理由越级。
- `SILHOUETTE_MISMATCH`：多视图轮廓偏离目标。
- `OUTPUT_SUBSTITUTION`：以二维生成图片替代三维档案。
- `ARTIFACT_INCOMPLETE`：档案、预览、截图或报告缺失。
- `PROMPT_REQUIRED`：缺少 Prompt、技术契约或流程记录。
- `PROMPT_STRUCTURE_INVALID`：十四章架构缺失、章节为空或技术约束缺失。
- `PROMPT_NOT_APPROVED`：没有当前版本的用户确认。
- `PROMPT_CHANGED`：Prompt 或技术契约的内容哈希改变，旧确认失效。
- `PROMPT_APPROVAL_INVALID` / `PROMPT_STATE_INVALID`：确认依据或流程记录无效。
- `PROMPT_CONTRACT_INVALID` / `PROMPT_CONTRACT_MISMATCH`：技术契约非法，或模型/清单违背已确认约束。

## 完成禁区

- 确认后的最终建模交付不得只有说明、提示词、效果图或未执行的代码；第 0 阶段必须只交 Prompt 与契约并等待确认。
- 不得把“基元数量多”当作质量高。
- 不得把 `frame` 误判为缺少外壳，也不得把应封闭的 `shell` 放行为开放表面。
- 不得伪造截图、检查记录、通过状态或 ZIP。
- 不得默认启用体素化、固定步长、整数网格或 0.01 量化。
- 不得加入用户未提供且无法从参考图合理推断的主要结构。
- 不得把不同视图的姿态、版本或透视差异直接平均成不存在的结构。
- 不得因为机械模板“通常存在”某零件，就在参考证据不足时补出高细节内部件。
- 不得在无已知尺寸、规格、标准件或相机标定时宣称恢复了真实米制比例。
- 不得把“低模”解释成规则体素、小格堆叠或随机删件。
- 不得把所有组堆在原点附近，再依赖预览器自动适配镜头制造“场景已规划”的假象。
- 不得把重复物件逐个临场复制而不记录原型、实例和变化规则。
- 不得把完整参考图、截图或含主体的图片作为平面贴图替代可见三维结构。
