#!/usr/bin/env python3
"""Strictly validate and package one GPT2GIA project."""

from __future__ import annotations

import argparse
import sys
import zipfile
from pathlib import Path

from validate_archive import validate_project
from verify_artifacts import verify_project
from prompt_workflow import require_approved


def package_project(project: Path, output: Path | None = None) -> Path:
    project = project.resolve()
    require_approved(project, check_components=True)
    validation = validate_project(project)
    if validation["status"] != "PASSED":
        raise RuntimeError(f"严格验证未通过：{validation['status']}")
    issues = verify_project(project)
    if issues:
        messages = "; ".join(item["message"] for item in issues)
        raise RuntimeError(f"产物核验未通过：{messages}")
    target = output.resolve() if output else project.parent / f"{project.name}.zip"
    if target == project or project in target.parents:
        raise ValueError("输出 ZIP 必须位于工程目录之外，避免把 ZIP 自身打包。")
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(project.rglob("*")):
            if not path.is_file() or "__pycache__" in path.parts or path.name == ".DS_Store":
                continue
            archive.write(path, Path(project.name) / path.relative_to(project))
    return target


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("project_dir", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        print(package_project(args.project_dir, args.output))
    except (RuntimeError, OSError, ValueError) as exc:
        print(str(exc), file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
