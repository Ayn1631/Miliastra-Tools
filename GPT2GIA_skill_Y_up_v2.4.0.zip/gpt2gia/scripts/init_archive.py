#!/usr/bin/env python3
"""Initialize a GPT2GIA component archive from bundled assets."""

from __future__ import annotations

import argparse
import sys
import re
import shutil
from pathlib import Path

from common import load_json, utc_now, write_json
from prompt_workflow import PLANNING_FILES, WORKFLOW_VERSION, PromptGateError, require_approved

SKILL_DIR = Path(__file__).resolve().parent.parent
ASSETS = SKILL_DIR / "assets"


def slugify(value: str) -> str:
    slug = re.sub(r"[^a-z0-9_-]+", "_", value.strip().lower()).strip("_")
    if not slug:
        raise ValueError("项目名必须至少包含一个英文字母、数字、下划线或连字符")
    return slug


def initialize(project_name: str, output: Path, example: str | None = None) -> Path:
    slug = slugify(project_name)
    project = output.resolve() / slug
    # 仅接纳已完成 Prompt 确认、尚未建模的规划目录。
    state = require_approved(project, check_manifest=False)
    extras = [path.name for path in project.iterdir() if path.name not in PLANNING_FILES]
    if extras:
        raise FileExistsError(f"目标目录已有建模或未知文件，拒绝覆盖：{extras}")
    prompt_contract = load_json(project / "prompt_contract.json")
    if example:
        example_dir = ASSETS / "examples" / example
        if example not in {p.name for p in (ASSETS / "examples").iterdir() if p.is_dir()}:
            raise ValueError(f"未知示例：{example}")
        example_components = load_json(example_dir / "components.json")["components"]
        if any(c["template_id"] not in prompt_contract["allowed_template_ids"] for c in example_components):
            raise ValueError("内置示例含当前已确认契约不允许的基元；拒绝初始化。")
        budget = prompt_contract.get("component_budget_max")
        if budget is not None and len(example_components) > budget:
            raise ValueError("内置示例超过当前已确认的组件数量上限。")
    (project / "screenshots").mkdir(exist_ok=True)
    shutil.copytree(ASSETS / "viewer", project / "preview", dirs_exist_ok=True)
    shutil.copytree(ASSETS / "schemas", project / "schemas", dirs_exist_ok=True)
    shutil.copy2(ASSETS / "primitive_catalog.json", project / "primitive_catalog.json")
    shutil.copy2(ASSETS / "templates" / "summary.md", project / "summary.md")
    shutil.copy2(ASSETS / "templates" / "self_check.md", project / "self_check.md")

    defaults = load_json(ASSETS / "defaults.json")
    components = {"schema_version": "2.2.0", "components": []}
    assembly = {"schema_version": "2.2.0", "groups": [], "relationships": []}
    scene_plan = {
        "schema_version": "2.2.0",
        "scene_scope": "single_object",
        "coordinate_plan": {
            "planning_status": "pending",
            "world_origin": [0.0, 0.0, 0.0],
            "ground_y": 0.0,
            "scene_bounds": {"min": [-1.0, 0.0, -1.0], "max": [1.0, 2.0, 1.0]},
            "scale_reference": {
                "kind": "arbitrary",
                "value": 1.0,
                "unit": "meter",
                "basis": "初始化占位；建模前必须替换为用户尺寸或参考推断依据。",
            },
            "anchors": [
                {
                    "anchor_id": "subject_origin",
                    "position": [0.0, 0.0, 0.0],
                    "purpose": "初始化占位；建模前定义主体语义锚点。",
                    "group_ids": [],
                }
            ],
            "zones": [],
        },
        "camera_plan": {
            "position": [4.0, 3.0, -6.0],
            "target": [0.0, 1.0, 0.0],
            "fov_degrees": 45.0,
            "depth_layers": [
                {
                    "layer_id": "subject",
                    "order": 0,
                    "distance_range": [0.0, 20.0],
                    "group_ids": ["pending_group"],
                    "purpose": "primary_subject",
                    "detail_level": "high",
                    "target_screen_fraction": [0.35, 0.85],
                    "occlusion_policy": "初始化占位；建模前替换。",
                }
            ],
        },
        "repeat_policy": {"status": "not_present", "sets": []},
        "surface_content_policy": {"status": "not_present", "items": []},
    }
    reference_analysis = {
        "schema_version": "2.2.0",
        "input_mode": "text_only",
        "views": [],
        "view_fusion": {
            "status": "not_applicable",
            "coordinate_convention": "normalized_image_xy_top_left",
            "landmarks": [],
            "silhouette_constraints": [],
            "conflicts": [],
        },
        "occlusion_inference": {
            "status": "not_present",
            "relations": [],
            "hidden_geometry": [],
        },
        "scale_recovery": {
            "status": "relative_only",
            "confidence": "low",
            "basis": "初始化占位；没有可靠绝对标尺时只允许恢复相对比例。",
            "targets": [
                {
                    "target_id": "subject",
                    "group_ids": [],
                    "mode": "relative_only",
                    "bounds_size_m": [None, None, None],
                    "reference_dimension": {
                        "kind": "relative_unit",
                        "value_m": None,
                        "source": "初始化占位；建模前替换为真实标尺或明确保持相对尺度。",
                        "uncertainty_fraction": 1.0,
                    },
                    "proportion_constraints": [],
                    "tolerance_fraction": 0.08,
                }
            ],
        },
    }
    decomposition = {
        "schema_version": "2.2.0",
        "profile": "generic",
        "template": "generic_object",
        "status": "pending",
        "root_node_id": "subject_system",
        "nodes": [
            {
                "node_id": "subject_system",
                "parent_node_id": None,
                "label": "主体系统",
                "level": "system",
                "group_ids": [],
                "function": "初始化占位；建模前完成对象或机械层级拆解。",
                "mechanical_role": "not_applicable",
                "visibility": "external",
                "motion": "static",
                "removable": False,
                "split_evidence": ["functional_boundary"],
            }
        ],
        "interfaces": [],
    }
    style_profile = {
        "schema_version": "2.2.0",
        "status": "pending",
        "style_mode": defaults["style_mode"],
        "shape_language": {
            "silhouette_first": True,
            "large_planes_first": True,
            "curve_treatment": "mixed",
            "symmetry_policy": "mostly_symmetric",
            "detail_policy": "identity_features",
        },
        "surface_language": {
            "color_mode": "flat_palette",
            "palette_max_colors": 16,
            "allow_noise": False,
            "allow_pixel_sampling": False,
        },
        "budgets": {
            "total_component_max": prompt_contract.get("component_budget_max") or 200,
            "primary_structure_fraction_min": 0.25,
            "detail_component_fraction_max": 0.35,
            "silhouette_tolerance_fraction": 0.08,
            "minimum_projected_feature_fraction": 0.01,
        },
        "depth_lod": [
            {
                "layer_id": "subject",
                "max_components_per_group": 80,
                "max_colors_per_group": 8,
                "allow_micro_detail": True,
            }
        ],
        "group_overrides": [],
        "forbidden_patterns": [
            "uniform_micro_tiles",
            "pixel_noise",
            "unjustified_subdivision",
            "hidden_detail",
            "smooth_curve_sampled_by_cuboids",
        ],
    }
    if example:
        example_dir = ASSETS / "examples" / example
        if not example_dir.is_dir():
            available = ", ".join(sorted(path.name for path in (ASSETS / "examples").iterdir()))
            raise ValueError(f"未知示例 {example!r}；可用示例：{available}")
        components = load_json(example_dir / "components.json")
        assembly = load_json(example_dir / "assembly.json")
        scene_plan = load_json(example_dir / "scene_plan.json")
        reference_analysis = load_json(example_dir / "reference_analysis.json")
        decomposition = load_json(example_dir / "decomposition.json")
        style_profile = load_json(example_dir / "style_profile.json")

    manifest = {
        "schema_version": "2.2.0",
        "project_name": slug,
        "created_at": utc_now(),
        "units": "meter",
        "coordinate_system": {
            "handedness": "right",
            "x": "right",
            "y": "up",
            "z": "depth",
        },
        "transform_contract": defaults["transform_contract"],
        "allowed_template_ids": prompt_contract["allowed_template_ids"],
        "representation_mode": prompt_contract["representation_mode"],
        "prompt_workflow": {
            "schema_version": WORKFLOW_VERSION,
            "prompt_sha256": state["prompt_sha256"],
            "contract_sha256": state["contract_sha256"],
        },
        "reference_views": [],
        "assumptions": [],
        "validation": defaults["validation"],
        "screenshots": defaults["screenshots"],
    }
    write_json(project / "components.json", components)
    write_json(project / "assembly.json", assembly)
    write_json(project / "scene_plan.json", scene_plan)
    write_json(project / "reference_analysis.json", reference_analysis)
    write_json(project / "decomposition.json", decomposition)
    write_json(project / "style_profile.json", style_profile)
    write_json(project / "manifest.json", manifest)
    write_json(
        project / "validation.json",
        {
            "schema_version": "2.2.0",
            "status": "PENDING",
            "generated_at": None,
            "errors": [],
            "checks": [],
            "manual_reviews": [
                {"code": code, "status": "pending", "evidence": ""}
                for code in (
                    "REPRESENTATION_MISMATCH",
                    "INTENT_COVERAGE_FAILURE",
                    "SILHOUETTE_MISMATCH",
                    "MULTIVIEW_FUSION_INCOMPLETE",
                    "OCCLUSION_INFERENCE_CONFLICT",
                    "REAL_SCALE_UNSUPPORTED",
                    "DECOMPOSITION_CONTRACT_ERROR",
                    "LOW_POLY_STYLE_VIOLATION",
                    "SCENE_COORDINATE_MISMATCH",
                    "DEPTH_HIERARCHY_COLLAPSE",
                    "REPETITION_CONTRACT_ERROR",
                    "SURFACE_CONTENT_MISMATCH",
                    "PRIMITIVE_PRIORITY_VIOLATION",
                    "OUTPUT_SUBSTITUTION",
                )
            ],
        },
    )
    write_json(project / "fragmentation.json", {"schema_version": "2.2.0", "groups": []})
    with (project / "build_log.jsonl").open("w", encoding="utf-8", newline="\n") as handle:
        handle.write(
            '{"time":"'
            + utc_now()
            + '","event":"archive_initialized","project":"'
            + slug
            + '"}\n'
        )
    from build_scene_data import build_scene_data

    build_scene_data(project)
    return project


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("project_name")
    parser.add_argument("--output", type=Path, default=Path.cwd())
    parser.add_argument("--example")
    args = parser.parse_args()
    try:
        project = initialize(args.project_name, args.output, args.example)
    except (PromptGateError, OSError, ValueError) as exc:
        print(str(exc), file=sys.stderr)
        return 2
    print(project)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
