#!/usr/bin/env python3
"""Build the browser-readable scene_data.js from archive JSON."""

from __future__ import annotations

import argparse
import sys
import json
from pathlib import Path

from common import load_json
from prompt_workflow import PromptGateError, require_approved


def build_scene_data(project: Path) -> Path:
    project = project.resolve()
    state = require_approved(project, check_components=True)
    payload = {
        "prompt_workflow": {"prompt_sha256": state["prompt_sha256"], "contract_sha256": state["contract_sha256"]},
        "components": load_json(project / "components.json"),
        "assembly": load_json(project / "assembly.json"),
        "scene_plan": load_json(project / "scene_plan.json"),
        "reference_analysis": load_json(project / "reference_analysis.json"),
        "decomposition": load_json(project / "decomposition.json"),
        "style_profile": load_json(project / "style_profile.json"),
        "manifest": load_json(project / "manifest.json"),
        "catalog": load_json(project / "primitive_catalog.json"),
    }
    encoded = json.dumps(payload, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
    encoded = encoded.replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    target = project / "preview" / "scene_data.js"
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write("window.GPT2GIA_SCENE=")
        handle.write(encoded)
        handle.write(";\n")
    return target


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("project_dir", type=Path)
    args = parser.parse_args()
    try:
        print(build_scene_data(args.project_dir))
    except (PromptGateError, OSError, ValueError) as exc:
        print(str(exc), file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
