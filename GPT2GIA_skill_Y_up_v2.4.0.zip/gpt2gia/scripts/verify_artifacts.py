#!/usr/bin/env python3
"""Verify that a GPT2GIA delivery contains real, complete artifacts."""

from __future__ import annotations

import argparse
import json
import re
import struct
from pathlib import Path
from typing import Any

from common import load_json
from prompt_workflow import inspect_workflow


def png_size(path: Path) -> tuple[int, int] | None:
    try:
        with path.open("rb") as handle:
            header = handle.read(24)
    except OSError:
        return None
    if len(header) != 24 or header[:8] != b"\x89PNG\r\n\x1a\n" or header[12:16] != b"IHDR":
        return None
    return struct.unpack(">II", header[16:24])


def verify_project(project: Path) -> list[dict[str, Any]]:
    project = project.resolve()
    issues: list[dict[str, Any]] = inspect_workflow(project, check_components=True)
    required = (
        "prompt.md",
        "prompt_contract.json",
        "prompt_state.json",
        "prompt_log.jsonl",
        "components.json",
        "assembly.json",
        "scene_plan.json",
        "reference_analysis.json",
        "decomposition.json",
        "style_profile.json",
        "manifest.json",
        "primitive_catalog.json",
        "validation.json",
        "fragmentation.json",
        "build_log.jsonl",
        "self_check.md",
        "summary.md",
        "preview/index.html",
        "preview/viewer.js",
        "preview/styles.css",
        "preview/scene_data.js",
        "schemas/components.schema.json",
        "schemas/assembly.schema.json",
        "schemas/scene_plan.schema.json",
        "schemas/reference_analysis.schema.json",
        "schemas/decomposition.schema.json",
        "schemas/style_profile.schema.json",
        "schemas/manifest.schema.json",
        "schemas/prompt_contract.schema.json",
        "schemas/prompt_state.schema.json",
    )
    for relative in required:
        if not (project / relative).is_file():
            issues.append({"code": "ARTIFACT_INCOMPLETE", "message": f"缺少 {relative}"})
    if issues:
        return issues

    manifest = load_json(project / "manifest.json")
    assembly = load_json(project / "assembly.json")
    validation = load_json(project / "validation.json")
    if validation.get("status") != "PASSED":
        issues.append({"code": "ARTIFACT_INCOMPLETE", "message": "validation.json 尚未 PASSED"})

    prompt_state = load_json(project / "prompt_state.json")
    screenshot_events = []
    for line in (project / "build_log.jsonl").read_text(encoding="utf-8").splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            issues.append({"code": "ARTIFACT_INCOMPLETE", "message": "build_log.jsonl 含非法 JSON 行"})
            continue
        if event.get("event") == "screenshot":
            # 旧 Prompt 的截图不能冒充本次修订的证据。
            if (event.get("prompt_sha256") == prompt_state["prompt_sha256"] and
                    event.get("contract_sha256") == prompt_state["contract_sha256"]):
                screenshot_events.append(event)
    if not screenshot_events:
        issues.append({"code": "OUTPUT_SUBSTITUTION", "message": "构建日志中没有真实渲染截图事件"})
    elif any(event.get("backend") not in {"playwright_browser", "viewer_canvas"} for event in screenshot_events):
        issues.append({"code": "OUTPUT_SUBSTITUTION", "message": "构建日志含未知截图后端"})
    if not any(event.get("mode") == "final" for event in screenshot_events):
        issues.append({"code": "OUTPUT_SUBSTITUTION", "message": "构建日志中没有最终视图渲染事件"})
    logged_step_groups = {
        event.get("group")
        for event in screenshot_events
        if event.get("mode") == "step" and isinstance(event.get("group"), str)
    }

    self_check = (project / "self_check.md").read_text(encoding="utf-8")
    if not re.search(r"最终状态[：:]\s*PASSED\b", self_check):
        issues.append({"code": "ARTIFACT_INCOMPLETE", "message": "self_check.md 未标记最终状态 PASSED"})

    screenshots = project / "screenshots"
    width = int(manifest.get("screenshots", {}).get("width", 1280))
    height = int(manifest.get("screenshots", {}).get("height", 900))
    view_names = {
        "perspective": "final_perspective.png",
        "front": "final_front.png",
        "right": "final_right.png",
        "back": "final_back.png",
        "top_or_isometric": "final_top_or_isometric.png",
    }
    for view in manifest.get("screenshots", {}).get("required_views", []):
        filename = view_names.get(view)
        if not filename:
            issues.append({"code": "ARTIFACT_INCOMPLETE", "message": f"未知必需视角：{view}"})
            continue
        size = png_size(screenshots / filename)
        if size is None:
            issues.append({"code": "ARTIFACT_INCOMPLETE", "message": f"{filename} 不是有效 PNG"})
        elif size[0] < width or size[1] < height:
            issues.append({"code": "ARTIFACT_INCOMPLETE", "message": f"{filename} 尺寸不足：{size}"})
    contact = png_size(screenshots / "contact_sheet.png")
    if contact is None:
        issues.append({"code": "ARTIFACT_INCOMPLETE", "message": "contact_sheet.png 不是有效 PNG"})

    for group in assembly.get("groups", []):
        group_id = str(group.get("group_id", ""))
        if group_id not in logged_step_groups:
            issues.append({"code": "OUTPUT_SUBSTITUTION", "message": f"{group_id} 缺少阶段渲染日志"})
        matches = list(screenshots.glob(f"step_*_{group_id}.png"))
        if not matches:
            issues.append({"code": "ARTIFACT_INCOMPLETE", "message": f"{group_id} 缺少阶段截图"})
        elif not any(png_size(path) for path in matches):
            issues.append({"code": "ARTIFACT_INCOMPLETE", "message": f"{group_id} 的阶段截图无有效 PNG"})
    return issues


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("project_dir", type=Path)
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()
    issues = verify_project(args.project_dir)
    if issues:
        for issue in issues:
            print(f"{issue['code']}: {issue['message']}")
        return 1
    print("PASSED: artifact verification")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
