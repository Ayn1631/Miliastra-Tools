#!/usr/bin/env python3
"""Prompt 草拟、用户确认和执行前置检查；不替用户作出确认。"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any

from common import ALLOWED_TEMPLATE_IDS, is_finite_vector3, load_json, utc_now, write_json

WORKFLOW_VERSION = "1.0.0"
COORDINATES = {"handedness": "right", "x": "right", "y": "up", "z": "depth"}
WIREFRAME_IDS = frozenset({10009010, 10009011})
WIREFRAME_POLICY = {'scale_effect': 'frame_dimensions_only', 'thickness_scales_with_object': False, 'thickness_value': None, 'thickness_status': 'unmeasured', 'flattening_scale': 'positive_nonzero', 'selection': 'prefer_single_native_frame_when_suitable', 'preview_mode': 'uncalibrated_screen_space_stroke'}
OPTIONAL_CONTRACT_FIELDS = {"wireframe_policy"}
PLANNING_FILES = {"prompt.md", "prompt_contract.json", "prompt_state.json", "prompt_log.jsonl"}
ORDINALS = ("一", "二", "三", "四", "五", "六", "七", "八", "九", "十", "十一", "十二", "十三", "十四")


class PromptGateError(RuntimeError):
    """带有可检索错误码的流程阻塞。"""

    def __init__(self, issues: list[dict[str, str]]):
        self.issues = issues
        super().__init__("\n".join(f"{item['code']}: {item['message']}" for item in issues))


def _issue(code: str, message: str) -> dict[str, str]:
    return {"code": code, "message": message}


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def default_contract() -> dict[str, Any]:
    """默认允许 11 类基元；数量预算必须按任务另行制定。"""
    return {
        "schema_version": WORKFLOW_VERSION,
        "coordinate_system": dict(COORDINATES),
        "allowed_template_ids": sorted(ALLOWED_TEMPLATE_IDS),
        "representation_mode": "adaptive_primitives",
        "numeric_policy": "continuous_float",
        "quantization_step": None,
        "fixed_decimal_places": None,
        "component_budget_max": None,
        "wireframe_policy": dict(WIREFRAME_POLICY),
    }


def validate_contract(contract: Any) -> list[dict[str, str]]:
    issues = []
    if not isinstance(contract, dict):
        return [_issue("PROMPT_CONTRACT_INVALID", "prompt_contract.json 必须为对象。")]
    known = set(default_contract())
    required = known - OPTIONAL_CONTRACT_FIELDS
    missing = required - set(contract)
    extra = set(contract) - known
    if missing or extra:
        issues.append(_issue("PROMPT_CONTRACT_INVALID", f"契约字段不完整或包含未知字段：缺少 {sorted(missing)}，额外 {sorted(extra)}。"))
    if contract.get("schema_version") != WORKFLOW_VERSION:
        issues.append(_issue("PROMPT_CONTRACT_INVALID", "流程契约版本必须为 1.0.0。"))
    if contract.get("coordinate_system") != COORDINATES:
        issues.append(_issue("PROMPT_CONTRACT_INVALID", "必须使用右手 Y-up：X 左右、Y 高度、Z 进深。"))
    ids = contract.get("allowed_template_ids")
    valid_ids = (isinstance(ids, list) and bool(ids) and
                 all(type(item) is int and item in ALLOWED_TEMPLATE_IDS for item in ids))
    if not valid_ids or len(ids) != len(set(ids)):
        issues.append(_issue("PROMPT_CONTRACT_INVALID", "允许基元必须是 11 种目录 ID 的非空、无重复子集。"))
    mode = contract.get("representation_mode")
    if mode not in {"adaptive_primitives", "restricted_primitives", "cuboid_only", "voxel_pixel"}:
        issues.append(_issue("PROMPT_CONTRACT_INVALID", "representation_mode 非法。"))
    elif mode in {"cuboid_only", "voxel_pixel"} and ids != [10009001]:
        issues.append(_issue("PROMPT_CONTRACT_INVALID", "纯长方体/体素模式只能允许 [10009001]。"))
    elif mode == "adaptive_primitives" and valid_ids and set(ids) != ALLOWED_TEMPLATE_IDS:
        issues.append(_issue("PROMPT_CONTRACT_INVALID", "指定基元子集请使用 restricted_primitives 或 cuboid_only。"))
    if contract.get("numeric_policy") != "continuous_float":
        issues.append(_issue("PROMPT_CONTRACT_INVALID", "本版使用连续浮点，不允许默认量化。"))
    for key in ("quantization_step", "fixed_decimal_places"):
        if key not in contract or contract[key] is not None:
            issues.append(_issue("PROMPT_CONTRACT_INVALID", f"{key} 必须明确为 null，不设置固定精度。"))
    budget = contract.get("component_budget_max")
    if budget is not None and (type(budget) is not int or budget < 1):
        issues.append(_issue("PROMPT_CONTRACT_INVALID", "component_budget_max 必须为正整数或 null。"))
    actual_policy = contract.get("wireframe_policy")
    policy_exact = (isinstance(actual_policy, dict) and set(actual_policy) == set(WIREFRAME_POLICY)
                    and all(type(actual_policy[key]) is type(value) and actual_policy[key] == value
                            for key, value in WIREFRAME_POLICY.items()))
    if "wireframe_policy" in contract and not policy_exact:
        issues.append(_issue("PROMPT_CONTRACT_INVALID", "wireframe_policy 必须保持内置固定线厚规则；缩放不改变线厚，实际厚度未标定。"))
    return issues


def validate_prompt_bytes(content: bytes) -> list[dict[str, str]]:
    """检查模板架构与非空正文；不声称可自动评判语义质量。"""
    try:
        text = content.decode("utf-8-sig")
    except UnicodeDecodeError:
        return [_issue("PROMPT_STRUCTURE_INVALID", "Prompt 必须是 UTF-8 文本。")]
    lines = []
    fence = None
    for line in text.splitlines():
        marker = re.match(r"^\s*(`{3,}|~{3,})", line)
        if marker:
            token = marker.group(1)
            if fence is None:
                fence = token[0]
            elif token[0] == fence:
                fence = None
            continue
        if fence is None:
            lines.append(line)
    visible = "\n".join(lines)
    matches = list(re.finditer(r"(?m)^#\s+([一二三四五六七八九十]+)[、.．]\s*(.+)$", visible))
    found = [match.group(1) for match in matches]
    issues = []
    if found != list(ORDINALS):
        issues.append(_issue("PROMPT_STRUCTURE_INVALID", "必须按新模板保留一至十四的一级章节，顺序完整且不重复；标题可按对象改写。"))
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(visible)
        body = re.sub(r"[\s#*`>\-]", "", visible[match.end():end])
        if len(body) < 20:
            issues.append(_issue("PROMPT_STRUCTURE_INVALID", f"第{match.group(1)}章正文不足，不能只留标题或占位。"))
    if not re.search(r"\bY[-‐‑–]up\b", visible, re.IGNORECASE):
        issues.append(_issue("PROMPT_STRUCTURE_INVALID", "技术约束须明确写出 Y-up。"))
    if "连续浮点" not in visible:
        issues.append(_issue("PROMPT_STRUCTURE_INVALID", "技术约束须明确使用连续浮点值。"))
    if re.search(r"\{\{[^}]+\}\}|(?im:^\s*(?:TODO|TBD|待补充|待填写)\s*[：:]?\s*$)", visible):
        issues.append(_issue("PROMPT_STRUCTURE_INVALID", "Prompt 仍含未填写的模板占位符。"))
    return issues


def validate_wireframe_requirements(content: bytes, contract: Any, *, require_current: bool = True) -> list[dict[str, str]]:
    """检查新技巧的明确声明，不推断自然语言的完整几何意图。"""
    if not isinstance(contract, dict):
        return []  # 由 validate_contract 报告结构错误。
    ids = contract.get("allowed_template_ids")
    if not isinstance(ids, list) or not all(type(value) is int for value in ids):
        return []
    wire_ids = WIREFRAME_IDS.intersection(ids)
    if not wire_ids:
        return []  # 不能要求纯长方体任务采用线框。
    if "wireframe_policy" not in contract:
        if require_current:
            return [_issue("PROMPT_WIREFRAME_POLICY_REQUIRED", "新建或修订允许线框的任务须使用带 wireframe_policy 的技术契约。")]
        return []  # 保留旧已确认工程原契约，不能静默补签新规则。
    try:
        text = content.decode("utf-8-sig")
    except UnicodeDecodeError:
        return []  # 编码错误由架构检查报告。
    lines, fence = [], None
    for line in text.splitlines():
        marker = re.match(r"^\s*(`{3,}|~{3,})", line)
        if marker:
            char = marker.group(1)[0]
            if fence is None:
                fence = char
            elif fence == char:
                fence = None
            continue
        if fence is None:
            lines.append(line)
    visible = "\n".join(lines)
    match = re.search(r"(?ms)^#\s+二[、.．][^\n]*\n(.*?)(?=^#\s+三[、.．]|\Z)", visible)
    technical = match.group(1) if match else ""
    missing = []
    if 10009011 in wire_ids and not ("10009011" in technical and "圆环" in technical and "压扁" in technical):
        missing.append("10009011 压扁成圆环的适用/不适用说明")
    if 10009010 in wire_ids and not ("10009010" in technical and re.search(r"矩形框|长方形框", technical) and "压扁" in technical):
        missing.append("10009010 压扁成矩形框的适用/不适用说明")
    if "线厚不随缩放改变" not in technical:
        missing.append("明确规则：线厚不随缩放改变")
    if not all(word in technical for word in ("固定像素", "标定")):
        missing.append("固定像素预览与未标定游戏线厚的区别")
    if missing:
        return [_issue("PROMPT_WIREFRAME_TECHNIQUE_MISSING", "第二章缺少：" + "；".join(missing) + "。参考 primitive-recipes.prompt.md 补全；不适用时写明原因，不新增无关结构。")]
    return []


def _append_log(project: Path, event: str, **details: Any) -> None:
    with (project / "prompt_log.jsonl").open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps({"time": utc_now(), "event": event, **details}, ensure_ascii=False, allow_nan=False) + "\n")


def _write_draft(project: Path, content: bytes, contract: dict[str, Any], revision: int) -> dict[str, Any]:
    (project / "prompt.md").write_bytes(content)
    write_json(project / "prompt_contract.json", contract)
    state = {
        "schema_version": WORKFLOW_VERSION,
        "status": "awaiting_user_confirmation",
        "revision": revision,
        "drafted_at": utc_now(),
        "prompt_sha256": sha256_file(project / "prompt.md"),
        "contract_sha256": sha256_file(project / "prompt_contract.json"),
        "approval": None,
    }
    write_json(project / "prompt_state.json", state)
    _append_log(project, "prompt_prepared", revision=revision, prompt_sha256=state["prompt_sha256"],
                contract_sha256=state["contract_sha256"])
    # 旧模型保留以便修改，但旧人工验收不能自动继承到新 Prompt。
    validation = project / "validation.json"
    if validation.exists():
        write_json(validation, {"schema_version": "2.2.0", "status": "PENDING", "generated_at": utc_now(),
                                "errors": [_issue("PROMPT_NOT_APPROVED", "Prompt 已修改，等待重新确认。")],
                                "checks": [], "manual_reviews": []})
    return state


def prepare(project_name: str, output: Path, draft: Path, contract_path: Path | None = None) -> Path:
    from init_archive import slugify
    content = draft.read_bytes()
    contract = load_json(contract_path) if contract_path else default_contract()
    issues = (validate_prompt_bytes(content) + validate_contract(contract)
              + validate_wireframe_requirements(content, contract))
    if issues:
        raise PromptGateError(issues)
    project = output.resolve() / slugify(project_name)
    if project.exists() and any(project.iterdir()):
        raise FileExistsError(f"目标目录非空，拒绝覆盖：{project}；修改现有 Prompt 请使用 revise。")
    project.mkdir(parents=True, exist_ok=True)
    _write_draft(project, content, contract, 1)
    return project


def revise(project: Path, draft: Path, contract_path: Path | None = None) -> dict[str, Any]:
    project = project.resolve()
    old = load_json(project / "prompt_state.json")
    if not isinstance(old, dict) or type(old.get("revision")) is not int or old["revision"] < 1:
        raise PromptGateError([_issue("PROMPT_STATE_INVALID", "旧流程记录没有合法 revision。")])
    content = draft.read_bytes()
    contract = load_json(contract_path or project / "prompt_contract.json")
    issues = (validate_prompt_bytes(content) + validate_contract(contract)
              + validate_wireframe_requirements(content, contract))
    if issues:
        raise PromptGateError(issues)
    return _write_draft(project, content, contract, old["revision"] + 1)


def inspect_workflow(project: Path, *, require_approval: bool = True,
                     check_manifest: bool = True, check_components: bool = False) -> list[dict[str, str]]:
    project = project.resolve()
    issues = []
    for name in ("prompt.md", "prompt_contract.json", "prompt_state.json", "prompt_log.jsonl"):
        if not (project / name).is_file():
            issues.append(_issue("PROMPT_REQUIRED", f"缺少 {name}；先生成 Prompt 并执行 prepare，不能直接建模。"))
    if issues:
        return issues
    try:
        issues.extend(validate_prompt_bytes((project / "prompt.md").read_bytes()))
        contract = load_json(project / "prompt_contract.json")
        state = load_json(project / "prompt_state.json")
        issues.extend(validate_contract(contract))
        issues.extend(validate_wireframe_requirements((project / "prompt.md").read_bytes(), contract,
                                                     require_current=False))
        if not isinstance(state, dict):
            return issues + [_issue("PROMPT_STATE_INVALID", "prompt_state.json 必须为对象。")]
        if (state.get("schema_version") != WORKFLOW_VERSION or
                type(state.get("revision")) is not int or state["revision"] < 1 or
                state.get("status") not in {"awaiting_user_confirmation", "approved"}):
            issues.append(_issue("PROMPT_STATE_INVALID", "流程版本、修订号或状态非法。"))
        hashes = {"prompt_sha256": sha256_file(project / "prompt.md"),
                  "contract_sha256": sha256_file(project / "prompt_contract.json")}
        if any(state.get(key) != value for key, value in hashes.items()):
            issues.append(_issue("PROMPT_CHANGED", "Prompt 或技术契约已改变；执行 revise 后必须重新展示并获得用户确认。"))
        if require_approval:
            approval = state.get("approval")
            if state.get("status") != "approved" or not isinstance(approval, dict):
                issues.append(_issue("PROMPT_NOT_APPROVED", "当前 Prompt 尚未获得用户确认；本轮应交付 Prompt 并停止建模。"))
            elif (approval.get("actor") != "user" or approval.get("source") != "user_message" or
                  not isinstance(approval.get("user_message"), str) or not approval["user_message"].strip() or
                  not isinstance(approval.get("user_message_ref"), str) or not approval["user_message_ref"].strip() or
                  not approval.get("recorded_at") or
                  any(approval.get(key) != value for key, value in hashes.items())):
                issues.append(_issue("PROMPT_APPROVAL_INVALID", "确认记录必须绑定当前文件哈希，并包含真实用户回复及其引用。"))
        if issues:
            return issues
        if check_manifest and (project / "manifest.json").exists():
            manifest = load_json(project / "manifest.json")
            if not isinstance(manifest, dict):
                return [_issue("PROMPT_CONTRACT_MISMATCH", "manifest.json 必须为对象。")]
            for key in ("coordinate_system", "allowed_template_ids", "representation_mode"):
                if manifest.get(key) != contract.get(key):
                    issues.append(_issue("PROMPT_CONTRACT_MISMATCH", f"manifest.{key} 与已确认技术契约不一致。"))
            workflow = manifest.get("prompt_workflow", {})
            if not isinstance(workflow, dict) or any(workflow.get(key) != value for key, value in hashes.items()):
                issues.append(_issue("PROMPT_CONTRACT_MISMATCH", "manifest 没有绑定当前已确认 Prompt；新修订确认后需执行 sync-manifest。"))
        if check_components and (project / "components.json").exists():
            data = load_json(project / "components.json")
            components = data.get("components") if isinstance(data, dict) else None
            if not isinstance(components, list):
                issues.append(_issue("PROMPT_CONTRACT_MISMATCH", "components.json 必须包含 components 数组。"))
            else:
                allowed = set(contract["allowed_template_ids"])
                for component in components:
                    if not isinstance(component, dict):
                        issues.append(_issue("PROMPT_CONTRACT_MISMATCH", "组件必须为对象。"))
                        continue
                    tid = component.get("template_id")
                    if type(tid) is not int or tid not in allowed:
                        issues.append(_issue("PROMPT_CONTRACT_MISMATCH", f"组件 {component.get('id')} 使用了未获允许的基元 {tid}。"))
                    for key in ("position", "rotation", "scale"):
                        if not is_finite_vector3(component.get(key), positive=key == "scale"):
                            issues.append(_issue("TRANSFORM_CONTRACT_ERROR", f"组件 {component.get('id')} 的 {key} 非法。"))
                budget = contract.get("component_budget_max")
                if budget is not None and len(components) > budget:
                    issues.append(_issue("PROMPT_CONTRACT_MISMATCH", f"实际组件数 {len(components)} 超过已确认上限 {budget}。"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError, ValueError, TypeError) as exc:
        issues.append(_issue("PROMPT_STATE_INVALID", f"流程文件无法解析：{exc}"))
    return issues


def require_approved(project: Path, *, check_manifest: bool = True, check_components: bool = False) -> dict[str, Any]:
    issues = inspect_workflow(project, check_manifest=check_manifest, check_components=check_components)
    if issues:
        raise PromptGateError(issues)
    return load_json(project / "prompt_state.json")


def record_confirmation(project: Path, user_message_file: Path, user_message_ref: str,
                        prompt_sha256: str, contract_sha256: str) -> dict[str, Any]:
    """仅记录已发生的用户确认。调用者负责核对原始会话，函数不能认证身份。"""
    project = project.resolve()
    issues = inspect_workflow(project, require_approval=False, check_manifest=False)
    if issues:
        raise PromptGateError(issues)
    message = user_message_file.read_text(encoding="utf-8-sig").strip()
    if not message or not user_message_ref.strip():
        raise PromptGateError([_issue("PROMPT_APPROVAL_INVALID", "必须提供真实用户确认回复和可核对的消息引用。")])
    state = load_json(project / "prompt_state.json")
    if state["prompt_sha256"] != prompt_sha256 or state["contract_sha256"] != contract_sha256:
        raise PromptGateError([_issue("PROMPT_APPROVAL_INVALID", "确认引用的哈希不是当前版本；请重新展示当前文件并获得确认。")])
    state["status"] = "approved"
    state["approval"] = {"actor": "user", "source": "user_message", "user_message": message,
                         "user_message_ref": user_message_ref.strip(), "recorded_at": utc_now(),
                         "prompt_sha256": prompt_sha256, "contract_sha256": contract_sha256}
    write_json(project / "prompt_state.json", state)
    _append_log(project, "user_confirmation_recorded", revision=state["revision"],
                user_message_ref=user_message_ref.strip(), prompt_sha256=prompt_sha256, contract_sha256=contract_sha256)
    return state


def sync_manifest(project: Path) -> None:
    """已初始化工程在 Prompt 重新确认后显式同步；不自动改动模型。"""
    state = require_approved(project, check_manifest=False)
    manifest = load_json(project / "manifest.json")
    if not isinstance(manifest, dict):
        raise ValueError("manifest.json 必须为对象")
    contract = load_json(project / "prompt_contract.json")
    for key in ("coordinate_system", "allowed_template_ids", "representation_mode"):
        manifest[key] = contract[key]
    manifest["prompt_workflow"] = {"schema_version": WORKFLOW_VERSION,
                                  "prompt_sha256": state["prompt_sha256"],
                                  "contract_sha256": state["contract_sha256"]}
    write_json(project / "manifest.json", manifest)
    _append_log(project, "manifest_synchronized", revision=state["revision"])


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("prepare", help="仅保存完整 Prompt 与技术契约，等待用户确认")
    p.add_argument("project_name")
    p.add_argument("--output", type=Path, default=Path.cwd())
    p.add_argument("--prompt", type=Path, required=True)
    p.add_argument("--contract", type=Path)
    p = sub.add_parser("revise", help="修改 Prompt 并使旧确认失效")
    p.add_argument("project_dir", type=Path)
    p.add_argument("--prompt", type=Path, required=True)
    p.add_argument("--contract", type=Path)
    p = sub.add_parser("record-confirmation", help="记录已发生的真实用户确认；禁止生成器自批")
    p.add_argument("project_dir", type=Path)
    p.add_argument("--user-message-file", type=Path, required=True)
    p.add_argument("--user-message-ref", required=True)
    p.add_argument("--prompt-sha256", required=True)
    p.add_argument("--contract-sha256", required=True)
    for name in ("check", "status", "sync-manifest"):
        p = sub.add_parser(name)
        p.add_argument("project_dir", type=Path)
    args = parser.parse_args()
    try:
        if args.command == "prepare":
            project = prepare(args.project_name, args.output, args.prompt, args.contract)
            print(project)
            print(json.dumps(load_json(project / "prompt_state.json"), ensure_ascii=False, indent=2))
        elif args.command == "revise":
            print(json.dumps(revise(args.project_dir, args.prompt, args.contract), ensure_ascii=False, indent=2))
        elif args.command == "record-confirmation":
            print(json.dumps(record_confirmation(args.project_dir, args.user_message_file, args.user_message_ref,
                                                 args.prompt_sha256, args.contract_sha256), ensure_ascii=False, indent=2))
        elif args.command == "sync-manifest":
            sync_manifest(args.project_dir)
            print("已同步当前获批契约；请检查并重建模型、预览和截图。")
        elif args.command == "status":
            print(json.dumps(load_json(args.project_dir / "prompt_state.json"), ensure_ascii=False, indent=2))
        else:
            require_approved(args.project_dir, check_components=True)
            print("PASSED: Prompt 已确认且文件、模型约束一致；语义质量仍需人工审核。")
        return 0
    except (PromptGateError, OSError, ValueError, TypeError) as exc:
        print(str(exc), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
