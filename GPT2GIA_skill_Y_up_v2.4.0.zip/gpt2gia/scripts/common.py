#!/usr/bin/env python3
"""Shared geometry and archive helpers for GPT2GIA."""

from __future__ import annotations

import json
import math
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

ALLOWED_TEMPLATE_IDS = {
    10009001,
    10009002,
    10009003,
    10009004,
    10009005,
    10009006,
    10009007,
    10009008,
    10009009,
    10009010,
    10009011,
}
ID_RE = re.compile(r"^[a-z0-9_]+$")
COLOR_RE = re.compile(r"^#[0-9A-Fa-f]{6}$")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")


def is_finite_vector3(value: Any, *, positive: bool = False) -> bool:
    if not isinstance(value, list) or len(value) != 3:
        return False
    if not all(isinstance(item, (int, float)) and not isinstance(item, bool) for item in value):
        return False
    if not all(math.isfinite(float(item)) for item in value):
        return False
    return not positive or all(float(item) > 0 for item in value)


def _rotation_matrix_xyz(rotation: Iterable[float]) -> list[list[float]]:
    rx, ry, rz = (math.radians(float(value)) for value in rotation)
    cx, sx = math.cos(rx), math.sin(rx)
    cy, sy = math.cos(ry), math.sin(ry)
    cz, sz = math.cos(rz), math.sin(rz)
    # Intrinsic XYZ: apply local X, then Y, then Z.
    return [
        [cz * cy, cz * sy * sx - sz * cx, cz * sy * cx + sz * sx],
        [sz * cy, sz * sy * sx + cz * cx, sz * sy * cx - cz * sx],
        [-sy, cy * sx, cy * cx],
    ]


def _mat_vec(matrix: list[list[float]], vector: Iterable[float]) -> list[float]:
    values = list(vector)
    return [sum(row[index] * values[index] for index in range(3)) for row in matrix]


def component_aabb(component: dict[str, Any]) -> tuple[list[float], list[float]]:
    # Y-up 保守包围盒：棱锥/圆锥以体积质心为原点；平面位于局部 XZ。
    # 线框仅计算路径范围，不包含尚未标定的真实线厚；不是实体碰撞包围盒。
    scale = [float(value) for value in component["scale"]]
    template_id = int(component["template_id"])
    if template_id in {10009006, 10009007, 10009009}:
        local_min = [-0.5 * scale[0], -0.25 * scale[1], -0.5 * scale[2]]
        local_max = [0.5 * scale[0], 0.75 * scale[1], 0.5 * scale[2]]
    elif template_id == 10009003:
        local_min = [-0.5 * scale[0], 0.0, -0.5 * scale[2]]
        local_max = [0.5 * scale[0], 0.0, 0.5 * scale[2]]
    else:
        local_min = [-0.5 * value for value in scale]
        local_max = [0.5 * value for value in scale]

    rotation = _rotation_matrix_xyz(component["rotation"])
    position = [float(value) for value in component["position"]]
    points: list[list[float]] = []
    for x in (local_min[0], local_max[0]):
        for y in (local_min[1], local_max[1]):
            for z in (local_min[2], local_max[2]):
                rotated = _mat_vec(rotation, [x, y, z])
                points.append([rotated[index] + position[index] for index in range(3)])
    return (
        [min(point[index] for point in points) for index in range(3)],
        [max(point[index] for point in points) for index in range(3)],
    )


def combined_bounds(components: list[dict[str, Any]]) -> tuple[list[float], list[float]]:
    if not components:
        return ([0.0, 0.0, 0.0], [0.0, 0.0, 0.0])
    boxes = [component_aabb(component) for component in components]
    return (
        [min(box[0][index] for box in boxes) for index in range(3)],
        [max(box[1][index] for box in boxes) for index in range(3)],
    )


def bounds_diagonal(bounds: tuple[list[float], list[float]]) -> float:
    return math.sqrt(sum((bounds[1][index] - bounds[0][index]) ** 2 for index in range(3)))


def aabbs_touch(
    first: tuple[list[float], list[float]],
    second: tuple[list[float], list[float]],
    tolerance: float,
) -> bool:
    return all(
        first[0][axis] <= second[1][axis] + tolerance
        and second[0][axis] <= first[1][axis] + tolerance
        for axis in range(3)
    )


def connection_components(components: list[dict[str, Any]], tolerance: float) -> list[list[str]]:
    if not components:
        return []
    boxes = [component_aabb(component) for component in components]
    adjacency: list[list[int]] = [[] for _ in components]
    for left in range(len(components)):
        for right in range(left + 1, len(components)):
            if aabbs_touch(boxes[left], boxes[right], tolerance):
                adjacency[left].append(right)
                adjacency[right].append(left)
    remaining = set(range(len(components)))
    result: list[list[str]] = []
    while remaining:
        seed = remaining.pop()
        stack = [seed]
        group = [str(components[seed]["id"])]
        while stack:
            current = stack.pop()
            for neighbor in adjacency[current]:
                if neighbor in remaining:
                    remaining.remove(neighbor)
                    stack.append(neighbor)
                    group.append(str(components[neighbor]["id"]))
        result.append(sorted(group))
    return sorted(result, key=lambda item: (-len(item), item))


def normalized_zero_rotation(rotation: list[float], tolerance: float = 1e-7) -> bool:
    for value in rotation:
        wrapped = float(value) % 360.0
        if min(wrapped, 360.0 - wrapped) > tolerance:
            return False
    return True
