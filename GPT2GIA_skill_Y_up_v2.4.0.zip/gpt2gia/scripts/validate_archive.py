#!/usr/bin/env python3
"""Validate GPT2GIA data, transform contracts, assembly, and fragmentation."""

from __future__ import annotations

import argparse
import json
import math
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

from analyze_fragmentation import analyze_project
from validate_reconstruction import validate_reconstruction
from prompt_workflow import inspect_workflow
from common import (
    ALLOWED_TEMPLATE_IDS,
    COLOR_RE,
    ID_RE,
    combined_bounds,
    is_finite_vector3,
    load_json,
    normalized_zero_rotation,
    utc_now,
    write_json,
)


def _error(code: str, message: str, **context: Any) -> dict[str, Any]:
    result = {"code": code, "message": message}
    if context:
        result["context"] = context
    return result


def _mergeable_cuboids(items: list[dict[str, Any]]) -> list[list[str]]:
    pairs: list[list[str]] = []
    for left_index, left in enumerate(items):
        if left.get("template_id") != 10009001 or not normalized_zero_rotation(left.get("rotation", [])):
            continue
        for right in items[left_index + 1 :]:
            if right.get("template_id") != 10009001 or not normalized_zero_rotation(right.get("rotation", [])):
                continue
            if left.get("color", "").upper() != right.get("color", "").upper():
                continue
            matching_axes = []
            touching_axes = []
            for axis in range(3):
                same_center = abs(float(left["position"][axis]) - float(right["position"][axis])) <= 1e-7
                same_scale = abs(float(left["scale"][axis]) - float(right["scale"][axis])) <= 1e-7
                if same_center and same_scale:
                    matching_axes.append(axis)
                distance = abs(float(left["position"][axis]) - float(right["position"][axis]))
                target = 0.5 * (float(left["scale"][axis]) + float(right["scale"][axis]))
                if abs(distance - target) <= max(1e-7, target * 1e-6):
                    touching_axes.append(axis)
            if len(matching_axes) == 2 and len(touching_axes) == 1:
                pairs.append([str(left["id"]), str(right["id"])])
    return pairs


def _valid_bounds(value: Any) -> bool:
    return (
        isinstance(value, dict)
        and is_finite_vector3(value.get("min"))
        and is_finite_vector3(value.get("max"))
        and all(float(value["min"][axis]) < float(value["max"][axis]) for axis in range(3))
    )


def _validate_scene_plan(
    scene_plan: Any,
    group_map: dict[str, dict[str, Any]],
    valid_components: list[dict[str, Any]],
    by_group: dict[str, list[dict[str, Any]]],
    errors: list[dict[str, Any]],
) -> None:
    if not isinstance(scene_plan, dict):
        errors.append(_error("SCENE_PLAN_INCOMPLETE", "scene_plan.json 必须是对象"))
        return
    scope = scene_plan.get("scene_scope")
    if scope not in {"single_object", "multi_object", "environment"}:
        errors.append(_error("SCENE_PLAN_INCOMPLETE", "scene_scope 非法"))

    coordinate = scene_plan.get("coordinate_plan")
    if not isinstance(coordinate, dict):
        errors.append(_error("SCENE_PLAN_INCOMPLETE", "缺少 coordinate_plan"))
        coordinate = {}
    if coordinate.get("planning_status") != "planned":
        errors.append(_error("SCENE_PLAN_INCOMPLETE", "coordinate_plan.planning_status 必须为 planned"))
    if not is_finite_vector3(coordinate.get("world_origin")):
        errors.append(_error("SCENE_PLAN_INCOMPLETE", "world_origin 必须是有限三维向量"))
    ground_y = coordinate.get("ground_y")
    if ground_y is not None and (
        not isinstance(ground_y, (int, float))
        or isinstance(ground_y, bool)
        or not math.isfinite(float(ground_y))
    ):
        errors.append(_error("SCENE_PLAN_INCOMPLETE", "ground_y 必须为有限数值或 null"))
    declared_bounds = coordinate.get("scene_bounds")
    if not _valid_bounds(declared_bounds):
        errors.append(_error("SCENE_PLAN_INCOMPLETE", "scene_bounds 必须具有有限且 min < max 的边界"))
    elif valid_components:
        actual_min, actual_max = combined_bounds(valid_components)
        span = max(
            math.sqrt(
                sum(
                    (float(declared_bounds["max"][axis]) - float(declared_bounds["min"][axis])) ** 2
                    for axis in range(3)
                )
            ),
            1.0,
        )
        tolerance = span * 1e-6
        outside = any(
            actual_min[axis] < float(declared_bounds["min"][axis]) - tolerance
            or actual_max[axis] > float(declared_bounds["max"][axis]) + tolerance
            for axis in range(3)
        )
        if outside:
            errors.append(
                _error(
                    "SCENE_COORDINATE_MISMATCH",
                    "实际组件边界超出 scene_bounds",
                    declared=declared_bounds,
                    actual={"min": actual_min, "max": actual_max},
                )
            )

    scale_reference = coordinate.get("scale_reference")
    if not isinstance(scale_reference, dict):
        errors.append(_error("SCENE_PLAN_INCOMPLETE", "缺少 scale_reference"))
    else:
        value = scale_reference.get("value")
        if (
            scale_reference.get("kind")
            not in {"known_dimension", "human_height", "user_unit", "reference_inferred", "arbitrary"}
            or not isinstance(value, (int, float))
            or isinstance(value, bool)
            or not math.isfinite(float(value))
            or float(value) <= 0
            or scale_reference.get("unit") != "meter"
            or not str(scale_reference.get("basis", "")).strip()
        ):
            errors.append(_error("SCENE_PLAN_INCOMPLETE", "scale_reference 的数值、单位或依据非法"))

    anchors = coordinate.get("anchors")
    anchor_ids: set[str] = set()
    anchored_groups: set[str] = set()
    if not isinstance(anchors, list) or not anchors:
        errors.append(_error("SCENE_PLAN_INCOMPLETE", "至少需要一个命名锚点"))
        anchors = []
    for anchor in anchors:
        if not isinstance(anchor, dict):
            errors.append(_error("SCENE_PLAN_INCOMPLETE", "锚点必须是对象"))
            continue
        anchor_id = anchor.get("anchor_id")
        if not isinstance(anchor_id, str) or not ID_RE.fullmatch(anchor_id) or anchor_id in anchor_ids:
            errors.append(_error("SCENE_PLAN_INCOMPLETE", "锚点 ID 非法或重复", anchor=anchor))
        else:
            anchor_ids.add(anchor_id)
        if not is_finite_vector3(anchor.get("position")) or not str(anchor.get("purpose", "")).strip():
            errors.append(_error("SCENE_PLAN_INCOMPLETE", f"锚点 {anchor_id} 缺少合法位置或用途"))
        group_ids = anchor.get("group_ids")
        if not isinstance(group_ids, list):
            errors.append(_error("SCENE_PLAN_INCOMPLETE", f"锚点 {anchor_id} 的 group_ids 非法"))
            continue
        for group_id in group_ids:
            if group_id not in group_map:
                errors.append(_error("SCENE_COORDINATE_MISMATCH", f"锚点 {anchor_id} 引用了不存在的组 {group_id}"))
            else:
                anchored_groups.add(group_id)

    zones = coordinate.get("zones")
    zone_ids: set[str] = set()
    zoned_groups: set[str] = set()
    if not isinstance(zones, list):
        errors.append(_error("SCENE_PLAN_INCOMPLETE", "zones 必须是数组"))
        zones = []
    if scope in {"multi_object", "environment"} and not zones:
        errors.append(_error("SCENE_PLAN_INCOMPLETE", f"{scope} 至少需要一个空间区域"))
    for zone in zones:
        if not isinstance(zone, dict):
            errors.append(_error("SCENE_PLAN_INCOMPLETE", "区域必须是对象"))
            continue
        zone_id = zone.get("zone_id")
        if not isinstance(zone_id, str) or not ID_RE.fullmatch(zone_id) or zone_id in zone_ids:
            errors.append(_error("SCENE_PLAN_INCOMPLETE", "区域 ID 非法或重复", zone=zone))
        else:
            zone_ids.add(zone_id)
        if not _valid_bounds(zone.get("bounds")) or not str(zone.get("purpose", "")).strip():
            errors.append(_error("SCENE_PLAN_INCOMPLETE", f"区域 {zone_id} 缺少合法边界或用途"))
        group_ids = zone.get("group_ids")
        if not isinstance(group_ids, list):
            errors.append(_error("SCENE_PLAN_INCOMPLETE", f"区域 {zone_id} 的 group_ids 非法"))
            continue
        for group_id in group_ids:
            if group_id not in group_map:
                errors.append(_error("SCENE_COORDINATE_MISMATCH", f"区域 {zone_id} 引用了不存在的组 {group_id}"))
            else:
                zoned_groups.add(group_id)
                items = by_group.get(group_id, [])
                if _valid_bounds(zone.get("bounds")) and items:
                    group_min, group_max = combined_bounds(items)
                    zone_bounds = zone["bounds"]
                    outside = any(
                        group_min[axis] < float(zone_bounds["min"][axis]) - 1e-6
                        or group_max[axis] > float(zone_bounds["max"][axis]) + 1e-6
                        for axis in range(3)
                    )
                    if outside:
                        errors.append(
                            _error(
                                "SCENE_COORDINATE_MISMATCH",
                                f"组 {group_id} 的实际边界超出区域 {zone_id}",
                                group_bounds={"min": group_min, "max": group_max},
                                zone_bounds=zone_bounds,
                            )
                        )
    if scope in {"multi_object", "environment"}:
        unplaced = sorted(set(group_map) - anchored_groups - zoned_groups)
        if unplaced:
            errors.append(
                _error(
                    "SCENE_COORDINATE_MISMATCH",
                    "多物件/环境场景存在未归属锚点或区域的组",
                    group_ids=unplaced,
                )
            )

    camera = scene_plan.get("camera_plan")
    if not isinstance(camera, dict):
        errors.append(_error("SCENE_PLAN_INCOMPLETE", "缺少 camera_plan"))
        camera = {}
    camera_position = camera.get("position")
    camera_target = camera.get("target")
    forward: list[float] | None = None
    if not is_finite_vector3(camera_position) or not is_finite_vector3(camera_target):
        errors.append(_error("SCENE_PLAN_INCOMPLETE", "相机 position 与 target 必须是有限三维向量"))
    else:
        delta = [float(camera_target[axis]) - float(camera_position[axis]) for axis in range(3)]
        length = math.sqrt(sum(value * value for value in delta))
        if length <= 1e-9:
            errors.append(_error("SCENE_PLAN_INCOMPLETE", "相机 position 不能与 target 重合"))
        else:
            forward = [value / length for value in delta]
    fov = camera.get("fov_degrees")
    if (
        not isinstance(fov, (int, float))
        or isinstance(fov, bool)
        or not math.isfinite(float(fov))
        or not 1.0 < float(fov) < 179.0
    ):
        errors.append(_error("SCENE_PLAN_INCOMPLETE", "fov_degrees 必须在 1 到 179 度之间"))

    layers = camera.get("depth_layers")
    if not isinstance(layers, list):
        errors.append(_error("SCENE_PLAN_INCOMPLETE", "depth_layers 必须是数组"))
        layers = []
    minimum_layers = {"single_object": 1, "multi_object": 2, "environment": 3}.get(scope, 1)
    if len(layers) < minimum_layers:
        errors.append(
            _error(
                "DEPTH_HIERARCHY_COLLAPSE",
                f"{scope} 至少需要 {minimum_layers} 个深度层",
                actual=len(layers),
            )
        )
    layer_ids: set[str] = set()
    orders: set[int] = set()
    assigned_groups: dict[str, str] = {}
    ordered_ranges: list[tuple[int, float, float, str]] = []
    layer_purposes: set[str] = set()
    layer_detail_levels: set[str] = set()
    for layer in layers:
        if not isinstance(layer, dict):
            errors.append(_error("SCENE_PLAN_INCOMPLETE", "深度层必须是对象"))
            continue
        layer_id = layer.get("layer_id")
        order = layer.get("order")
        if not isinstance(layer_id, str) or not ID_RE.fullmatch(layer_id) or layer_id in layer_ids:
            errors.append(_error("SCENE_PLAN_INCOMPLETE", "深度层 ID 非法或重复", layer=layer))
        else:
            layer_ids.add(layer_id)
        if not isinstance(order, int) or isinstance(order, bool) or order < 0 or order in orders:
            errors.append(_error("DEPTH_HIERARCHY_COLLAPSE", f"深度层 {layer_id} 的 order 非法或重复"))
        else:
            orders.add(order)
        purpose = layer.get("purpose")
        detail_level = layer.get("detail_level")
        if purpose not in {"framing", "primary_subject", "context", "horizon", "transition"}:
            errors.append(_error("DEPTH_HIERARCHY_COLLAPSE", f"深度层 {layer_id} 的 purpose 非法"))
        else:
            layer_purposes.add(str(purpose))
        if detail_level not in {"high", "medium", "low", "silhouette_only"}:
            errors.append(_error("DEPTH_HIERARCHY_COLLAPSE", f"深度层 {layer_id} 的 detail_level 非法"))
        else:
            layer_detail_levels.add(str(detail_level))
        if not str(layer.get("occlusion_policy", "")).strip():
            errors.append(_error("DEPTH_HIERARCHY_COLLAPSE", f"深度层 {layer_id} 缺少遮挡策略"))
        distance_range = layer.get("distance_range")
        valid_range = (
            isinstance(distance_range, list)
            and len(distance_range) == 2
            and all(
                isinstance(value, (int, float))
                and not isinstance(value, bool)
                and math.isfinite(float(value))
                for value in distance_range
            )
            and 0 <= float(distance_range[0]) < float(distance_range[1])
        )
        if not valid_range:
            errors.append(_error("DEPTH_HIERARCHY_COLLAPSE", f"深度层 {layer_id} 的 distance_range 非法"))
        elif isinstance(order, int):
            ordered_ranges.append((order, float(distance_range[0]), float(distance_range[1]), str(layer_id)))
        screen_range = layer.get("target_screen_fraction")
        if not (
            isinstance(screen_range, list)
            and len(screen_range) == 2
            and all(isinstance(value, (int, float)) and not isinstance(value, bool) for value in screen_range)
            and 0 <= float(screen_range[0]) < float(screen_range[1]) <= 1
        ):
            errors.append(_error("DEPTH_HIERARCHY_COLLAPSE", f"深度层 {layer_id} 的 target_screen_fraction 非法"))
        group_ids = layer.get("group_ids")
        if not isinstance(group_ids, list) or not group_ids:
            errors.append(_error("DEPTH_HIERARCHY_COLLAPSE", f"深度层 {layer_id} 必须包含至少一个组"))
            group_ids = []
        for group_id in group_ids:
            if group_id not in group_map:
                errors.append(_error("DEPTH_HIERARCHY_COLLAPSE", f"深度层 {layer_id} 引用了不存在的组 {group_id}"))
                continue
            if group_id in assigned_groups:
                errors.append(
                    _error(
                        "DEPTH_HIERARCHY_COLLAPSE",
                        f"组 {group_id} 同时属于多个主深度层",
                        first=assigned_groups[group_id],
                        second=layer_id,
                    )
                )
            else:
                assigned_groups[group_id] = str(layer_id)
            items = by_group.get(group_id, [])
            if forward is not None and valid_range and items:
                bounds = combined_bounds(items)
                center = [(bounds[0][axis] + bounds[1][axis]) * 0.5 for axis in range(3)]
                depth = sum(
                    (center[axis] - float(camera_position[axis])) * forward[axis]
                    for axis in range(3)
                )
                tolerance = max(1e-6, (float(distance_range[1]) - float(distance_range[0])) * 0.01)
                if depth < float(distance_range[0]) - tolerance or depth > float(distance_range[1]) + tolerance:
                    errors.append(
                        _error(
                            "SCENE_COORDINATE_MISMATCH",
                            f"组 {group_id} 的实际相机视线深度不在层 {layer_id} 范围内",
                            depth=depth,
                            distance_range=distance_range,
                        )
                    )
    missing_layer_groups = sorted(set(group_map) - set(assigned_groups))
    if missing_layer_groups:
        errors.append(
            _error(
                "DEPTH_HIERARCHY_COLLAPSE",
                "存在未分配主深度层的组",
                group_ids=missing_layer_groups,
            )
        )
    sorted_ranges = sorted(ordered_ranges)
    for previous, current in zip(sorted_ranges, sorted_ranges[1:]):
        if current[1] < previous[1] or current[2] < previous[2]:
            errors.append(
                _error(
                    "DEPTH_HIERARCHY_COLLAPSE",
                    "深度层距离未随 order 单调增加",
                    previous=previous[3],
                    current=current[3],
                )
            )
    if scope == "environment" and (
        len(layer_purposes) < 2 or len(layer_detail_levels) < 2
    ):
        errors.append(
            _error(
                "DEPTH_HIERARCHY_COLLAPSE",
                "环境场景的深度层必须具有不同构图职责和至少两种细节等级",
            )
        )

    component_map = {str(component["id"]): component for component in valid_components}
    repeat_policy = scene_plan.get("repeat_policy")
    if not isinstance(repeat_policy, dict):
        errors.append(_error("REPETITION_CONTRACT_ERROR", "缺少 repeat_policy"))
        repeat_policy = {}
    repeat_status = repeat_policy.get("status")
    repeat_sets = repeat_policy.get("sets")
    if not isinstance(repeat_sets, list):
        errors.append(_error("REPETITION_CONTRACT_ERROR", "repeat_policy.sets 必须是数组"))
        repeat_sets = []
    if repeat_status == "not_present" and repeat_sets:
        errors.append(_error("REPETITION_CONTRACT_ERROR", "status 为 not_present 时 sets 必须为空"))
    elif repeat_status == "planned" and not repeat_sets:
        errors.append(_error("REPETITION_CONTRACT_ERROR", "status 为 planned 时至少需要一个重复集合"))
    elif repeat_status not in {"not_present", "planned"}:
        errors.append(_error("REPETITION_CONTRACT_ERROR", "repeat_policy.status 非法"))
    repeat_ids: set[str] = set()
    for repeat_set in repeat_sets:
        if not isinstance(repeat_set, dict):
            errors.append(_error("REPETITION_CONTRACT_ERROR", "重复集合必须是对象"))
            continue
        repeat_id = repeat_set.get("repeat_id")
        if not isinstance(repeat_id, str) or not ID_RE.fullmatch(repeat_id) or repeat_id in repeat_ids:
            errors.append(_error("REPETITION_CONTRACT_ERROR", "repeat_id 非法或重复", repeat_set=repeat_set))
        else:
            repeat_ids.add(repeat_id)
        if repeat_set.get("placement_mode") not in {"linear", "grid", "radial", "path", "scatter", "explicit"}:
            errors.append(_error("REPETITION_CONTRACT_ERROR", f"{repeat_id} 的 placement_mode 非法"))
        if repeat_set.get("topology_policy") not in {"shared", "variant"}:
            errors.append(_error("REPETITION_CONTRACT_ERROR", f"{repeat_id} 的 topology_policy 非法"))
        spacing = repeat_set.get("spacing")
        if not isinstance(spacing, dict):
            errors.append(_error("REPETITION_CONTRACT_ERROR", f"{repeat_id} 缺少 spacing"))
        else:
            minimum = spacing.get("minimum")
            if (
                not isinstance(minimum, (int, float))
                or isinstance(minimum, bool)
                or not math.isfinite(float(minimum))
                or float(minimum) < 0
                or not str(spacing.get("rhythm", "")).strip()
            ):
                errors.append(_error("REPETITION_CONTRACT_ERROR", f"{repeat_id} 的间距或节奏非法"))
        instances = repeat_set.get("instances")
        if not isinstance(instances, list) or len(instances) < 2:
            errors.append(_error("REPETITION_CONTRACT_ERROR", f"{repeat_id} 至少需要两个实例"))
            instances = []
        instance_map: dict[str, list[str]] = {}
        member_owners: dict[str, str] = {}
        for instance in instances:
            if not isinstance(instance, dict):
                errors.append(_error("REPETITION_CONTRACT_ERROR", f"{repeat_id} 的实例必须是对象"))
                continue
            instance_id = instance.get("instance_id")
            members = instance.get("member_component_ids")
            if (
                not isinstance(instance_id, str)
                or not ID_RE.fullmatch(instance_id)
                or instance_id in instance_map
            ):
                errors.append(_error("REPETITION_CONTRACT_ERROR", f"{repeat_id} 的 instance_id 非法或重复"))
                continue
            if not isinstance(members, list) or not members or len(set(members)) != len(members):
                errors.append(_error("REPETITION_CONTRACT_ERROR", f"{repeat_id}/{instance_id} 的成员列表非法"))
                members = []
            instance_map[instance_id] = [str(member) for member in members]
            for member in members:
                if member not in component_map:
                    errors.append(_error("REPETITION_CONTRACT_ERROR", f"{repeat_id}/{instance_id} 引用了不存在的组件 {member}"))
                if member in member_owners:
                    errors.append(
                        _error(
                            "REPETITION_CONTRACT_ERROR",
                            f"{repeat_id} 中组件 {member} 同时属于多个实例",
                            first=member_owners[member],
                            second=instance_id,
                        )
                    )
                else:
                    member_owners[str(member)] = instance_id
        prototype = repeat_set.get("prototype_instance_id")
        if prototype not in instance_map:
            errors.append(_error("REPETITION_CONTRACT_ERROR", f"{repeat_id} 的原型实例不存在：{prototype}"))
        elif repeat_set.get("topology_policy") == "shared":
            prototype_signature = Counter(
                component_map[member]["template_id"]
                for member in instance_map[prototype]
                if member in component_map
            )
            for instance_id, members in instance_map.items():
                signature = Counter(
                    component_map[member]["template_id"]
                    for member in members
                    if member in component_map
                )
                if signature != prototype_signature:
                    errors.append(
                        _error(
                            "REPETITION_CONTRACT_ERROR",
                            f"{repeat_id}/{instance_id} 与原型的基元拓扑计数不一致",
                        )
                    )
        if isinstance(spacing, dict) and isinstance(spacing.get("minimum"), (int, float)):
            minimum_spacing = float(spacing["minimum"])
            instance_centers: list[tuple[str, list[float]]] = []
            for instance_id, members in instance_map.items():
                member_components = [component_map[member] for member in members if member in component_map]
                if not member_components:
                    continue
                bounds = combined_bounds(member_components)
                instance_centers.append(
                    (
                        instance_id,
                        [(bounds[0][axis] + bounds[1][axis]) * 0.5 for axis in range(3)],
                    )
                )
            for left_index, (left_id, left_center) in enumerate(instance_centers):
                for right_id, right_center in instance_centers[left_index + 1 :]:
                    distance = math.sqrt(
                        sum(
                            (left_center[axis] - right_center[axis]) ** 2
                            for axis in range(3)
                        )
                    )
                    if distance + 1e-6 < minimum_spacing:
                        errors.append(
                            _error(
                                "REPETITION_CONTRACT_ERROR",
                                f"{repeat_id} 的实例间距小于声明下限",
                                first=left_id,
                                second=right_id,
                                distance=distance,
                                minimum=minimum_spacing,
                            )
                        )
        if not isinstance(repeat_set.get("invariants"), list) or not repeat_set.get("invariants"):
            errors.append(_error("REPETITION_CONTRACT_ERROR", f"{repeat_id} 缺少不可变量"))
        variation = repeat_set.get("variation")
        if not isinstance(variation, dict):
            errors.append(_error("REPETITION_CONTRACT_ERROR", f"{repeat_id} 缺少 variation"))
        else:
            position_jitter = variation.get("position_jitter")
            rotation_jitter = variation.get("rotation_jitter")
            scale_range = variation.get("uniform_scale_range")
            if not (
                isinstance(variation.get("seed"), int)
                and not isinstance(variation.get("seed"), bool)
                and is_finite_vector3(position_jitter)
                and all(float(value) >= 0 for value in position_jitter)
                and is_finite_vector3(rotation_jitter)
                and all(float(value) >= 0 for value in rotation_jitter)
                and isinstance(scale_range, list)
                and len(scale_range) == 2
                and all(
                    isinstance(value, (int, float))
                    and not isinstance(value, bool)
                    and math.isfinite(float(value))
                    for value in scale_range
                )
                and 0 < float(scale_range[0]) <= float(scale_range[1])
                and variation.get("color_policy") in {"fixed", "palette", "controlled_shift"}
            ):
                errors.append(_error("REPETITION_CONTRACT_ERROR", f"{repeat_id} 的 variation 参数非法"))

    surface_policy = scene_plan.get("surface_content_policy")
    if not isinstance(surface_policy, dict):
        errors.append(_error("SURFACE_CONTENT_MISMATCH", "缺少 surface_content_policy"))
        surface_policy = {}
    surface_status = surface_policy.get("status")
    surface_items = surface_policy.get("items")
    if not isinstance(surface_items, list):
        errors.append(_error("SURFACE_CONTENT_MISMATCH", "surface_content_policy.items 必须是数组"))
        surface_items = []
    if surface_status == "not_present" and surface_items:
        errors.append(_error("SURFACE_CONTENT_MISMATCH", "status 为 not_present 时 items 必须为空"))
    elif surface_status == "planned" and not surface_items:
        errors.append(_error("SURFACE_CONTENT_MISMATCH", "status 为 planned 时至少需要一项表面内容"))
    elif surface_status not in {"not_present", "planned"}:
        errors.append(_error("SURFACE_CONTENT_MISMATCH", "surface_content_policy.status 非法"))
    content_ids: set[str] = set()
    for item in surface_items:
        if not isinstance(item, dict):
            errors.append(_error("SURFACE_CONTENT_MISMATCH", "表面内容项必须是对象"))
            continue
        content_id = item.get("content_id")
        if not isinstance(content_id, str) or not ID_RE.fullmatch(content_id) or content_id in content_ids:
            errors.append(_error("SURFACE_CONTENT_MISMATCH", "content_id 非法或重复", item=item))
        else:
            content_ids.add(content_id)
        if item.get("host_group_id") not in group_map:
            errors.append(_error("SURFACE_CONTENT_MISMATCH", f"{content_id} 的宿主组不存在"))
        strategy = item.get("strategy")
        salience = item.get("salience")
        if item.get("content_type") not in {"literal_text", "symbol", "image_texture", "pattern", "color_region"}:
            errors.append(_error("SURFACE_CONTENT_MISMATCH", f"{content_id} 的 content_type 非法"))
        if salience not in {"critical", "high", "medium", "low"}:
            errors.append(_error("SURFACE_CONTENT_MISMATCH", f"{content_id} 的 salience 非法"))
        if item.get("readability") not in {"readable", "recognizable", "decorative", "not_visible"}:
            errors.append(_error("SURFACE_CONTENT_MISMATCH", f"{content_id} 的 readability 非法"))
        if strategy not in {
            "primitive_geometry",
            "color_block_geometry",
            "simplified_symbol",
            "dominant_color_plane",
            "omit",
        }:
            errors.append(_error("SURFACE_CONTENT_MISMATCH", f"{content_id} 的 strategy 非法"))
        budget = item.get("component_budget")
        if (
            not isinstance(budget, int)
            or isinstance(budget, bool)
            or budget < 0
            or not str(item.get("source_semantics", "")).strip()
            or not str(item.get("reason", "")).strip()
        ):
            errors.append(_error("SURFACE_CONTENT_MISMATCH", f"{content_id} 的预算、语义或理由非法"))
        targets = item.get("target_component_ids")
        if not isinstance(targets, list):
            errors.append(_error("SURFACE_CONTENT_MISMATCH", f"{content_id} 的 target_component_ids 非法"))
            targets = []
        for component_id in targets:
            if component_id not in component_map:
                errors.append(_error("SURFACE_CONTENT_MISMATCH", f"{content_id} 引用了不存在的组件 {component_id}"))
        if salience in {"critical", "high"} and strategy == "omit":
            errors.append(_error("SURFACE_CONTENT_MISMATCH", f"{content_id} 为高显著度内容，不允许省略"))
        if strategy == "omit":
            if targets or budget != 0:
                errors.append(_error("SURFACE_CONTENT_MISMATCH", f"{content_id} 省略时目标组件必须为空且预算为 0"))
        elif not targets:
            errors.append(_error("SURFACE_CONTENT_MISMATCH", f"{content_id} 未绑定实际组件"))
        elif isinstance(budget, int) and len(targets) > budget:
            errors.append(
                _error(
                    "SURFACE_CONTENT_MISMATCH",
                    f"{content_id} 使用 {len(targets)} 个组件，超过预算 {budget}",
                )
            )
        if (
            item.get("content_type") == "literal_text"
            and item.get("readability") == "readable"
            and strategy != "primitive_geometry"
        ):
            errors.append(_error("SURFACE_CONTENT_MISMATCH", f"{content_id} 要求逐字可读，必须使用基元文字"))


def validate_project(project: Path) -> dict[str, Any]:
    project = project.resolve()
    errors: list[dict[str, Any]] = inspect_workflow(project, check_components=True)
    checks: list[dict[str, Any]] = [{"name": "prompt_approval", "status": "failed" if errors else "passed"}]
    required = (
        "prompt.md",
        "prompt_contract.json",
        "prompt_state.json",
        "prompt_log.jsonl",
        "components.json",
        "assembly.json",
        "scene_plan.json",
        "reference_analysis.json",
        "decomposition.json",
        "style_profile.json",
        "manifest.json",
        "primitive_catalog.json",
    )
    for filename in required:
        if not (project / filename).is_file():
            errors.append(_error("ARTIFACT_INCOMPLETE", f"缺少 {filename}"))
    if errors:
        result = {
            "schema_version": "2.2.0",
            "status": "FAILED",
            "generated_at": utc_now(),
            "errors": errors,
            "checks": checks,
            "manual_reviews": [],
        }
        # 审阅阶段只返回诊断，不把规划目录写成半初始化工程。
        if (project / "manifest.json").is_file():
            write_json(project / "validation.json", result)
        return result

    try:
        components_data = load_json(project / "components.json")
        assembly = load_json(project / "assembly.json")
        scene_plan = load_json(project / "scene_plan.json")
        reference_analysis = load_json(project / "reference_analysis.json")
        decomposition = load_json(project / "decomposition.json")
        style_profile = load_json(project / "style_profile.json")
        manifest = load_json(project / "manifest.json")
        catalog = load_json(project / "primitive_catalog.json")
    except (OSError, json.JSONDecodeError) as exc:
        result = {
            "schema_version": "2.2.0",
            "status": "FAILED",
            "generated_at": utc_now(),
            "errors": [_error("ARTIFACT_INCOMPLETE", f"JSON 无法解析：{exc}")],
            "checks": checks,
            "manual_reviews": [],
        }
        write_json(project / "validation.json", result)
        return result

    contract = manifest.get("transform_contract", {})
    expected_contract = {
        "origin": "geometric_center",
        "rotation_unit": "degree",
        "rotation_order": "intrinsic_xyz",
        "transform_order": "scale_rotate_translate",
    }
    for key, expected in expected_contract.items():
        if contract.get(key) != expected:
            errors.append(
                _error(
                    "TRANSFORM_CONTRACT_ERROR",
                    f"transform_contract.{key} 必须为 {expected}",
                    actual=contract.get(key),
                )
            )

    catalog_ids = {
        item.get("template_id") for item in catalog.get("primitives", []) if isinstance(item, dict)
    }
    if catalog.get("origin_contract") != "geometric_center" or catalog_ids != ALLOWED_TEMPLATE_IDS:
        errors.append(_error("TRANSFORM_CONTRACT_ERROR", "primitive_catalog 与标准基元或几何中心契约不一致"))

    global_allowed = set(manifest.get("allowed_template_ids", []))
    if not global_allowed or not global_allowed <= ALLOWED_TEMPLATE_IDS:
        errors.append(_error("REPRESENTATION_MISMATCH", "manifest.allowed_template_ids 含非法值或为空"))

    groups = assembly.get("groups")
    relationships = assembly.get("relationships")
    if not isinstance(groups, list) or not isinstance(relationships, list):
        errors.append(_error("ARTIFACT_INCOMPLETE", "assembly.json 必须包含 groups 与 relationships 数组"))
        groups = []
        relationships = []
    if not groups:
        errors.append(_error("ARTIFACT_INCOMPLETE", "assembly.json 至少需要一个几何意图组"))
    group_map: dict[str, dict[str, Any]] = {}
    for group in groups:
        group_id = group.get("group_id") if isinstance(group, dict) else None
        if not isinstance(group_id, str) or not ID_RE.fullmatch(group_id):
            errors.append(_error("ARTIFACT_INCOMPLETE", "group_id 非法", group=group))
            continue
        if group_id in group_map:
            errors.append(_error("ARTIFACT_INCOMPLETE", f"重复 group_id：{group_id}"))
            continue
        group_map[group_id] = group
        if group.get("geometry_role") not in {"volume", "shell", "surface", "frame", "connector", "detail"}:
            errors.append(_error("INTENT_COVERAGE_FAILURE", f"{group_id} 缺少合法 geometry_role"))
        allowed = set(group.get("allowed_template_ids", []))
        if not allowed or not allowed <= global_allowed:
            errors.append(_error("REPRESENTATION_MISMATCH", f"{group_id} 的允许基元不属于全局允许范围"))
        priority = group.get("primitive_priority")
        if (
            not isinstance(priority, list)
            or len(priority) != len(set(priority))
            or set(priority) != allowed
        ):
            errors.append(
                _error(
                    "PRIMITIVE_PRIORITY_VIOLATION",
                    f"{group_id} 的 primitive_priority 必须是 allowed_template_ids 的完整无重复排列",
                )
            )
        if not str(group.get("primitive_priority_notes", "")).strip():
            errors.append(_error("PRIMITIVE_PRIORITY_VIOLATION", f"{group_id} 缺少 primitive_priority_notes"))
        budget = group.get("primitive_budget", {})
        if not isinstance(budget.get("min"), int) or not isinstance(budget.get("max"), int):
            errors.append(_error("ARTIFACT_INCOMPLETE", f"{group_id} 的 primitive_budget 非法"))
        elif budget["min"] < 0 or budget["max"] < max(1, budget["min"]):
            errors.append(_error("ARTIFACT_INCOMPLETE", f"{group_id} 的 primitive_budget 范围非法"))

    for relation in relationships:
        if relation.get("from_group") not in group_map or relation.get("to_group") not in group_map:
            errors.append(_error("DISCONNECTED_ASSEMBLY", "关系引用了不存在的组", relation=relation))
        if relation.get("type") not in {"covers", "attaches_to", "connects", "supports", "mirrors"}:
            errors.append(_error("ARTIFACT_INCOMPLETE", "关系类型非法", relation=relation))

    components = components_data.get("components")
    if not isinstance(components, list):
        errors.append(_error("ARTIFACT_INCOMPLETE", "components.json 必须包含 components 数组"))
        components = []
    if not components:
        errors.append(_error("ARTIFACT_INCOMPLETE", "components.json 至少需要一个组件"))
    seen_ids: set[str] = set()
    by_group: dict[str, list[dict[str, Any]]] = defaultdict(list)
    valid_components: list[dict[str, Any]] = []
    signatures: dict[tuple[Any, ...], list[str]] = defaultdict(list)
    for component in components:
        if not isinstance(component, dict):
            errors.append(_error("ARTIFACT_INCOMPLETE", "组件必须是对象"))
            continue
        component_id = component.get("id")
        if not isinstance(component_id, str) or not ID_RE.fullmatch(component_id):
            errors.append(_error("ARTIFACT_INCOMPLETE", "组件 id 非法", component=component))
            continue
        if component_id in seen_ids:
            errors.append(_error("REDUNDANT_PRIMITIVES", f"重复组件 id：{component_id}"))
            continue
        seen_ids.add(component_id)
        group_id = component.get("group_id")
        if group_id not in group_map:
            errors.append(_error("ARTIFACT_INCOMPLETE", f"{component_id} 引用了不存在的组 {group_id}"))
        template_id = component.get("template_id")
        if template_id not in ALLOWED_TEMPLATE_IDS or template_id not in global_allowed:
            errors.append(_error("REPRESENTATION_MISMATCH", f"{component_id} 使用了未允许的基元 {template_id}"))
        elif group_id in group_map and template_id not in set(group_map[group_id].get("allowed_template_ids", [])):
            errors.append(_error("REPRESENTATION_MISMATCH", f"{component_id} 的基元不在所属组允许范围"))
        for field in ("position", "rotation"):
            if not is_finite_vector3(component.get(field)):
                errors.append(_error("TRANSFORM_CONTRACT_ERROR", f"{component_id}.{field} 必须是有限三维向量"))
        if not is_finite_vector3(component.get("scale"), positive=True):
            errors.append(_error("TRANSFORM_CONTRACT_ERROR", f"{component_id}.scale 必须是有限正三维向量"))
        color = component.get("color")
        if not isinstance(color, str) or not COLOR_RE.fullmatch(color):
            errors.append(_error("ARTIFACT_INCOMPLETE", f"{component_id}.color 必须为 #RRGGBB"))
        parent_id = component.get("parent_id")
        if parent_id is not None and (not isinstance(parent_id, str) or not ID_RE.fullmatch(parent_id)):
            errors.append(_error("ARTIFACT_INCOMPLETE", f"{component_id}.parent_id 非法"))
        if all(
            (
                template_id in ALLOWED_TEMPLATE_IDS,
                is_finite_vector3(component.get("position")),
                is_finite_vector3(component.get("rotation")),
                is_finite_vector3(component.get("scale"), positive=True),
                isinstance(color, str) and COLOR_RE.fullmatch(color),
            )
        ):
            valid_components.append(component)
            by_group[str(group_id)].append(component)
            signature = (
                template_id,
                tuple(round(float(value), 9) for value in component["position"]),
                tuple(round(float(value), 9) for value in component["rotation"]),
                tuple(round(float(value), 9) for value in component["scale"]),
                color.upper(),
            )
            signatures[signature].append(component_id)

    for component in valid_components:
        parent_id = component.get("parent_id")
        if parent_id is not None and parent_id not in seen_ids:
            errors.append(_error("ARTIFACT_INCOMPLETE", f"{component['id']} 的 parent_id 不存在：{parent_id}"))

    duplicate_sets = [ids for ids in signatures.values() if len(ids) > 1]
    if duplicate_sets:
        errors.append(_error("REDUNDANT_PRIMITIVES", "存在变换与颜色完全相同的重复组件", duplicates=duplicate_sets))
    for group_id, items in by_group.items():
        mergeable = _mergeable_cuboids(items)
        if mergeable:
            errors.append(_error("REDUNDANT_PRIMITIVES", f"{group_id} 存在可无损合并的相邻长方体", pairs=mergeable))

    counts = Counter(component.get("group_id") for component in components if isinstance(component, dict))
    for group_id, group in group_map.items():
        budget = group.get("primitive_budget", {})
        count = counts.get(group_id, 0)
        if isinstance(budget.get("min"), int) and count < budget["min"]:
            errors.append(_error("INTENT_COVERAGE_FAILURE", f"{group_id} 组件数 {count} 低于预算下限 {budget['min']}"))
        if isinstance(budget.get("max"), int) and count > budget["max"]:
            errors.append(_error("OVER_FRAGMENTATION", f"{group_id} 组件数 {count} 超过预算上限 {budget['max']}"))

    _validate_scene_plan(scene_plan, group_map, valid_components, by_group, errors)
    errors.extend(
        validate_reconstruction(
            reference_analysis,
            decomposition,
            style_profile,
            scene_plan,
            group_map,
            valid_components,
            by_group,
        )
    )

    fragmentation = analyze_project(project)
    write_json(project / "fragmentation.json", fragmentation)
    for group_report in fragmentation["groups"]:
        for flag in group_report["flags"]:
            errors.append(
                _error(flag, f"{group_report['group_id']} 命中 {flag}", metrics=group_report)
            )

    previous = {}
    validation_path = project / "validation.json"
    if validation_path.is_file():
        try:
            previous = load_json(validation_path)
        except (OSError, json.JSONDecodeError):
            previous = {}
    old_reviews = {
        item.get("code"): item
        for item in previous.get("manual_reviews", [])
        if isinstance(item, dict) and isinstance(item.get("code"), str)
    }
    manual_codes = (
        "REPRESENTATION_MISMATCH",
        "INTENT_COVERAGE_FAILURE",
        "SILHOUETTE_MISMATCH",
        "MULTIVIEW_FUSION_INCOMPLETE",
        "OCCLUSION_INFERENCE_CONFLICT",
        "REAL_SCALE_UNSUPPORTED",
        "DECOMPOSITION_CONTRACT_ERROR",
        "LOW_POLY_STYLE_VIOLATION",
        "SCENE_COORDINATE_MISMATCH",
        "DEPTH_HIERARCHY_COLLAPSE",
        "REPETITION_CONTRACT_ERROR",
        "SURFACE_CONTENT_MISMATCH",
        "PRIMITIVE_PRIORITY_VIOLATION",
        "OUTPUT_SUBSTITUTION",
    )
    manual_reviews = []
    for code in manual_codes:
        old = old_reviews.get(code, {})
        status = old.get("status", "pending")
        if status not in {"pending", "passed", "failed"}:
            status = "pending"
        evidence = str(old.get("evidence", "")).strip()
        if status == "passed" and len(evidence) < 10:
            status = "pending"
        manual_reviews.append(
            {"code": code, "status": status, "evidence": evidence}
        )
    if errors or any(item["status"] == "failed" for item in manual_reviews):
        status = "FAILED"
    elif any(item["status"] == "pending" for item in manual_reviews):
        status = "NEEDS_REVIEW"
    else:
        status = "PASSED"
    checks.extend(
        [
            {"name": "transform_contract", "status": "passed" if not any(item["code"] == "TRANSFORM_CONTRACT_ERROR" for item in errors) else "failed"},
            {"name": "primitive_and_group_contract", "status": "passed" if not any(item["code"] in {"REPRESENTATION_MISMATCH", "ARTIFACT_INCOMPLETE"} for item in errors) else "failed"},
            {"name": "scene_coordinate_and_depth", "status": "passed" if not any(item["code"] in {"SCENE_PLAN_INCOMPLETE", "SCENE_COORDINATE_MISMATCH", "DEPTH_HIERARCHY_COLLAPSE"} for item in errors) else "failed"},
            {"name": "multiview_occlusion_and_scale", "status": "passed" if not any(item["code"] in {"MULTIVIEW_FUSION_INCOMPLETE", "OCCLUSION_INFERENCE_CONFLICT", "REAL_SCALE_UNSUPPORTED"} for item in errors) else "failed"},
            {"name": "decomposition", "status": "passed" if not any(item["code"] == "DECOMPOSITION_CONTRACT_ERROR" for item in errors) else "failed"},
            {"name": "low_poly_style", "status": "passed" if not any(item["code"] == "LOW_POLY_STYLE_VIOLATION" for item in errors) else "failed"},
            {"name": "repeat_and_surface_content", "status": "passed" if not any(item["code"] in {"REPETITION_CONTRACT_ERROR", "SURFACE_CONTENT_MISMATCH"} for item in errors) else "failed"},
            {"name": "primitive_priority", "status": "passed" if not any(item["code"] == "PRIMITIVE_PRIORITY_VIOLATION" for item in errors) else "failed"},
            {"name": "fragmentation_and_connectivity", "status": "passed" if not any(item["code"] in {"OVER_FRAGMENTATION", "GRID_FRAGMENTATION", "SCALE_HIERARCHY_COLLAPSE", "DISCONNECTED_ASSEMBLY"} for item in errors) else "failed"},
            {"name": "redundancy", "status": "passed" if not any(item["code"] == "REDUNDANT_PRIMITIVES" for item in errors) else "failed"},
        ]
    )
    result = {
        "schema_version": "2.2.0",
        "status": status,
        "generated_at": utc_now(),
        "component_count": len(components),
        "group_count": len(groups),
        "checks": checks,
        "errors": errors,
        "manual_reviews": manual_reviews,
    }
    write_json(validation_path, result)
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("project_dir", type=Path)
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()
    result = validate_project(args.project_dir)
    print(f"{result['status']}: {len(result['errors'])} automatic error(s)")
    if args.strict and result["status"] != "PASSED":
        return 1
    return 0 if not result["errors"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
