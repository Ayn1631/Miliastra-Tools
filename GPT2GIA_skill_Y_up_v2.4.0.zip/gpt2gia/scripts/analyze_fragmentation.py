#!/usr/bin/env python3
"""Analyze scale hierarchy, micro components, grids, and connectivity."""

from __future__ import annotations

import argparse
import math
import statistics
from collections import defaultdict
from pathlib import Path
from typing import Any

from common import combined_bounds, bounds_diagonal, connection_components, load_json, utc_now, write_json


def _regular_axis(values: list[float]) -> bool:
    unique = sorted(set(round(value, 6) for value in values))
    if len(unique) < 4:
        return False
    differences = [
        unique[index + 1] - unique[index]
        for index in range(len(unique) - 1)
        if unique[index + 1] - unique[index] > 1e-8
    ]
    if len(differences) < 3:
        return False
    median = statistics.median(differences)
    if median <= 1e-8:
        return False
    return max(abs(value - median) for value in differences) / median <= 0.08


def _grid_members(components: list[dict[str, Any]], minimum: int) -> set[str]:
    buckets: dict[tuple[Any, ...], list[dict[str, Any]]] = defaultdict(list)
    for component in components:
        key = (
            component["template_id"],
            component["color"].upper(),
            *(round(float(value), 4) for value in component["scale"]),
        )
        buckets[key].append(component)
    result: set[str] = set()
    for bucket in buckets.values():
        if len(bucket) < minimum:
            continue
        if any(_regular_axis([float(item["position"][axis]) for item in bucket]) for axis in range(3)):
            result.update(str(item["id"]) for item in bucket)
    return result


def analyze_project(project: Path) -> dict[str, Any]:
    project = project.resolve()
    manifest = load_json(project / "manifest.json")
    components_data = load_json(project / "components.json")
    assembly = load_json(project / "assembly.json")
    thresholds = manifest.get("validation", {})
    by_group: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for component in components_data.get("components", []):
        by_group[str(component.get("group_id", ""))].append(component)

    reports = []
    for group in assembly.get("groups", []):
        group_id = str(group["group_id"])
        items = by_group.get(group_id, [])
        bounds = combined_bounds(items)
        diagonal = max(bounds_diagonal(bounds), 1e-9)
        extent_ratio = float(thresholds.get("micro_extent_ratio", 0.025))
        micro_ids = [
            str(item["id"])
            for item in items
            if max(float(value) for value in item["scale"]) < diagonal * extent_ratio
        ]
        micro_fraction = len(micro_ids) / len(items) if items else 0.0
        sizes = [max(float(value) for value in item["scale"]) for item in items]
        maximum = max(sizes, default=0.0)
        scale_bands = sorted(
            {
                min(12, int(math.floor(math.log2(maximum / max(size, 1e-12)))))
                for size in sizes
            }
        ) if maximum > 0 else []
        grid_ids = sorted(
            _grid_members(items, int(thresholds.get("grid_bucket_min_count", 12)))
        )
        grid_fraction = len(grid_ids) / len(items) if items else 0.0
        tolerance = diagonal * float(thresholds.get("connection_tolerance_ratio", 0.015))
        connected = connection_components(items, tolerance)
        flags = []
        if micro_fraction > float(thresholds.get("max_micro_fraction", 0.35)):
            flags.append("OVER_FRAGMENTATION")
        if grid_fraction > float(thresholds.get("max_grid_fraction", 0.4)):
            flags.append("GRID_FRAGMENTATION")
        if (
            len(items) >= int(thresholds.get("scale_hierarchy_min_count", 20))
            and len(scale_bands) < int(thresholds.get("minimum_scale_bands", 3))
        ):
            flags.append("SCALE_HIERARCHY_COLLAPSE")
        if group.get("continuity") == "continuous" and len(connected) > 1:
            flags.append("DISCONNECTED_ASSEMBLY")
        reports.append(
            {
                "group_id": group_id,
                "component_count": len(items),
                "bounds": {"min": bounds[0], "max": bounds[1]},
                "diagonal": diagonal,
                "micro_component_ids": micro_ids,
                "micro_fraction": micro_fraction,
                "scale_bands": scale_bands,
                "grid_component_ids": grid_ids,
                "grid_fraction": grid_fraction,
                "connection_components": connected,
                "flags": flags,
            }
        )
    return {
        "schema_version": "2.2.0",
        "generated_at": utc_now(),
        "groups": reports,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("project_dir", type=Path)
    args = parser.parse_args()
    report = analyze_project(args.project_dir)
    target = args.project_dir.resolve() / "fragmentation.json"
    write_json(target, report)
    print(target)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
