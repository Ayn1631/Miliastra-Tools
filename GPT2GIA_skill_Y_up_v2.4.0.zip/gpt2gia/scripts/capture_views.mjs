#!/usr/bin/env node
/**
 * Capture the bundled viewer with Playwright, or execute the same viewer.js
 * through @napi-rs/canvas when no browser executable is available.
 */

import { createRequire } from "node:module";
import { appendFile, readFile, readdir, writeFile } from "node:fs/promises";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";
import vm from "node:vm";

const require = createRequire(import.meta.url);
const args = process.argv.slice(2);
if (!args.length) {
  console.error("用法：capture_views.mjs <project_dir> [--step <group_id> | --final]");
  process.exit(2);
}
const project = resolve(args[0]);
const stepIndex = args.indexOf("--step");
const finalMode = args.includes("--final");
const stepGroup = stepIndex >= 0 ? args[stepIndex + 1] : null;
if ((!stepGroup && !finalMode) || (stepGroup && finalMode)) {
  console.error("必须且只能指定 --step <group_id> 或 --final");
  process.exit(2);
}
if (stepGroup && !/^[a-z0-9_]+$/.test(stepGroup)) {
  console.error("group_id 必须使用小写英文、数字和下划线");
  process.exit(2);
}

const scriptDir = dirname(fileURLToPath(import.meta.url));
const python = process.env.GPT2GIA_PYTHON || (process.platform === "win32" ? "python" : "python3");
const buildResult = spawnSync(python, [join(scriptDir, "build_scene_data.py"), project], {
  encoding: "utf8",
});
if (buildResult.status !== 0) {
  console.error(buildResult.error?.message || buildResult.stderr || buildResult.stdout);
  process.exit(buildResult.status || 1);
}

const manifest = JSON.parse(await readFile(join(project, "manifest.json"), "utf8"));
const width = Number(manifest.screenshots?.width || 1400);
const height = Number(manifest.screenshots?.height || 1000);
const preview = join(project, "preview");
const screenshots = join(project, "screenshots");
const viewerSource = await readFile(join(preview, "viewer.js"), "utf8");
const scenePayload = {
  components: JSON.parse(await readFile(join(project, "components.json"), "utf8")),
  assembly: JSON.parse(await readFile(join(project, "assembly.json"), "utf8")),
  scene_plan: JSON.parse(await readFile(join(project, "scene_plan.json"), "utf8")),
  manifest,
  catalog: JSON.parse(await readFile(join(project, "primitive_catalog.json"), "utf8")),
};

async function browserBackend() {
  const { chromium } = require("playwright");
  // 直接装载同一套 HTML/CSS/数据/预览脚本，不依赖 localhost 或 file:// 导航。
  const [indexSource, cssSource, dataSource] = await Promise.all([
    readFile(join(preview, "index.html"), "utf8"),
    readFile(join(preview, "styles.css"), "utf8"),
    readFile(join(preview, "scene_data.js"), "utf8"),
  ]);
  const inlineHTML = indexSource
    .replace(/<link\b[^>]*rel=["']stylesheet["'][^>]*>/gi, "")
    .replace(/<script\b[^>]*src=["'][^"']+["'][^>]*>\s*<\/script>/gi, "");
  let browser;
  try {
    const launchOptions = { headless: true };
    // 可使用宿主已安装的 Chromium；不自动下载或改变用户浏览器。
    if (process.env.GPT2GIA_CHROMIUM_EXECUTABLE) {
      launchOptions.executablePath = process.env.GPT2GIA_CHROMIUM_EXECUTABLE;
    }
    browser = await chromium.launch(launchOptions);
    return {
      name: "playwright_browser",
      transport: "inline_assets",
      async capture(view) {
        const page = await browser.newPage({ viewport: { width, height }, deviceScaleFactor: 1 });
        await page.setContent(inlineHTML, { waitUntil: "domcontentloaded" });
        await page.addStyleTag({ content: cssSource });
        await page.addScriptTag({ content: dataSource });
        await page.addScriptTag({ content: viewerSource });
        await page.waitForFunction(() => window.renderReady === true, null, { timeout: 15000 });
        await page.evaluate((selectedView) => window.setGPT2GIAView(selectedView), view);
        const bytes = await page.screenshot({ type: "png" });
        await page.close();
        return bytes;
      },
      async contactSheet(cards) {
        const page = await browser.newPage({ viewport: { width, height }, deviceScaleFactor: 1 });
        const figures = cards.map((card) =>
          `<figure><img src="data:image/png;base64,${card.bytes.toString("base64")}"><figcaption>${card.label}</figcaption></figure>`
        ).join("");
        await page.setContent(`<!doctype html><meta charset="utf-8"><style>
          *{box-sizing:border-box}html,body{margin:0;width:100%;height:100%;overflow:hidden;background:#09101b;color:#e9f1ff;font:14px system-ui}
          main{display:grid;grid-template-columns:1fr 1fr;grid-template-rows:repeat(3,1fr);gap:8px;padding:10px;width:100%;height:100%}
          figure{position:relative;margin:0;min-height:0;border:1px solid #24344c;border-radius:8px;overflow:hidden;background:#101a2a}
          img{width:100%;height:100%;object-fit:cover}figcaption{position:absolute;left:8px;bottom:7px;padding:4px 8px;border-radius:5px;background:#07101dcc}
          figure:first-child{grid-row:span 2}
        </style><main>${figures}</main>`);
        await page.waitForFunction(() => [...document.images].every((image) => image.complete));
        const bytes = await page.screenshot({ type: "png" });
        await page.close();
        return bytes;
      },
      async close() {
        await browser.close();
      },
    };
  } catch (error) {
    if (browser) await browser.close();
    throw error;
  }
}

function fakeElement(dataset = {}) {
  return {
    dataset,
    textContent: "",
    classList: { toggle() {}, add() {}, remove() {} },
    addEventListener() {},
  };
}

async function canvasBackend() {
  const { createCanvas, loadImage } = require("@napi-rs/canvas");
  return {
    name: "viewer_canvas",
    async capture(view) {
      const canvas = createCanvas(width, height - 54);
      Object.defineProperties(canvas, {
        clientWidth: { value: width, configurable: true },
        clientHeight: { value: height - 54, configurable: true },
      });
      canvas.addEventListener = () => {};
      canvas.setPointerCapture = () => {};
      const buttons = ["perspective", "front", "right", "back", "top_or_isometric"]
        .map((name) => fakeElement({ view: name }));
      const elements = new Map([
        ["viewport", canvas],
        ["project-name", fakeElement()],
        ["scene-stats", fakeElement()],
        ["legend", fakeElement()],
        ["debug-toggle", fakeElement()],
      ]);
      const windowObject = {
        GPT2GIA_SCENE: scenePayload,
        devicePixelRatio: 1,
        renderReady: false,
        addEventListener() {},
      };
      const sandbox = {
        window: windowObject,
        document: {
          getElementById(id) { return elements.get(id) || fakeElement(); },
          querySelectorAll(selector) { return selector === "[data-view]" ? buttons : []; },
        },
        location: { search: `?view=${encodeURIComponent(view)}` },
        URLSearchParams,
        console,
      };
      vm.createContext(sandbox);
      vm.runInContext(viewerSource, sandbox, { filename: "viewer.js" });
      if (!windowObject.renderReady) throw new Error("viewer.js 未完成渲染");

      const output = createCanvas(width, height);
      const context = output.getContext("2d");
      context.fillStyle = "#09101b";
      context.fillRect(0, 0, width, height);
      context.fillStyle = "#e8eef8";
      context.font = "bold 16px sans-serif";
      context.fillText(manifest.project_name || "GPT2GIA", 18, 32);
      context.fillStyle = "#91a3bc";
      context.font = "13px sans-serif";
      const depthCount = scenePayload.scene_plan?.camera_plan?.depth_layers?.length || 0;
      const repeatCount = scenePayload.scene_plan?.repeat_policy?.sets?.length || 0;
      context.fillText(
        `${scenePayload.components.components.length} components · ${scenePayload.assembly.groups.length} groups · ${depthCount} depth layers · ${repeatCount} repeat sets · ${view}`,
        220,
        32,
      );
      context.drawImage(canvas, 0, 54);
      return output.toBuffer("image/png");
    },
    async contactSheet(cards) {
      const output = createCanvas(width, height);
      const context = output.getContext("2d");
      context.fillStyle = "#09101b";
      context.fillRect(0, 0, width, height);
      const gap = 10;
      const cellWidth = (width - gap * 3) / 2;
      const cellHeight = (height - gap * 4) / 3;
      for (let index = 0; index < cards.length; index += 1) {
        const placements = [
          [0, 0, 2],
          [1, 0, 1],
          [1, 1, 1],
          [0, 2, 1],
          [1, 2, 1],
        ];
        const [column, row, rowSpan] = placements[index];
        const x = gap + column * (cellWidth + gap);
        const y = gap + row * (cellHeight + gap);
        const h = cellHeight * rowSpan + gap * (rowSpan - 1);
        const image = await loadImage(cards[index].bytes);
        context.save();
        context.beginPath();
        context.roundRect(x, y, cellWidth, h, 8);
        context.clip();
        const ratio = Math.max(cellWidth / image.width, h / image.height);
        const drawWidth = image.width * ratio;
        const drawHeight = image.height * ratio;
        context.drawImage(image, x + (cellWidth - drawWidth) / 2, y + (h - drawHeight) / 2, drawWidth, drawHeight);
        context.restore();
        context.fillStyle = "rgba(7,16,29,.82)";
        context.fillRect(x + 8, y + h - 31, 94, 23);
        context.fillStyle = "#eef5ff";
        context.font = "13px sans-serif";
        context.fillText(cards[index].label, x + 15, y + h - 15);
      }
      return output.toBuffer("image/png");
    },
    async close() {},
  };
}

let backend;
let browserFailure = "";
try {
  backend = await browserBackend();
} catch (error) {
  browserFailure = String(error?.message || error);
  try {
    backend = await canvasBackend();
  } catch (canvasError) {
    console.error("BLOCKED_NO_RENDER_BACKEND");
    console.error(`Playwright: ${browserFailure}`);
    console.error(`Canvas: ${canvasError?.message || canvasError}`);
    process.exit(1);
  }
}

async function save(view, filename) {
  const bytes = await backend.capture(view);
  await writeFile(join(screenshots, filename), bytes);
  return bytes;
}

try {
  if (stepGroup) {
    const existing = (await readdir(screenshots)).filter((name) => /^step_\d+_/.test(name));
    const number = String(existing.length + 1).padStart(2, "0");
    const filename = `step_${number}_${stepGroup}.png`;
    await save("perspective", filename);
    console.log(join(screenshots, filename));
  } else {
    const views = [
      ["perspective", "final_perspective.png", "Perspective"],
      ["front", "final_front.png", "Front"],
      ["right", "final_right.png", "Right"],
      ["back", "final_back.png", "Back"],
      ["top_or_isometric", "final_top_or_isometric.png", "Top / Isometric"],
    ];
    const cards = [];
    for (const [view, filename, label] of views) {
      cards.push({ bytes: await save(view, filename), label });
    }
    const contactBytes = await backend.contactSheet(cards);
    await writeFile(join(screenshots, "contact_sheet.png"), contactBytes);
    console.log(join(screenshots, "contact_sheet.png"));
  }
  await appendFile(
    join(project, "build_log.jsonl"),
    `${JSON.stringify({ time: new Date().toISOString(), event: "screenshot", prompt_sha256: manifest.prompt_workflow?.prompt_sha256, contract_sha256: manifest.prompt_workflow?.contract_sha256, backend: backend.name, transport: backend.transport || "canvas_vm", mode: stepGroup ? "step" : "final", group: stepGroup || null })}\n`,
    "utf8",
  );
} finally {
  await backend.close();
}
