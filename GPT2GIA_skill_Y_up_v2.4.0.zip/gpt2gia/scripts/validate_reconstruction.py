#!/usr/bin/env python3
"""Validate reference fusion, occlusion, scale, decomposition, and low-poly style."""

from __future__ import annotations

import math
from collections import Counter, defaultdict
from typing import Any

from common import ID_RE, combined_bounds, is_finite_vector3

SCHEMA_VERSION = "2.2.0"


def _error(code: str, message: str, **context: Any) -> dict[str, Any]:
    result: dict[str, Any] = {"code": code, "message": message}
    if context:
        result["context"] = context
    return result


def _finite_number(value: Any, *, positive: bool = False) -> bool:
    return (
        isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(float(value))
        and (not positive or float(value) > 0)
    )


def _valid_unit_point(value: Any) -> bool:
    return (
        isinstance(value, list)
        and len(value) == 2
        and all(_finite_number(item) and 0 <= float(item) <= 1 for item in value)
    )


def _valid_unit_range(value: Any) -> bool:
    return (
        isinstance(value, list)
        and len(value) == 2
        and all(_finite_number(item) and 0 <= float(item) <= 1 for item in value)
        and float(value[0]) <= float(value[1])
    )


def _graph_has_cycle(adjacency: dict[str, set[str]]) -> bool:
    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(node: str) -> bool:
        if node in visiting:
            return True
        if node in visited:
            return False
        visiting.add(node)
        for neighbor in adjacency.get(node, set()):
            if visit(neighbor):
                return True
        visiting.remove(node)
        visited.add(node)
        return False

    return any(visit(node) for node in set(adjacency) | {item for values in adjacency.values() for item in values})


def _validate_reference_analysis(
    reference: Any,
    group_map: dict[str, dict[str, Any]],
    valid_components: list[dict[str, Any]],
    by_group: dict[str, list[dict[str, Any]]],
    coordinate_plan: dict[str, Any],
    errors: list[dict[str, Any]],
) -> set[str]:
    if not isinstance(reference, dict) or reference.get("schema_version") != SCHEMA_VERSION:
        errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", "reference_analysis.json 缺失或版本非法"))
        return set()

    input_mode = reference.get("input_mode")
    if input_mode not in {"text_only", "single_image", "multi_view", "mixed"}:
        errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", "input_mode 非法"))

    views = reference.get("views")
    if not isinstance(views, list):
        errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", "views 必须是数组"))
        views = []
    view_ids: set[str] = set()
    view_orientations: dict[str, str] = {}
    for view in views:
        if not isinstance(view, dict):
            errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", "视图记录必须是对象"))
            continue
        view_id = view.get("view_id")
        if not isinstance(view_id, str) or not ID_RE.fullmatch(view_id) or view_id in view_ids:
            errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", "view_id 非法或重复", view=view))
            continue
        view_ids.add(view_id)
        orientation = view.get("orientation")
        if orientation not in {
            "front", "back", "left", "right", "top", "bottom",
            "left_45", "right_45", "isometric", "detail", "unknown",
        }:
            errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", f"{view_id} 的 orientation 非法"))
        else:
            view_orientations[view_id] = str(orientation)
        if view.get("projection") not in {"orthographic", "perspective", "weak_perspective", "unknown"}:
            errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", f"{view_id} 的 projection 非法"))
        if view.get("reliability") not in {"high", "medium", "low"}:
            errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", f"{view_id} 的 reliability 非法"))
        if not str(view.get("source_ref", "")).strip():
            errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", f"{view_id} 缺少 source_ref"))
        bbox = view.get("subject_bbox")
        if bbox is not None and not (
            isinstance(bbox, list)
            and len(bbox) == 4
            and all(_finite_number(value) and 0 <= float(value) <= 1 for value in bbox)
            and float(bbox[0]) < float(bbox[2])
            and float(bbox[1]) < float(bbox[3])
        ):
            errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", f"{view_id} 的 subject_bbox 非法"))

    if input_mode == "text_only" and views:
        errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", "text_only 模式不应登记图片视图"))
    if input_mode == "single_image" and len(views) != 1:
        errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", "single_image 模式必须恰有一个视图"))
    if input_mode == "multi_view" and len(views) < 2:
        errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", "multi_view 模式至少需要两个视图"))
    if input_mode == "mixed" and not views:
        errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", "mixed 模式至少需要一个图片视图"))

    fusion = reference.get("view_fusion")
    if not isinstance(fusion, dict):
        errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", "缺少 view_fusion"))
        fusion = {}
    fusion_status = fusion.get("status")
    if input_mode == "multi_view" and fusion_status != "fused":
        errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", "多视图输入必须完成 fused 状态"))
    elif input_mode in {"text_only", "single_image"} and fusion_status not in {"not_applicable", "fused"}:
        errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", "当前输入模式的 view_fusion 状态非法"))
    elif input_mode == "mixed" and len(views) >= 2 and fusion_status != "fused":
        errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", "mixed 模式含多张图时必须完成融合"))

    landmarks = fusion.get("landmarks")
    if not isinstance(landmarks, list):
        errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", "view_fusion.landmarks 必须是数组"))
        landmarks = []
    landmark_ids: set[str] = set()
    for landmark in landmarks:
        if not isinstance(landmark, dict):
            errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", "地标记录必须是对象"))
            continue
        landmark_id = landmark.get("landmark_id")
        if (
            not isinstance(landmark_id, str)
            or not ID_RE.fullmatch(landmark_id)
            or landmark_id in landmark_ids
        ):
            errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", "landmark_id 非法或重复"))
            continue
        landmark_ids.add(landmark_id)
        if landmark.get("target_group_id") not in group_map:
            errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", f"{landmark_id} 的目标组不存在"))
        observations = landmark.get("observations")
        if not isinstance(observations, list) or not observations:
            errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", f"{landmark_id} 缺少视图观测"))
            observations = []
        observed_views: set[str] = set()
        direct_observations = 0
        for observation in observations:
            if not isinstance(observation, dict):
                errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", f"{landmark_id} 的观测必须是对象"))
                continue
            view_id = observation.get("view_id")
            if view_id not in view_ids or view_id in observed_views:
                errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", f"{landmark_id} 引用了非法或重复视图 {view_id}"))
            else:
                observed_views.add(str(view_id))
            visibility = observation.get("visibility")
            point = observation.get("image_xy")
            if visibility in {"visible", "partial"}:
                direct_observations += 1
                if not _valid_unit_point(point):
                    errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", f"{landmark_id}/{view_id} 可见但坐标非法"))
            elif visibility in {"occluded", "out_of_frame"}:
                if point is not None:
                    errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", f"{landmark_id}/{view_id} 不可见时 image_xy 必须为 null"))
            else:
                errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", f"{landmark_id}/{view_id} 的 visibility 非法"))
        method = landmark.get("fusion_method")
        if method not in {
            "calibrated_triangulation",
            "orthographic_correspondence",
            "silhouette_carving",
            "proportion_transfer",
            "symmetry_constraint",
            "manual_constraint",
        }:
            errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", f"{landmark_id} 的融合方法非法"))
        if method in {"calibrated_triangulation", "orthographic_correspondence"} and direct_observations < 2:
            errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", f"{landmark_id} 的融合方法至少需要两个直接观测"))
        fused_position = landmark.get("fused_position")
        if fusion_status == "fused" and not is_finite_vector3(fused_position):
            errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", f"{landmark_id} 缺少有效 fused_position"))
        if landmark.get("confidence") not in {"high", "medium", "low"}:
            errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", f"{landmark_id} 的 confidence 非法"))

    constraints = fusion.get("silhouette_constraints")
    if not isinstance(constraints, list):
        errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", "silhouette_constraints 必须是数组"))
        constraints = []
    constrained_views: set[str] = set()
    for constraint in constraints:
        if not isinstance(constraint, dict):
            errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", "轮廓约束必须是对象"))
            continue
        view_id = constraint.get("view_id")
        if view_id not in view_ids:
            errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", f"轮廓约束引用不存在的视图 {view_id}"))
        else:
            constrained_views.add(str(view_id))
        group_ids = constraint.get("group_ids")
        if not isinstance(group_ids, list) or not group_ids:
            errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", f"{view_id} 的轮廓约束没有目标组"))
        else:
            for group_id in group_ids:
                if group_id not in group_map:
                    errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", f"{view_id} 的轮廓约束引用不存在的组 {group_id}"))
        tolerance = constraint.get("tolerance_fraction")
        if not _finite_number(tolerance) or not 0 <= float(tolerance) <= 0.25:
            errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", f"{view_id} 的轮廓容差非法"))
    if fusion_status == "fused":
        required_constraint_views = {
            view_id for view_id, orientation in view_orientations.items() if orientation != "detail"
        }
        missing = sorted(required_constraint_views - constrained_views)
        if missing:
            errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", "存在没有轮廓约束的主要视图", view_ids=missing))

    conflicts = fusion.get("conflicts")
    if not isinstance(conflicts, list):
        errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", "view_fusion.conflicts 必须是数组"))
        conflicts = []
    conflict_ids: set[str] = set()
    for conflict in conflicts:
        if not isinstance(conflict, dict):
            errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", "冲突记录必须是对象"))
            continue
        conflict_id = conflict.get("conflict_id")
        involved = conflict.get("involved_view_ids")
        if (
            not isinstance(conflict_id, str)
            or not ID_RE.fullmatch(conflict_id)
            or conflict_id in conflict_ids
        ):
            errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", "conflict_id 非法或重复"))
        else:
            conflict_ids.add(conflict_id)
        if (
            not isinstance(involved, list)
            or len(set(involved)) < 2
            or any(view_id not in view_ids for view_id in involved)
        ):
            errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", f"{conflict_id} 的 involved_view_ids 非法"))
        if not str(conflict.get("rationale", "")).strip():
            errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", f"{conflict_id} 缺少解决理由"))

    for component in valid_components:
        evidence_ids = component.get("evidence_ids", [])
        if not isinstance(evidence_ids, list) or len(evidence_ids) != len(set(evidence_ids)):
            errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", f"{component['id']} 的 evidence_ids 非法"))
        else:
            unknown = sorted(set(evidence_ids) - landmark_ids)
            if unknown:
                errors.append(_error("MULTIVIEW_FUSION_INCOMPLETE", f"{component['id']} 引用了不存在的融合地标", evidence_ids=unknown))

    occlusion = reference.get("occlusion_inference")
    if not isinstance(occlusion, dict):
        errors.append(_error("OCCLUSION_INFERENCE_CONFLICT", "缺少 occlusion_inference"))
        occlusion = {}
    occlusion_status = occlusion.get("status")
    relations = occlusion.get("relations")
    hidden_geometry = occlusion.get("hidden_geometry")
    if not isinstance(relations, list):
        errors.append(_error("OCCLUSION_INFERENCE_CONFLICT", "occlusion relations 必须是数组"))
        relations = []
    if not isinstance(hidden_geometry, list):
        errors.append(_error("OCCLUSION_INFERENCE_CONFLICT", "hidden_geometry 必须是数组"))
        hidden_geometry = []
    if occlusion_status == "not_present" and (relations or hidden_geometry):
        errors.append(_error("OCCLUSION_INFERENCE_CONFLICT", "遮挡状态为 not_present 时关系和隐藏推断必须为空"))
    elif occlusion_status == "planned" and not relations:
        errors.append(_error("OCCLUSION_INFERENCE_CONFLICT", "遮挡状态为 planned 时至少需要一条关系"))
    elif occlusion_status not in {"not_present", "planned"}:
        errors.append(_error("OCCLUSION_INFERENCE_CONFLICT", "occlusion_inference.status 非法"))

    relation_ids: set[str] = set()
    directed_pairs: dict[str, set[tuple[str, str]]] = defaultdict(set)
    adjacency: dict[str, dict[str, set[str]]] = defaultdict(lambda: defaultdict(set))
    materially_hidden_groups: set[str] = set()
    for relation in relations:
        if not isinstance(relation, dict):
            errors.append(_error("OCCLUSION_INFERENCE_CONFLICT", "遮挡关系必须是对象"))
            continue
        relation_id = relation.get("relation_id")
        view_id = relation.get("view_id")
        occluder = relation.get("occluder_group_id")
        occluded = relation.get("occluded_group_id")
        if (
            not isinstance(relation_id, str)
            or not ID_RE.fullmatch(relation_id)
            or relation_id in relation_ids
        ):
            errors.append(_error("OCCLUSION_INFERENCE_CONFLICT", "relation_id 非法或重复"))
        else:
            relation_ids.add(relation_id)
        if view_id not in view_ids:
            errors.append(_error("OCCLUSION_INFERENCE_CONFLICT", f"{relation_id} 引用了不存在的视图"))
        if occluder not in group_map or occluded not in group_map or occluder == occluded:
            errors.append(_error("OCCLUSION_INFERENCE_CONFLICT", f"{relation_id} 的遮挡组引用非法"))
            continue
        pair = (str(occluder), str(occluded))
        reverse = (str(occluded), str(occluder))
        if reverse in directed_pairs[str(view_id)]:
            errors.append(_error("OCCLUSION_INFERENCE_CONFLICT", f"{view_id} 同时声明了相反遮挡关系", pair=pair))
        directed_pairs[str(view_id)].add(pair)
        adjacency[str(view_id)][str(occluder)].add(str(occluded))
        fraction = relation.get("occlusion_fraction")
        if not _valid_unit_range(fraction):
            errors.append(_error("OCCLUSION_INFERENCE_CONFLICT", f"{relation_id} 的 occlusion_fraction 非法"))
        elif float(fraction[1]) >= 0.5:
            materially_hidden_groups.add(str(occluded))
        if not str(relation.get("evidence", "")).strip():
            errors.append(_error("OCCLUSION_INFERENCE_CONFLICT", f"{relation_id} 缺少证据"))
    for view_id, graph in adjacency.items():
        if _graph_has_cycle(graph):
            errors.append(_error("OCCLUSION_INFERENCE_CONFLICT", f"{view_id} 的遮挡图存在循环"))

    inference_ids: set[str] = set()
    inferred_groups: set[str] = set()
    for inference in hidden_geometry:
        if not isinstance(inference, dict):
            errors.append(_error("OCCLUSION_INFERENCE_CONFLICT", "隐藏几何推断必须是对象"))
            continue
        inference_id = inference.get("inference_id")
        target_group = inference.get("target_group_id")
        if (
            not isinstance(inference_id, str)
            or not ID_RE.fullmatch(inference_id)
            or inference_id in inference_ids
        ):
            errors.append(_error("OCCLUSION_INFERENCE_CONFLICT", "inference_id 非法或重复"))
        else:
            inference_ids.add(inference_id)
        if target_group not in group_map:
            errors.append(_error("OCCLUSION_INFERENCE_CONFLICT", f"{inference_id} 的目标组不存在"))
        else:
            inferred_groups.add(str(target_group))
        basis = inference.get("basis")
        source_views = inference.get("source_view_ids")
        if not isinstance(source_views, list) or any(view_id not in view_ids for view_id in source_views):
            errors.append(_error("OCCLUSION_INFERENCE_CONFLICT", f"{inference_id} 的 source_view_ids 非法"))
            source_views = []
        if basis == "other_view" and not source_views:
            errors.append(_error("OCCLUSION_INFERENCE_CONFLICT", f"{inference_id} 使用 other_view 但没有来源视图"))
        if basis == "conservative_unknown" and inference.get("action") == "reconstruct":
            errors.append(_error("OCCLUSION_INFERENCE_CONFLICT", f"{inference_id} 证据不足时不得重建隐藏细节"))
        if basis not in {"other_view", "symmetry", "visible_continuation", "mechanical_template", "conservative_unknown"}:
            errors.append(_error("OCCLUSION_INFERENCE_CONFLICT", f"{inference_id} 的 basis 非法"))
        if inference.get("action") not in {"reconstruct", "simplify", "leave_unmodeled"}:
            errors.append(_error("OCCLUSION_INFERENCE_CONFLICT", f"{inference_id} 的 action 非法"))
        if not str(inference.get("assumption", "")).strip():
            errors.append(_error("OCCLUSION_INFERENCE_CONFLICT", f"{inference_id} 缺少假设边界"))
    missing_inference = sorted(materially_hidden_groups - inferred_groups)
    if missing_inference:
        errors.append(_error("OCCLUSION_INFERENCE_CONFLICT", "被大面积遮挡的组缺少隐藏几何推断", group_ids=missing_inference))

    scale = reference.get("scale_recovery")
    if not isinstance(scale, dict):
        errors.append(_error("REAL_SCALE_UNSUPPORTED", "缺少 scale_recovery"))
        return landmark_ids
    scale_status = scale.get("status")
    if scale_status not in {"absolute_recovered", "absolute_estimated", "relative_only"}:
        errors.append(_error("REAL_SCALE_UNSUPPORTED", "scale_recovery.status 非法"))
    if scale.get("confidence") not in {"high", "medium", "low"} or not str(scale.get("basis", "")).strip():
        errors.append(_error("REAL_SCALE_UNSUPPORTED", "scale_recovery 缺少置信度或依据"))
    targets = scale.get("targets")
    if not isinstance(targets, list) or not targets:
        errors.append(_error("REAL_SCALE_UNSUPPORTED", "scale_recovery 至少需要一个目标"))
        targets = []
    target_ids: set[str] = set()
    for target in targets:
        if not isinstance(target, dict):
            errors.append(_error("REAL_SCALE_UNSUPPORTED", "尺度目标必须是对象"))
            continue
        target_id = target.get("target_id")
        if (
            not isinstance(target_id, str)
            or not ID_RE.fullmatch(target_id)
            or target_id in target_ids
        ):
            errors.append(_error("REAL_SCALE_UNSUPPORTED", "target_id 非法或重复"))
            continue
        target_ids.add(target_id)
        group_ids = target.get("group_ids")
        if not isinstance(group_ids, list) or not group_ids:
            errors.append(_error("REAL_SCALE_UNSUPPORTED", f"{target_id} 没有目标组"))
            group_ids = []
        elif any(group_id not in group_map for group_id in group_ids):
            errors.append(_error("REAL_SCALE_UNSUPPORTED", f"{target_id} 引用了不存在的组"))
        mode = target.get("mode")
        if mode != scale_status:
            errors.append(_error("REAL_SCALE_UNSUPPORTED", f"{target_id} 的 mode 与全局尺度状态不一致"))
        dimensions = target.get("bounds_size_m")
        if not (
            isinstance(dimensions, list)
            and len(dimensions) == 3
            and all(value is None or _finite_number(value, positive=True) for value in dimensions)
        ):
            errors.append(_error("REAL_SCALE_UNSUPPORTED", f"{target_id} 的 bounds_size_m 非法"))
            dimensions = [None, None, None]
        reference_dimension = target.get("reference_dimension")
        if not isinstance(reference_dimension, dict):
            errors.append(_error("REAL_SCALE_UNSUPPORTED", f"{target_id} 缺少 reference_dimension"))
            reference_dimension = {}
        kind = reference_dimension.get("kind")
        value_m = reference_dimension.get("value_m")
        if mode == "relative_only":
            if any(value is not None for value in dimensions) or value_m is not None or kind != "relative_unit":
                errors.append(_error("REAL_SCALE_UNSUPPORTED", f"{target_id} 为 relative_only 时不得声明绝对米制尺寸"))
        else:
            if not any(value is not None for value in dimensions) or not _finite_number(value_m, positive=True):
                errors.append(_error("REAL_SCALE_UNSUPPORTED", f"{target_id} 声称恢复绝对尺度但缺少有效尺寸证据"))
            if mode == "absolute_recovered" and kind not in {"known_length", "manufacturer_spec", "standard_part"}:
                errors.append(_error("REAL_SCALE_UNSUPPORTED", f"{target_id} 的证据不足以标记 absolute_recovered"))
            if mode == "absolute_estimated" and kind not in {
                "known_length", "human_height", "manufacturer_spec", "standard_part", "multi_view_ratio"
            }:
                errors.append(_error("REAL_SCALE_UNSUPPORTED", f"{target_id} 的估算尺度依据非法"))
        uncertainty = reference_dimension.get("uncertainty_fraction")
        if not _finite_number(uncertainty) or not 0 <= float(uncertainty) <= 1:
            errors.append(_error("REAL_SCALE_UNSUPPORTED", f"{target_id} 的不确定度非法"))
        if not str(reference_dimension.get("source", "")).strip():
            errors.append(_error("REAL_SCALE_UNSUPPORTED", f"{target_id} 缺少尺度来源"))
        tolerance = target.get("tolerance_fraction")
        if not _finite_number(tolerance) or not 0 <= float(tolerance) <= 1:
            errors.append(_error("REAL_SCALE_UNSUPPORTED", f"{target_id} 的容差非法"))
            tolerance = 0.0

        target_components = [
            component
            for group_id in group_ids
            for component in by_group.get(str(group_id), [])
        ]
        if target_components:
            bounds = combined_bounds(target_components)
            actual_dimensions = [bounds[1][axis] - bounds[0][axis] for axis in range(3)]
            for axis, expected in enumerate(dimensions):
                if expected is None:
                    continue
                residual = abs(actual_dimensions[axis] - float(expected)) / float(expected)
                if residual > float(tolerance) + 1e-9:
                    errors.append(
                        _error(
                            "REAL_SCALE_UNSUPPORTED",
                            f"{target_id} 的轴向尺寸超出恢复容差",
                            axis="xyz"[axis],
                            expected=expected,
                            actual=actual_dimensions[axis],
                            residual=residual,
                            tolerance=tolerance,
                        )
                    )
            constraints = target.get("proportion_constraints")
            if not isinstance(constraints, list):
                errors.append(_error("REAL_SCALE_UNSUPPORTED", f"{target_id} 的比例约束必须是数组"))
                constraints = []
            axis_index = {"x": 0, "y": 1, "z": 2}
            for constraint in constraints:
                if not isinstance(constraint, dict):
                    errors.append(_error("REAL_SCALE_UNSUPPORTED", f"{target_id} 的比例约束必须是对象"))
                    continue
                numerator = constraint.get("numerator_axis")
                denominator = constraint.get("denominator_axis")
                ratio = constraint.get("target_ratio")
                ratio_tolerance = constraint.get("tolerance_fraction")
                if (
                    numerator not in axis_index
                    or denominator not in axis_index
                    or numerator == denominator
                    or not _finite_number(ratio, positive=True)
                    or not _finite_number(ratio_tolerance)
                    or not 0 <= float(ratio_tolerance) <= 1
                ):
                    errors.append(_error("REAL_SCALE_UNSUPPORTED", f"{target_id} 的比例约束非法"))
                    continue
                actual_ratio = actual_dimensions[axis_index[numerator]] / max(
                    actual_dimensions[axis_index[denominator]], 1e-12
                )
                residual = abs(actual_ratio - float(ratio)) / float(ratio)
                if residual > float(ratio_tolerance) + 1e-9:
                    errors.append(
                        _error(
                            "REAL_SCALE_UNSUPPORTED",
                            f"{target_id} 的比例约束超差",
                            axes=f"{numerator}/{denominator}",
                            expected=ratio,
                            actual=actual_ratio,
                            residual=residual,
                        )
                    )
        elif group_ids:
            errors.append(_error("REAL_SCALE_UNSUPPORTED", f"{target_id} 的目标组没有组件"))

    scale_reference = coordinate_plan.get("scale_reference", {})
    if scale_status in {"absolute_recovered", "absolute_estimated"} and scale_reference.get("kind") == "arbitrary":
        errors.append(_error("REAL_SCALE_UNSUPPORTED", "已声明绝对尺度，但 scene_plan.scale_reference 仍为 arbitrary"))
    return landmark_ids


def _validate_decomposition(
    decomposition: Any,
    group_map: dict[str, dict[str, Any]],
    errors: list[dict[str, Any]],
) -> None:
    if not isinstance(decomposition, dict) or decomposition.get("schema_version") != SCHEMA_VERSION:
        errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", "decomposition.json 缺失或版本非法"))
        return
    if decomposition.get("status") != "planned":
        errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", "decomposition.status 必须为 planned"))
    profile = decomposition.get("profile")
    template = decomposition.get("template")
    mechanical_templates = {
        "vehicle_aircraft",
        "rotary_machine",
        "robot_actuated",
        "industrial_equipment",
        "handheld_tool",
        "custom_mechanical",
    }
    if profile == "generic" and template != "generic_object":
        errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", "generic profile 必须使用 generic_object 模板"))
    elif profile == "mechanical_equipment" and template not in mechanical_templates:
        errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", "机械设备必须选择机械拆解模板"))
    elif profile not in {"generic", "mechanical_equipment"}:
        errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", "decomposition.profile 非法"))

    nodes = decomposition.get("nodes")
    if not isinstance(nodes, list) or not nodes:
        errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", "decomposition.nodes 至少需要一个节点"))
        nodes = []
    node_map: dict[str, dict[str, Any]] = {}
    group_owners: dict[str, str] = {}
    level_rank = {"system": 0, "module": 1, "subassembly": 2, "part": 3, "detail": 4}
    mechanical_roles: set[str] = set()
    for node in nodes:
        if not isinstance(node, dict):
            errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", "拆解节点必须是对象"))
            continue
        node_id = node.get("node_id")
        if not isinstance(node_id, str) or not ID_RE.fullmatch(node_id) or node_id in node_map:
            errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", "node_id 非法或重复"))
            continue
        node_map[node_id] = node
        if node.get("level") not in level_rank:
            errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", f"{node_id} 的 level 非法"))
        if not str(node.get("function", "")).strip():
            errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", f"{node_id} 缺少功能说明"))
        split_evidence = node.get("split_evidence")
        if not isinstance(split_evidence, list) or not split_evidence:
            errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", f"{node_id} 缺少拆分证据"))
        group_ids = node.get("group_ids")
        if not isinstance(group_ids, list) or len(group_ids) != len(set(group_ids)):
            errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", f"{node_id} 的 group_ids 非法"))
            group_ids = []
        for group_id in group_ids:
            if group_id not in group_map:
                errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", f"{node_id} 引用了不存在的组 {group_id}"))
            elif group_id in group_owners:
                errors.append(
                    _error(
                        "DECOMPOSITION_CONTRACT_ERROR",
                        f"组 {group_id} 被多个拆解节点重复认领",
                        first=group_owners[group_id],
                        second=node_id,
                    )
                )
            else:
                group_owners[group_id] = node_id
        role = node.get("mechanical_role")
        if profile == "mechanical_equipment" and node.get("level") != "system":
            if role == "not_applicable":
                errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", f"机械节点 {node_id} 缺少机械角色"))
            elif isinstance(role, str):
                mechanical_roles.add(role)

    root_id = decomposition.get("root_node_id")
    root = node_map.get(root_id)
    if root is None:
        errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", "root_node_id 不存在"))
    elif root.get("parent_node_id") is not None or root.get("level") != "system":
        errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", "根节点必须是无父级的 system"))

    parent_graph: dict[str, set[str]] = defaultdict(set)
    for node_id, node in node_map.items():
        parent_id = node.get("parent_node_id")
        if node_id == root_id:
            continue
        if parent_id not in node_map:
            errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", f"{node_id} 的父节点不存在"))
            continue
        parent_graph[str(parent_id)].add(node_id)
        parent_level = node_map[str(parent_id)].get("level")
        child_level = node.get("level")
        if parent_level in level_rank and child_level in level_rank and level_rank[child_level] <= level_rank[parent_level]:
            errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", f"{node_id} 的层级没有比父节点更具体"))
    if _graph_has_cycle(parent_graph):
        errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", "拆解层级存在循环"))

    missing_groups = sorted(set(group_map) - set(group_owners))
    if missing_groups:
        errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", "存在未归入拆解节点的装配组", group_ids=missing_groups))
    if profile == "mechanical_equipment":
        levels = {str(node.get("level")) for node in nodes if isinstance(node, dict)}
        if not {"system", "module", "part"} <= levels:
            errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", "机械模板至少需要 system、module 和 part 层"))
        if len(mechanical_roles) < 2:
            errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", "机械拆解至少需要两个不同机械角色"))

    interfaces = decomposition.get("interfaces")
    if not isinstance(interfaces, list):
        errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", "interfaces 必须是数组"))
        interfaces = []
    if profile == "mechanical_equipment" and len(node_map) > 1 and not interfaces:
        errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", "机械拆解存在多个节点但没有接口关系"))
    interface_ids: set[str] = set()
    for interface in interfaces:
        if not isinstance(interface, dict):
            errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", "接口必须是对象"))
            continue
        interface_id = interface.get("interface_id")
        from_node = interface.get("from_node_id")
        to_node = interface.get("to_node_id")
        joint_type = interface.get("joint_type")
        if (
            not isinstance(interface_id, str)
            or not ID_RE.fullmatch(interface_id)
            or interface_id in interface_ids
        ):
            errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", "interface_id 非法或重复"))
        else:
            interface_ids.add(interface_id)
        if from_node not in node_map or to_node not in node_map or from_node == to_node:
            errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", f"{interface_id} 的节点引用非法"))
        axis = interface.get("axis")
        if joint_type in {"revolute", "prismatic"}:
            if not is_finite_vector3(axis) or math.sqrt(sum(float(value) ** 2 for value in axis)) <= 1e-9:
                errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", f"{interface_id} 的运动轴非法"))
        elif axis is not None and not is_finite_vector3(axis):
            errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", f"{interface_id} 的 axis 非法"))
        limits = interface.get("limits")
        if limits is not None and not (
            isinstance(limits, list)
            and len(limits) == 2
            and all(_finite_number(value) for value in limits)
            and float(limits[0]) <= float(limits[1])
        ):
            errors.append(_error("DECOMPOSITION_CONTRACT_ERROR", f"{interface_id} 的 limits 非法"))


def _validate_style_profile(
    style: Any,
    scene_plan: dict[str, Any],
    group_map: dict[str, dict[str, Any]],
    valid_components: list[dict[str, Any]],
    by_group: dict[str, list[dict[str, Any]]],
    errors: list[dict[str, Any]],
) -> None:
    if not isinstance(style, dict) or style.get("schema_version") != SCHEMA_VERSION:
        errors.append(_error("LOW_POLY_STYLE_VIOLATION", "style_profile.json 缺失或版本非法"))
        return
    if style.get("status") != "planned":
        errors.append(_error("LOW_POLY_STYLE_VIOLATION", "style_profile.status 必须为 planned"))
    if style.get("style_mode") not in {"low_poly", "blockbench_ysm", "stylized_primitive", "custom"}:
        errors.append(_error("LOW_POLY_STYLE_VIOLATION", "style_mode 非法"))
    shape = style.get("shape_language")
    if not isinstance(shape, dict) or shape.get("silhouette_first") is not True or shape.get("large_planes_first") is not True:
        errors.append(_error("LOW_POLY_STYLE_VIOLATION", "低模必须启用轮廓优先和大平面优先"))
    surface = style.get("surface_language")
    if not isinstance(surface, dict):
        errors.append(_error("LOW_POLY_STYLE_VIOLATION", "缺少 surface_language"))
        surface = {}
    palette_max = surface.get("palette_max_colors")
    if not isinstance(palette_max, int) or isinstance(palette_max, bool) or palette_max < 1:
        errors.append(_error("LOW_POLY_STYLE_VIOLATION", "palette_max_colors 非法"))
        palette_max = 0
    if surface.get("allow_noise") is not False or surface.get("allow_pixel_sampling") is not False:
        errors.append(_error("LOW_POLY_STYLE_VIOLATION", "低模档案禁止噪点和逐像素采样"))
    actual_colors = {str(component["color"]).upper() for component in valid_components}
    if palette_max and len(actual_colors) > palette_max:
        errors.append(
            _error(
                "LOW_POLY_STYLE_VIOLATION",
                "实际颜色数量超过低模调色板上限",
                actual=len(actual_colors),
                maximum=palette_max,
            )
        )

    budgets = style.get("budgets")
    if not isinstance(budgets, dict):
        errors.append(_error("LOW_POLY_STYLE_VIOLATION", "缺少低模预算"))
        budgets = {}
    total_max = budgets.get("total_component_max")
    if not isinstance(total_max, int) or isinstance(total_max, bool) or total_max < 1:
        errors.append(_error("LOW_POLY_STYLE_VIOLATION", "total_component_max 非法"))
    elif len(valid_components) > total_max:
        errors.append(
            _error(
                "LOW_POLY_STYLE_VIOLATION",
                "总组件数超过低模预算",
                actual=len(valid_components),
                maximum=total_max,
            )
        )
    primary_min = budgets.get("primary_structure_fraction_min")
    detail_max = budgets.get("detail_component_fraction_max")
    for name, value in (
        ("primary_structure_fraction_min", primary_min),
        ("detail_component_fraction_max", detail_max),
        ("silhouette_tolerance_fraction", budgets.get("silhouette_tolerance_fraction")),
        ("minimum_projected_feature_fraction", budgets.get("minimum_projected_feature_fraction")),
    ):
        if not _finite_number(value) or not 0 <= float(value) <= 1:
            errors.append(_error("LOW_POLY_STYLE_VIOLATION", f"{name} 非法"))

    overrides = style.get("group_overrides")
    if not isinstance(overrides, list):
        errors.append(_error("LOW_POLY_STYLE_VIOLATION", "group_overrides 必须是数组"))
        overrides = []
    override_map: dict[str, dict[str, Any]] = {}
    primary_count = 0
    detail_count = 0
    for override in overrides:
        if not isinstance(override, dict):
            errors.append(_error("LOW_POLY_STYLE_VIOLATION", "组风格覆盖必须是对象"))
            continue
        group_id = override.get("group_id")
        if group_id not in group_map or group_id in override_map:
            errors.append(_error("LOW_POLY_STYLE_VIOLATION", f"组风格覆盖引用非法或重复：{group_id}"))
            continue
        override_map[str(group_id)] = override
        items = by_group.get(str(group_id), [])
        component_max = override.get("component_max")
        color_max = override.get("color_max")
        if not isinstance(component_max, int) or isinstance(component_max, bool) or component_max < 1:
            errors.append(_error("LOW_POLY_STYLE_VIOLATION", f"{group_id} 的 component_max 非法"))
        elif len(items) > component_max:
            errors.append(_error("LOW_POLY_STYLE_VIOLATION", f"{group_id} 超过组级低模组件预算"))
        if not isinstance(color_max, int) or isinstance(color_max, bool) or color_max < 1:
            errors.append(_error("LOW_POLY_STYLE_VIOLATION", f"{group_id} 的 color_max 非法"))
        elif len({str(item["color"]).upper() for item in items}) > color_max:
            errors.append(_error("LOW_POLY_STYLE_VIOLATION", f"{group_id} 超过组级颜色预算"))
        role = override.get("role")
        if role == "primary":
            primary_count += len(items)
        elif role == "detail":
            detail_count += len(items)
        elif role not in {"secondary", "connector"}:
            errors.append(_error("LOW_POLY_STYLE_VIOLATION", f"{group_id} 的低模角色非法"))
        if not str(override.get("reason", "")).strip():
            errors.append(_error("LOW_POLY_STYLE_VIOLATION", f"{group_id} 缺少预算理由"))
    missing_overrides = sorted(set(group_map) - set(override_map))
    if missing_overrides:
        errors.append(_error("LOW_POLY_STYLE_VIOLATION", "存在没有低模预算覆盖的组", group_ids=missing_overrides))
    total_count = len(valid_components)
    if total_count and _finite_number(primary_min) and primary_count / total_count < float(primary_min):
        errors.append(_error("LOW_POLY_STYLE_VIOLATION", "主结构组件占比低于风格下限"))
    if total_count and _finite_number(detail_max) and detail_count / total_count > float(detail_max):
        errors.append(_error("LOW_POLY_STYLE_VIOLATION", "细节组件占比超过风格上限"))

    depth_layers = scene_plan.get("camera_plan", {}).get("depth_layers", [])
    layer_map = {
        str(layer.get("layer_id")): layer
        for layer in depth_layers
        if isinstance(layer, dict) and isinstance(layer.get("layer_id"), str)
    }
    depth_lod = style.get("depth_lod")
    if not isinstance(depth_lod, list):
        errors.append(_error("LOW_POLY_STYLE_VIOLATION", "depth_lod 必须是数组"))
        depth_lod = []
    lod_map: dict[str, dict[str, Any]] = {}
    for lod in depth_lod:
        if not isinstance(lod, dict):
            errors.append(_error("LOW_POLY_STYLE_VIOLATION", "depth_lod 项必须是对象"))
            continue
        layer_id = lod.get("layer_id")
        if layer_id not in layer_map or layer_id in lod_map:
            errors.append(_error("LOW_POLY_STYLE_VIOLATION", f"depth_lod 引用了非法或重复层：{layer_id}"))
            continue
        lod_map[str(layer_id)] = lod
        component_max = lod.get("max_components_per_group")
        color_max = lod.get("max_colors_per_group")
        if not isinstance(component_max, int) or component_max < 1:
            errors.append(_error("LOW_POLY_STYLE_VIOLATION", f"{layer_id} 的 max_components_per_group 非法"))
            continue
        if not isinstance(color_max, int) or color_max < 1:
            errors.append(_error("LOW_POLY_STYLE_VIOLATION", f"{layer_id} 的 max_colors_per_group 非法"))
            continue
        for group_id in layer_map[str(layer_id)].get("group_ids", []):
            items = by_group.get(str(group_id), [])
            if len(items) > component_max:
                errors.append(_error("LOW_POLY_STYLE_VIOLATION", f"{group_id} 超过深度层组件预算"))
            if len({str(item["color"]).upper() for item in items}) > color_max:
                errors.append(_error("LOW_POLY_STYLE_VIOLATION", f"{group_id} 超过深度层颜色预算"))
            if lod.get("allow_micro_detail") is False:
                override = override_map.get(str(group_id), {})
                if override.get("role") == "detail" and items:
                    errors.append(_error("LOW_POLY_STYLE_VIOLATION", f"{layer_id} 禁止微型细节，但 {group_id} 仍包含细节组件"))
    if set(lod_map) != set(layer_map):
        errors.append(
            _error(
                "LOW_POLY_STYLE_VIOLATION",
                "depth_lod 必须与场景深度层一一对应",
                missing=sorted(set(layer_map) - set(lod_map)),
                extra=sorted(set(lod_map) - set(layer_map)),
            )
        )

    forbidden = style.get("forbidden_patterns")
    required_forbidden = {"uniform_micro_tiles", "pixel_noise", "unjustified_subdivision"}
    if not isinstance(forbidden, list) or not required_forbidden <= set(forbidden):
        errors.append(_error("LOW_POLY_STYLE_VIOLATION", "forbidden_patterns 缺少基础低模禁区"))


def validate_reconstruction(
    reference: Any,
    decomposition: Any,
    style: Any,
    scene_plan: dict[str, Any],
    group_map: dict[str, dict[str, Any]],
    valid_components: list[dict[str, Any]],
    by_group: dict[str, list[dict[str, Any]]],
) -> list[dict[str, Any]]:
    errors: list[dict[str, Any]] = []
    coordinate_plan = scene_plan.get("coordinate_plan", {}) if isinstance(scene_plan, dict) else {}
    _validate_reference_analysis(
        reference,
        group_map,
        valid_components,
        by_group,
        coordinate_plan,
        errors,
    )
    _validate_decomposition(decomposition, group_map, errors)
    _validate_style_profile(style, scene_plan, group_map, valid_components, by_group, errors)
    return errors
