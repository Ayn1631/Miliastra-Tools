"""可选：Python Playwright 运行真实 viewer.js。不是游戏实体线厚标定。"""
from pathlib import Path
import argparse
import os
import shutil
import base64
import json
import re
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description="用内置 viewer.js 对六组原生线框输入做隔离浏览器验证。")
parser.add_argument("--output", type=Path, default=root / "tests/render_checks/wireframe_recipes")
parser.add_argument("--chromium", help="可选 Chromium 可执行文件路径；未指定时查找系统 Chromium 或 Playwright 自带浏览器。")
args = parser.parse_args()
out = args.output.resolve()
out.mkdir(parents=True, exist_ok=True)
html = (root/'assets/viewer/index.html').read_text()
html = re.sub(r'<link\b[^>]*rel=["\']stylesheet["\'][^>]*>', '', html, flags=re.I)
html = re.sub(r'<script\b[^>]*src=["\'][^"\']+["\'][^>]*>\s*</script>', '', html, flags=re.I)
css = (root/'assets/viewer/styles.css').read_text()
js = (root/'assets/viewer/viewer.js').read_text()
examples = json.loads((root/'assets/recipes/wireframe_examples.json').read_text())['examples']
catalog = json.loads((root/'assets/primitive_catalog.json').read_text())
labels = ['水平圆环 · XZ','竖直圆环 · XY','水平椭圆环 · XZ','正面矩形框 · XY','水平矩形框 · XZ','侧面矩形框 · YZ']
results, cards = [], []
with sync_playwright() as p:
    executable = args.chromium or os.environ.get("GPT2GIA_CHROMIUM_EXECUTABLE") or shutil.which("chromium")
    launch = {"headless": True}
    if executable:
        launch["executable_path"] = executable
    browser = p.chromium.launch(**launch)
    try:
        for example, label in zip(examples, labels):
            payload = {
                'components': {'schema_version':'2.2.0','components':[example['component']]},
                'assembly': {'groups':[{'group_id':'wireframe_recipe'}]},
                'scene_plan': {'coordinate_plan':{'ground_y':None}},
                'manifest': {'project_name':label+' · 单原生基元'},
                'catalog': catalog,
            }
            page = browser.new_page(viewport={'width':900,'height':640}, device_scale_factor=1)
            errors=[]
            page.on('pageerror', lambda err: errors.append(str(err)))
            page.set_content(html)
            page.add_style_tag(content=css)
            page.add_script_tag(content='window.GPT2GIA_SCENE='+json.dumps(payload,ensure_ascii=False)+';')
            page.add_script_tag(content=js)
            page.wait_for_function('window.renderReady===true')
            meta=page.evaluate('window.GPT2GIA_PREVIEW_INFO')
            path=out/(example['recipe_id']+'.png')
            page.screenshot(path=str(path))
            results.append({'recipe_id':example['recipe_id'],'component_count':1,
                            'backend':'python_playwright_chromium_same_viewer',
                            'page_errors':errors,'preview_metadata':meta,'file':path.name})
            if errors: raise RuntimeError(errors)
            cards.append('<figure><img src="data:image/png;base64,'+base64.b64encode(path.read_bytes()).decode()+'"><figcaption>'+label+'</figcaption></figure>')
            page.close()
        page=browser.new_page(viewport={'width':1440,'height':1220},device_scale_factor=1)
        page.set_content('''<!doctype html><html lang="zh-CN"><meta charset="UTF-8"><style>
        *{box-sizing:border-box}body{margin:0;background:#09101b;color:#e8eff9;font-family:Arial,"Noto Sans CJK SC",sans-serif}
        header{height:94px;padding:19px 24px}h1{font-size:23px;margin:0 0 9px}p{margin:0;color:#b4c3d8;font-size:14px}
        main{display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;padding:0 20px}
        figure{margin:0;position:relative;border:1px solid #2d4058;border-radius:8px;overflow:hidden;background:#111b2c}
        img{display:block;width:100%;height:482px;object-fit:contain}figcaption{padding:12px 16px;background:#142237;font-size:17px}
        footer{padding:16px 24px;color:#b4c3d8;font-size:14px}
        </style><header><h1>GPT2GIA v2.4.0 · 单基元环框验证</h1><p>每格 1 个原生组件；同一 viewer.js 实际渲染。线厚不随缩放改变，固定像素预览不代表游戏线厚已标定。</p></header><main>'''+''.join(cards)+'''</main><footer>压扁尺度均为正数。所有输入是隔离测试示例，不是已确认的用户场景。</footer></html>''')
        page.wait_for_function('Array.from(document.images).every(img=>img.complete)')
        page.screenshot(path=str(out/'contact_sheet.png'))
        page.close()
    finally:
        browser.close()
(out/'render_results.json').write_text(json.dumps({'scope':'isolated_technique_renderer_check_not_game_validation','results':results},ensure_ascii=False,indent=2)+'\n')
print(out/'contact_sheet.png')
print('6 个实际浏览器渲染完成，页面错误 0。')
