"""基元复用回归。所有审批是隔离的合成夹具，不构成任何用户任务授权。"""
from __future__ import annotations

import copy
import importlib.util
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SKILL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL / 'scripts'))
from common import component_aabb, load_json, write_json
from prompt_workflow import (
    WIREFRAME_POLICY, PromptGateError, _write_draft, default_contract,
    inspect_workflow, prepare, record_confirmation, revise,
    validate_contract, validate_wireframe_requirements,
)
from init_archive import initialize
from build_scene_data import build_scene_data
from test_skill import fixture_prompt

SNIPPET = (SKILL / 'references/primitive-recipes.prompt.md').read_text(encoding='utf-8')


def bare_prompt() -> str:
    return fixture_prompt().replace(SNIPPET + '\n', '', 1)


class PrimitiveRecipesTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='gpt2gia_recipe_test_')
        self.root = Path(self.tmp.name)
        self.draft = self.root / 'draft.md'
        self.draft.write_text(fixture_prompt(), encoding='utf-8')
        self.message = self.root / 'synthetic_confirmation.txt'
        self.message.write_text('仅限隔离自动测试：同意测试夹具，不是实际用户确认。', encoding='utf-8')

    def tearDown(self):
        self.tmp.cleanup()

    def prepare(self, contract=None):
        path = None
        if contract is not None:
            path = self.root / 'contract.json'
            write_json(path, contract)
        return prepare('recipe', self.root / 'projects', self.draft, path)

    def confirm(self, project):
        state = load_json(project / 'prompt_state.json')
        return record_confirmation(project, self.message, 'unittest://recipe-synthetic-not-user-approval',
                                   state['prompt_sha256'], state['contract_sha256'])

    def assert_gate(self, call, code):
        with self.assertRaises(PromptGateError) as raised:
            call()
        self.assertIn(code, [item['code'] for item in raised.exception.issues])

    def probe(self, components, name='geometry_probe.cjs'):
        result = subprocess.run(['node', str(SKILL / 'tests' / name), str(SKILL / 'assets/viewer/viewer.js')],
                                input=json.dumps(components), capture_output=True, text=True, check=True, timeout=20)
        return json.loads(result.stdout)

    def test_r01_default_policy_and_bundled_contract_agree(self):
        self.assertEqual(default_contract(), load_json(SKILL / 'assets/templates/prompt_contract.json'))
        self.assertIs(default_contract()['wireframe_policy']['thickness_scales_with_object'], False)
        self.assertIsNone(default_contract()['wireframe_policy']['thickness_value'])

    def test_r02_invalid_scaling_and_invented_physical_thickness_rejected(self):
        for key, value in [('thickness_scales_with_object', True), ('thickness_value', 0.01),
                           ('flattening_scale', 'zero'), ('preview_mode', 'calibrated_world_space')]:
            with self.subTest(key=key):
                contract = default_contract(); contract['wireframe_policy'][key] = value
                self.assertTrue(validate_contract(contract))

    def test_r03_boolean_type_is_not_interchangeable_with_zero(self):
        contract = default_contract(); contract['wireframe_policy']['thickness_scales_with_object'] = 0
        self.assertTrue(validate_contract(contract))

    def test_r04_default_policy_is_not_shared_mutable_state(self):
        contract = default_contract(); contract['wireframe_policy']['thickness_value'] = 100
        self.assertIsNone(default_contract()['wireframe_policy']['thickness_value'])

    def test_r05_legacy_policy_omission_is_readable_but_not_new_draft(self):
        contract = default_contract(); contract.pop('wireframe_policy')
        self.assertEqual(validate_contract(contract), [])
        self.assertEqual(validate_wireframe_requirements(bare_prompt().encode(), contract, require_current=False), [])
        self.assert_gate(lambda: self.prepare(contract), 'PROMPT_WIREFRAME_POLICY_REQUIRED')

    def test_r06_missing_techniques_blocked_before_directory_creation(self):
        self.draft.write_text(bare_prompt(), encoding='utf-8')
        self.assert_gate(self.prepare, 'PROMPT_WIREFRAME_TECHNIQUE_MISSING')
        self.assertFalse((self.root / 'projects/recipe').exists())

    def test_r07_rules_must_be_in_technical_chapter(self):
        self.draft.write_text(bare_prompt() + '\n' + SNIPPET, encoding='utf-8')
        self.assert_gate(self.prepare, 'PROMPT_WIREFRAME_TECHNIQUE_MISSING')

    def test_r08_fenced_example_cannot_replace_actual_rules(self):
        text = bare_prompt().replace('# 三、测试结构', '```markdown\n' + SNIPPET + '\n```\n# 三、测试结构')
        self.draft.write_text(text, encoding='utf-8')
        self.assert_gate(self.prepare, 'PROMPT_WIREFRAME_TECHNIQUE_MISSING')

    def test_r09_cuboid_only_does_not_require_or_enable_wireframes(self):
        contract = default_contract(); contract['allowed_template_ids'] = [10009001]
        contract['representation_mode'] = 'cuboid_only'; contract.pop('wireframe_policy')
        self.draft.write_text(bare_prompt(), encoding='utf-8')
        project = self.prepare(contract)
        self.assertEqual(load_json(project / 'prompt_contract.json')['allowed_template_ids'], [10009001])
        self.assertFalse((project / 'components.json').exists())

    def test_r10_restricted_wirebox_does_not_require_cylinder(self):
        contract = default_contract(); contract['allowed_template_ids'] = [10009010]
        contract['representation_mode'] = 'restricted_primitives'
        text = bare_prompt().replace('# 三、测试结构',
            '10009010 压扁为矩形框；本任务无框架，故不使用。线厚不随缩放改变。固定像素预览，游戏线厚未标定。\n\n# 三、测试结构')
        self.draft.write_text(text, encoding='utf-8')
        self.assertTrue(self.prepare(contract).exists())

    def test_r11_allowing_wires_does_not_force_actual_ring_geometry(self):
        project = self.prepare(); self.confirm(project)
        initialize(project.name, project.parent)
        self.assertEqual(load_json(project / 'components.json')['components'], [])

    def test_r12_fixed_thickness_phrase_cannot_be_omitted(self):
        self.draft.write_text(fixture_prompt().replace('线厚不随缩放改变', '线框大小可以调整'), encoding='utf-8')
        self.assert_gate(self.prepare, 'PROMPT_WIREFRAME_TECHNIQUE_MISSING')

    def test_r13_pixel_proxy_disclaimer_cannot_be_omitted(self):
        self.draft.write_text(fixture_prompt().replace('固定像素', '真实实体'), encoding='utf-8')
        self.assert_gate(self.prepare, 'PROMPT_WIREFRAME_TECHNIQUE_MISSING')

    def test_r14_catalog_fixed_thickness_metadata_consistent(self):
        entries = load_json(SKILL / 'assets/primitive_catalog.json')['primitives']
        self.assertEqual(len(entries), 11)
        for item in entries:
            if item['template_id'] in {10009010, 10009011}:
                self.assertEqual(item['wireframe_semantics'], WIREFRAME_POLICY)
                self.assertFalse(item['solid'])
            else:
                self.assertNotIn('wireframe_semantics', item)

    @unittest.skipUnless(importlib.util.find_spec('jsonschema'), 'JSON Schema 对照需要 jsonschema')
    def test_r15_examples_match_unchanged_component_schema(self):
        import jsonschema
        schema = load_json(SKILL / 'assets/schemas/components.schema.json')
        for example in load_json(SKILL / 'assets/recipes/wireframe_examples.json')['examples']:
            with self.subTest(recipe=example['recipe_id']):
                jsonschema.validate({'schema_version':'2.2.0', 'components':[example['component']]}, schema)
                self.assertEqual(example['export_component_count'], 1)
                self.assertTrue(all(value > 0 for value in example['component']['scale']))

    def test_r16_export_retains_one_native_component_and_continuous_values(self):
        project = self.prepare(); self.confirm(project); initialize(project.name, project.parent)
        for example in load_json(SKILL / 'assets/recipes/wireframe_examples.json')['examples']:
            component = copy.deepcopy(example['component']); component['position'][0] = 1.2345678912345
            write_json(project / 'components.json', {'schema_version':'2.2.0', 'components':[component]})
            target = build_scene_data(project)
            data = json.loads(target.read_text(encoding='utf-8')[len('window.GPT2GIA_SCENE='):-2])
            self.assertEqual(data['components']['components'], [component])
            self.assertEqual(len(data['components']['components']), 1)

    @unittest.skipUnless(shutil.which('node'), '预览几何对照需要 Node.js')
    def test_r17_six_flattened_recipes_match_expected_axes(self):
        examples = load_json(SKILL / 'assets/recipes/wireframe_examples.json')['examples']
        results = self.probe([item['component'] for item in examples])
        thin_axes = [1, 2, 1, 2, 1, 0]
        for example, actual, thin_axis in zip(examples, results, thin_axes):
            with self.subTest(recipe=example['recipe_id']):
                minimum, maximum = component_aabb(example['component'])
                for axis in range(3):
                    self.assertAlmostEqual(actual['min'][axis], minimum[axis], places=9)
                    self.assertAlmostEqual(actual['max'][axis], maximum[axis], places=9)
                dimensions = [b-a for a,b in zip(actual['min'], actual['max'])]
                self.assertEqual(dimensions.index(min(dimensions)), thin_axis)
                self.assertAlmostEqual(min(dimensions), min(example['component']['scale']), places=9)

    @unittest.skipUnless(shutil.which('node'), '预览几何对照需要 Node.js')
    def test_r18_wire_ring_frame_are_not_filled_discs_or_surfaces(self):
        components = [{'template_id':tid,'position':[0,0,0],'rotation':[0,0,0],'scale':[3,0.001367,3]}
                      for tid in (10009011,10009010,10009008)]
        actual = self.probe(components)
        self.assertEqual([item['face_count'] for item in actual[:2]], [0,0])
        self.assertTrue(all(item['wire'] for item in actual[:2]))
        self.assertGreater(actual[2]['face_count'], 0)
        self.assertFalse(actual[2]['wire'])

    @unittest.skipUnless(shutil.which('node'), 'Canvas 描边调用验证需要 Node.js')
    def test_r19_actual_strokes_independent_of_size_and_flattening(self):
        cases=[]
        for tid in (10009010,10009011):
            for scale in ([1,1,1],[10,10,10],[0.1,0.1,0.1],[5,0.001367,5],
                          [5,3,0.002731],[12.3456789,0.003451,3.2109876]):
                cases.append({'id':'test_wire','template_id':tid,'position':[0,0,0],
                              'rotation':[0,0,0],'scale':scale,'color':'#9EDDD2'})
        for actual in self.probe(cases, 'wireframe_preview_probe.cjs'):
            self.assertTrue(actual['ready'])
            self.assertEqual(actual['widths'], [2.2])
            self.assertGreater(actual['stroke_count'], 0)

    @unittest.skipUnless(shutil.which('node'), '预览语义验证需要 Node.js')
    def test_r20_preview_exposes_unknown_physical_thickness_and_legend(self):
        case={'id':'test_wire','template_id':10009011,'position':[0,0,0],
              'rotation':[0,0,0],'scale':[4,0.001367,4],'color':'#9EDDD2'}
        result = self.probe([case], 'wireframe_preview_probe.cjs')[0]
        self.assertIsNone(result['metadata']['wireframe']['physicalThickness'])
        self.assertFalse(result['metadata']['wireframe']['thicknessScalesWithObject'])
        self.assertIn('未标定', result['legend'])

    def test_r21_zero_negative_and_nonfinite_flattening_blocked(self):
        project = self.prepare(); self.confirm(project); initialize(project.name, project.parent)
        for value in (0, -0.001, float('nan'), float('inf')):
            component={'id':'bad_flat','template_id':10009011,'position':[0,0,0],
                       'rotation':[0,0,0],'scale':[4,value,4],'color':'#9EDDD2'}
            # 故意构造非法 JSON 测试输入；生产 write_json 禁止 NaN/Infinity。
            (project / 'components.json').write_text(json.dumps({'components':[component]}), encoding='utf-8')
            self.assert_gate(lambda: build_scene_data(project), 'TRANSFORM_CONTRACT_ERROR')

    def legacy_project(self):
        project = self.root / 'legacy'; project.mkdir()
        contract = default_contract(); contract.pop('wireframe_policy')
        # 构造历史版本文件形态，仅限当前临时测试目录。
        _write_draft(project, bare_prompt().encode(), contract, 1)
        self.confirm(project)
        return project

    def test_r22_legacy_confirmed_project_not_silently_mutated(self):
        project = self.legacy_project()
        before = {name:(project/name).read_bytes() for name in ('prompt.md','prompt_contract.json','prompt_state.json')}
        self.assertEqual(inspect_workflow(project), [])
        initialize(project.name, project.parent)
        self.assertEqual(before, {name:(project/name).read_bytes() for name in before})

    def test_r23_legacy_revision_requires_current_policy_and_reconfirmation(self):
        project = self.legacy_project()
        self.assert_gate(lambda: revise(project, self.draft), 'PROMPT_WIREFRAME_POLICY_REQUIRED')
        contract_path = self.root / 'new_contract.json'; write_json(contract_path, default_contract())
        state = revise(project, self.draft, contract_path)
        self.assertEqual(state['status'], 'awaiting_user_confirmation')
        self.assertIsNone(state['approval'])

    def test_r24_rule_mutation_invalidates_existing_approval(self):
        project = self.prepare(); self.confirm(project)
        contract = load_json(project / 'prompt_contract.json')
        contract['wireframe_policy']['thickness_scales_with_object'] = True
        write_json(project / 'prompt_contract.json', contract)
        codes = [item['code'] for item in inspect_workflow(project)]
        self.assertIn('PROMPT_CONTRACT_INVALID', codes)
        self.assertIn('PROMPT_CHANGED', codes)

    @unittest.skipUnless(importlib.util.find_spec('jsonschema'), 'JSON Schema 对照需要 jsonschema')
    def test_r25_policy_schema_matches_python_validator(self):
        import jsonschema
        schema = load_json(SKILL / 'assets/schemas/prompt_contract.schema.json')
        contract = default_contract(); jsonschema.validate(contract, schema)
        legacy = copy.deepcopy(contract); legacy.pop('wireframe_policy'); jsonschema.validate(legacy, schema)
        contract['wireframe_policy']['thickness_scales_with_object'] = True
        with self.assertRaises(jsonschema.ValidationError): jsonschema.validate(contract, schema)

    def test_r26_recipe_required_reading_and_original_template_preserved(self):
        text = (SKILL / 'SKILL.md').read_text(encoding='utf-8')
        self.assertIn('references/primitive-recipes.md', text)
        self.assertIn('references/primitive-recipes.prompt.md', text)
        self.assertIn('线厚不随缩放改变', text)
        template = (SKILL / 'references/template.prompt.md').read_text(encoding='utf-8')
        self.assertNotIn('wireframe_policy', template)


if __name__ == '__main__':
    unittest.main(verbosity=2)
