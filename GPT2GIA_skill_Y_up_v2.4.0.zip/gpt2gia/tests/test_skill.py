"""修改版 Skill 的离线回归测试。所有确认消息均是隔离目录中的合成夹具。"""
from __future__ import annotations

import copy
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SKILL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL / "scripts"))
from common import component_aabb, load_json, write_json
from prompt_workflow import (
    ORDINALS, PromptGateError, default_contract, inspect_workflow, prepare, record_confirmation,
    require_approved, revise, sync_manifest, validate_contract, validate_prompt_bytes,
)
from init_archive import initialize
from build_scene_data import build_scene_data
from package_archive import package_project
from validate_archive import validate_project
from verify_artifacts import verify_project

TEMPLATE_SHA256 = "641e83ac29cbbcae166590ab226d79c11e66a93545c43aa10a6a8a50dbbef7ed"


def fixture_prompt() -> str:
    # 不属于真实用户任务，不携带可用于真实建模的用户授权。
    sections = ["# 隔离回归测试提示词\n\n仅用于脚本测试，不代表用户批准建模。"]
    for ordinal in ORDINALS:
        sections.append(f"# {ordinal}、测试结构\n\n本章明确检查组件、场景、接口、比例与输出约束。采用 Y-up 坐标和连续浮点值，禁止默认量化。本例只测试流程与数据，不认定视觉任务已完成。")
    text = "\n\n".join(sections) + "\n"
    technique = (SKILL / "references/primitive-recipes.prompt.md").read_text(encoding="utf-8")
    return text.replace("# 三、测试结构", technique + "\n# 三、测试结构", 1)


class SkillTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="gpt2gia_unittest_")
        self.root = Path(self.tmp.name)
        self.draft = self.root / "draft.md"
        self.draft.write_text(fixture_prompt(), encoding="utf-8")
        self.message = self.root / "fixture_message.txt"
        self.message.write_text("仅限自动测试夹具：同意测试此草稿。此文本不代表真实用户确认。", encoding="utf-8")

    def tearDown(self):
        self.tmp.cleanup()

    def create(self, contract=None, name="subject"):
        path = None
        if contract is not None:
            path = self.root / f"{name}_contract.json"
            write_json(path, contract)
        return prepare(name, self.root / "work", self.draft, path)

    def approve_fixture(self, project):
        state = load_json(project / "prompt_state.json")
        record_confirmation(project, self.message, "unittest://synthetic-confirmation-not-a-user-message",
                            state["prompt_sha256"], state["contract_sha256"])

    def initialized(self, example=None, contract=None):
        project = self.create(contract)
        self.approve_fixture(project)
        initialize(project.name, project.parent, example)
        return project

    def assert_gate(self, function, code):
        with self.assertRaises(PromptGateError) as ctx:
            function()
        self.assertIn(code, [item["code"] for item in ctx.exception.issues])

    def test_01_template_is_exact_user_upload(self):
        self.assertEqual(hashlib.sha256((SKILL / "references/template.prompt.md").read_bytes()).hexdigest(), TEMPLATE_SHA256)

    def test_02_template_has_complete_structure(self):
        self.assertEqual(validate_prompt_bytes((SKILL / "references/template.prompt.md").read_bytes()), [])

    def test_03_incomplete_prompt_rejected_without_project(self):
        self.draft.write_text("Y-up 连续浮点\n先规划，再建模。", encoding="utf-8")
        self.assert_gate(self.create, "PROMPT_STRUCTURE_INVALID")
        self.assertFalse((self.root / "work/subject").exists())

    def test_04_fenced_headings_do_not_count(self):
        value = "```markdown\n" + fixture_prompt() + "```\n"
        self.assertTrue(validate_prompt_bytes(value.encode()))

    def test_05_placeholder_is_rejected(self):
        self.assertTrue(validate_prompt_bytes((fixture_prompt()+"\n{{待填写场景}}\n").encode()))

    def test_06_invalid_contract_types(self):
        for value in ([], None, "bad", {"allowed_template_ids": [[10009001]]}):
            with self.subTest(value=value):
                self.assertTrue(validate_contract(value))

    def test_07_z_up_is_rejected(self):
        contract = default_contract()
        contract["coordinate_system"]["y"] = "depth"
        contract["coordinate_system"]["z"] = "up"
        self.assert_gate(lambda: self.create(contract), "PROMPT_CONTRACT_INVALID")

    def test_08_quantization_and_fixed_precision_rejected(self):
        for key, value in (("quantization_step", 0.01), ("fixed_decimal_places", 4)):
            contract = default_contract(); contract[key] = value
            with self.subTest(key=key):
                self.assertTrue(validate_contract(contract))

    def test_09_prepare_only_creates_planning_files(self):
        project = self.create()
        self.assertEqual({p.name for p in project.iterdir()},
                         {"prompt.md", "prompt_state.json", "prompt_contract.json", "prompt_log.jsonl"})
        state = load_json(project / "prompt_state.json")
        self.assertEqual(state["status"], "awaiting_user_confirmation")
        self.assertIsNone(state["approval"])

    def test_10_initialize_without_prompt_is_blocked(self):
        self.assert_gate(lambda: initialize("subject", self.root), "PROMPT_REQUIRED")
        self.assertFalse((self.root / "subject").exists())

    def test_11_initialize_before_confirmation_is_blocked(self):
        project = self.create()
        self.assert_gate(lambda: initialize(project.name, project.parent), "PROMPT_NOT_APPROVED")
        self.assertFalse((project / "components.json").exists())

    def test_12_build_before_confirmation_is_blocked(self):
        project = self.create()
        self.assert_gate(lambda: build_scene_data(project), "PROMPT_NOT_APPROVED")
        self.assertFalse((project / "preview").exists())

    def test_13_validator_reports_prompt_issue(self):
        project = self.create()
        result = validate_project(project)
        self.assertEqual(result["status"], "FAILED")
        self.assertIn("PROMPT_NOT_APPROVED", [e["code"] for e in result["errors"]])

    def test_14_artifact_verifier_reports_prompt_issue(self):
        project = self.create()
        self.assertIn("PROMPT_NOT_APPROVED", [e["code"] for e in verify_project(project)])

    def test_15_packaging_before_confirmation_is_blocked(self):
        project = self.create()
        self.assert_gate(lambda: package_project(project), "PROMPT_NOT_APPROVED")
        self.assertFalse(project.with_suffix(".zip").exists())

    def test_16_empty_confirmation_rejected(self):
        project = self.create(); self.message.write_text(" ", encoding="utf-8")
        self.assert_gate(lambda: self.approve_fixture(project), "PROMPT_APPROVAL_INVALID")

    def test_17_old_hash_confirmation_rejected(self):
        project = self.create(); state=load_json(project / "prompt_state.json")
        self.assert_gate(lambda: record_confirmation(project, self.message, "unittest://old-hash", "0"*64,
                                                      state["contract_sha256"]), "PROMPT_APPROVAL_INVALID")

    def test_18_all_eleven_types_preserved_in_build(self):
        project = self.initialized("adaptive_vehicle")
        source = load_json(project / "components.json")
        content = (project / "preview/scene_data.js").read_text(encoding="utf-8")
        payload = json.loads(content[len("window.GPT2GIA_SCENE="):-2])
        self.assertEqual(payload["components"], source)
        self.assertEqual({c["template_id"] for c in source["components"]}, set(range(10009001, 10009012)))

    def test_19_cuboid_only_manifest_and_sphere_rejection(self):
        contract = default_contract(); contract["allowed_template_ids"] = [10009001]; contract["representation_mode"] = "cuboid_only"
        project = self.initialized(contract=contract)
        self.assertEqual(load_json(project / "manifest.json")["allowed_template_ids"], [10009001])
        write_json(project / "components.json", {"components": [{"id":"bad_sphere", "template_id":10009002,
            "position":[0.,0.,0.], "rotation":[0.,0.,0.], "scale":[1.,1.,1.]}]})
        self.assert_gate(lambda: build_scene_data(project), "PROMPT_CONTRACT_MISMATCH")

    def test_20_restricted_subset_preserved(self):
        contract=default_contract(); contract["allowed_template_ids"]=[10009001,10009008];contract["representation_mode"]="restricted_primitives"
        project=self.initialized(contract=contract)
        self.assertEqual(load_json(project / "manifest.json")["allowed_template_ids"], [10009001,10009008])

    def test_21_prompt_edit_invalidates_approval(self):
        project=self.initialized()
        with (project / "prompt.md").open("a",encoding="utf-8") as f:f.write("\n改变主要目标。\n")
        self.assert_gate(lambda:build_scene_data(project),"PROMPT_CHANGED")

    def test_22_contract_edit_invalidates_approval(self):
        project=self.initialized(); contract=load_json(project / "prompt_contract.json");contract["component_budget_max"]=12
        write_json(project / "prompt_contract.json",contract)
        self.assert_gate(lambda:require_approved(project),"PROMPT_CHANGED")

    def test_23_revision_requires_reconfirmation_and_sync(self):
        project=self.initialized()
        self.draft.write_text(fixture_prompt()+"\n新增一次结构检查。\n",encoding="utf-8")
        state=revise(project,self.draft)
        self.assertEqual(state["revision"],2); self.assertIsNone(state["approval"])
        self.assertEqual(load_json(project / "validation.json")["manual_reviews"],[])
        self.assert_gate(lambda:build_scene_data(project),"PROMPT_NOT_APPROVED")
        self.approve_fixture(project)
        self.assert_gate(lambda:build_scene_data(project),"PROMPT_CONTRACT_MISMATCH")
        sync_manifest(project)
        self.assertTrue(build_scene_data(project).exists())

    def test_24_invalid_component_transform_blocked(self):
        project=self.initialized()
        write_json(project / "components.json", {"components":[{"id":"bad_scale","template_id":10009001,
            "position":[0,0,0],"rotation":[0,0,0],"scale":[1,0,1]}]})
        self.assert_gate(lambda:build_scene_data(project),"TRANSFORM_CONTRACT_ERROR")

    def test_25_manifest_axes_change_blocked(self):
        project=self.initialized();manifest=load_json(project / "manifest.json");manifest["coordinate_system"]["y"]="depth"
        write_json(project / "manifest.json",manifest)
        self.assert_gate(lambda:build_scene_data(project),"PROMPT_CONTRACT_MISMATCH")

    def test_26_manifest_primitive_change_blocked(self):
        project=self.initialized();manifest=load_json(project / "manifest.json");manifest["allowed_template_ids"]=[10009001]
        write_json(project / "manifest.json",manifest)
        self.assert_gate(lambda:build_scene_data(project),"PROMPT_CONTRACT_MISMATCH")

    def test_27_component_budget_enforced(self):
        contract=default_contract();contract["component_budget_max"]=1
        project=self.initialized(contract=contract)
        component={"id":"fixture", "template_id":10009001,"position":[0,0,0],"rotation":[0,0,0],"scale":[1,1,1]}
        write_json(project / "components.json",{"components":[component,component]})
        self.assert_gate(lambda:build_scene_data(project),"PROMPT_CONTRACT_MISMATCH")

    def test_28_stale_screenshot_log_rejected(self):
        project=self.initialized()
        (project / "build_log.jsonl").write_text(json.dumps({"event":"screenshot","mode":"final", "backend":"playwright_browser",
            "prompt_sha256":"0"*64, "contract_sha256":"0"*64})+"\n",encoding="utf-8")
        messages=[e["message"] for e in verify_project(project)]
        self.assertIn("构建日志中没有最终视图渲染事件",messages)

    def test_29_init_wont_overwrite_existing_model(self):
        project=self.initialized()
        with self.assertRaises(FileExistsError):initialize(project.name, project.parent)

    def test_30_init_default_camera_is_y_up(self):
        project=self.initialized();scene=load_json(project / "scene_plan.json")
        self.assertGreater(scene["camera_plan"]["position"][1],0)
        self.assertEqual(scene["camera_plan"]["target"],[0.,1.,0.])
        self.assertEqual(scene["coordinate_plan"]["scene_bounds"]["max"],[1.,2.,1.])

    def test_31_plane_and_cone_bounds(self):
        component={"position":[0.,0.,0.],"rotation":[0.,0.,0.],"scale":[2.,4.,6.]}
        for template_id, expected in ((10009003,([-1.,0.,-3.],[1.,0.,3.])),
                (10009006,([-1.,-1.,-3.],[1.,3.,3.])),(10009007,([-1.,-1.,-3.],[1.,3.,3.])),
                (10009009,([-1.,-1.,-3.],[1.,3.,3.]))):
            with self.subTest(template_id=template_id):
                self.assertEqual(component_aabb({**component,"template_id":template_id}),expected)

    @unittest.skipUnless(shutil.which("node"), "几何对照需要 Node.js")
    def test_32_all_preview_vertices_within_python_bounds(self):
        cases=[]
        for tid in range(10009001,10009012):
            for rotation in ([0.,0.,0.],[37.123456789,81.2987654321,-16.99873456],[-90.,0.,0.]):
                cases.append({"template_id":tid,"position":[1.234567891,2.987654321,-4.123456789],
                              "rotation":rotation,"scale":[2.123456789,4.987654321,6.543219876]})
        result=subprocess.run(["node",str(SKILL/"tests/geometry_probe.cjs"),str(SKILL/"assets/viewer/viewer.js")],
                              input=json.dumps(cases),capture_output=True,text=True,check=True,timeout=20)
        for case, actual in zip(cases,json.loads(result.stdout)):
            minimum,maximum=component_aabb(case)
            with self.subTest(tid=case["template_id"],rotation=case["rotation"]):
                for axis in range(3):
                    self.assertGreaterEqual(actual["min"][axis],minimum[axis]-1e-9)
                    self.assertLessEqual(actual["max"][axis],maximum[axis]+1e-9)
                    if case["template_id"] in {10009001,10009003,10009010}:
                        self.assertAlmostEqual(actual["min"][axis],minimum[axis],places=9)
                        self.assertAlmostEqual(actual["max"][axis],maximum[axis],places=9)

    @unittest.skipUnless(shutil.which("node"), "截图入口测试需要 Node.js")
    def test_33_capture_entry_rejects_unapproved_before_backend(self):
        project=self.create()
        result=subprocess.run(["node",str(SKILL/"scripts/capture_views.mjs"),str(project),"--final"],
                              capture_output=True,text=True,timeout=20)
        self.assertNotEqual(result.returncode,0)
        self.assertIn("PROMPT_NOT_APPROVED",result.stderr+result.stdout)
        self.assertNotIn("BLOCKED_NO_RENDER_BACKEND",result.stderr+result.stdout)

    def test_34_all_json_files_parse(self):
        for path in (SKILL/"assets").rglob("*.json"):
            with self.subTest(path=path.name):json.loads(path.read_text(encoding="utf-8"))

    def test_35_example_exceeding_contract_rejected_before_model_files(self):
        contract=default_contract();contract["allowed_template_ids"]=[10009001];contract["representation_mode"]="cuboid_only"
        project=self.create(contract);self.approve_fixture(project)
        with self.assertRaises(ValueError):initialize(project.name,project.parent,"adaptive_vehicle")
        self.assertFalse((project/"components.json").exists())

    def test_36_fractional_transform_values_retained(self):
        project=self.initialized()
        value=0.1234567890123456
        component={"id":"continuous", "template_id":10009001,"position":[value,value,value],
                   "rotation":[12.3456789012345,0.,0.],"scale":[value,value,value]}
        write_json(project/"components.json",{"components":[component]})
        data=json.loads(build_scene_data(project).read_text(encoding="utf-8")[len("window.GPT2GIA_SCENE="):-2])
        self.assertEqual(data["components"]["components"][0],component)

    def test_37_adaptive_example_has_no_automatic_errors(self):
        project=self.initialized("adaptive_vehicle")
        result=validate_project(project)
        self.assertEqual(result["errors"],[])
        self.assertEqual(result["status"],"NEEDS_REVIEW")

    def test_38_layered_example_has_no_automatic_errors(self):
        project=self.initialized("layered_scene")
        result=validate_project(project)
        self.assertEqual(result["errors"],[])
        self.assertEqual(result["status"],"NEEDS_REVIEW")


    def test_39_planning_validation_does_not_poison_initialization(self):
        project=self.create()
        validate_project(project)
        self.assertFalse((project/"validation.json").exists())
        self.approve_fixture(project)
        self.assertEqual(initialize(project.name,project.parent),project)

    def test_40_bare_approved_or_assistant_approval_is_rejected(self):
        project=self.create();state=load_json(project/"prompt_state.json")
        state["status"]="approved";state["approval"]={"actor":"assistant"}
        write_json(project/"prompt_state.json",state)
        self.assert_gate(lambda:require_approved(project),"PROMPT_APPROVAL_INVALID")

    def test_41_confirmed_subset_revision_does_not_rewrite_components(self):
        project=self.initialized("adaptive_vehicle")
        original=(project/"components.json").read_bytes()
        contract=default_contract();contract["allowed_template_ids"]=[10009001];contract["representation_mode"]="cuboid_only"
        path=self.root/"revised_contract.json";write_json(path,contract)
        revise(project,self.draft,path);self.approve_fixture(project);sync_manifest(project)
        self.assertEqual((project/"components.json").read_bytes(),original)
        self.assert_gate(lambda:build_scene_data(project),"PROMPT_CONTRACT_MISMATCH")

    def test_42_confirmation_requires_message_reference(self):
        project=self.create();state=load_json(project/"prompt_state.json")
        self.assert_gate(lambda:record_confirmation(project,self.message," ",state["prompt_sha256"],
                                                    state["contract_sha256"]),"PROMPT_APPROVAL_INVALID")


if __name__=="__main__":
    unittest.main(verbosity=2)
