/* 运行实际 viewer.js，记录其真实 Canvas stroke 调用。此处不生成像素或模拟游戏实体厚度。 */
'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const source = fs.readFileSync(process.argv[2], 'utf8');
const cases = JSON.parse(fs.readFileSync(0, 'utf8'));
const results = cases.map(component => {
  const strokes = [];
  const context = {
    lineWidth: 1,
    createLinearGradient() { return { addColorStop() {} }; },
    save() {}, restore() {}, beginPath() {}, moveTo() {}, lineTo() {}, closePath() {},
    fill() {}, fillRect() {},
    stroke() { strokes.push({ width: this.lineWidth, color: this.strokeStyle }); },
  };
  const fake = () => ({ textContent: '', classList: { toggle() {} }, addEventListener() {} });
  const canvas = {
    width: 900, height: 600, clientWidth: 900, clientHeight: 600,
    getContext() { return context; }, addEventListener() {}, setPointerCapture() {},
  };
  const elements = new Map([['viewport', canvas], ['project-name', fake()], ['scene-stats', fake()],
    ['legend', fake()], ['debug-toggle', fake()]]);
  const sandbox = {
    window: {
      GPT2GIA_SCENE: {
        components: { components: [component] }, assembly: { groups: [] }, manifest: {},
        scene_plan: { coordinate_plan: { ground_y: null } },
      }, devicePixelRatio: 1, addEventListener() {},
    },
    document: { getElementById: id => elements.get(id), querySelectorAll: () => [] },
    location: { search: '' }, URLSearchParams,
  };
  vm.runInNewContext(source, sandbox, { timeout: 10000 });
  return {
    ready: sandbox.window.renderReady,
    widths: [...new Set(strokes.map(stroke => stroke.width))],
    stroke_count: strokes.length,
    metadata: sandbox.window.GPT2GIA_PREVIEW_INFO,
    legend: elements.get('legend').textContent,
  };
});
process.stdout.write(JSON.stringify(results));
