/* 执行实际 viewer.js 中的几何函数，不复制几何算法。仅供回归测试。 */
const fs = require('node:fs');
const vm = require('node:vm');
const source = fs.readFileSync(process.argv[2], 'utf8');
const marker = '  const meshes = components.map((component) => {';
if (!source.includes(marker)) throw new Error('预览器测试插入点已改变');
const instrumented = source.replace(marker,
  '  globalThis.PROBE = { geometryFor, transformVertex }; return;\n' + marker);
const sandbox = {
  window: { GPT2GIA_SCENE: {} },
  document: { getElementById: () => ({ getContext: () => ({}) }) },
  location: { search: '' }, URLSearchParams,
};
vm.runInNewContext(instrumented, sandbox, { timeout: 10000 });
const input = JSON.parse(fs.readFileSync(0, 'utf8'));
const results = input.map(component => {
  const geometry = sandbox.PROBE.geometryFor(component.template_id);
  const vertices = geometry.vertices.map(v => sandbox.PROBE.transformVertex(v, component));
  const min = [Infinity, Infinity, Infinity], max = [-Infinity, -Infinity, -Infinity];
  for (const vertex of vertices) for (let axis = 0; axis < 3; axis++) {
    min[axis] = Math.min(min[axis], vertex[axis]);
    max[axis] = Math.max(max[axis], vertex[axis]);
  }
  return { template_id: component.template_id, min, max, vertex_count: vertices.length,
    edge_count: geometry.edges.length, face_count: geometry.faces.length, wire: geometry.wire };
});
process.stdout.write(JSON.stringify(results));
