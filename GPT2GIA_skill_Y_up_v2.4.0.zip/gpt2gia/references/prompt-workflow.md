# Prompt 审阅与执行检查

## 1. 四个规划文件

`prompt.md` 保存完整任务文本；`prompt_contract.json` 保存机器可检查的技术要求；`prompt_state.json` 保存修订号、状态和确认依据；`prompt_log.jsonl` 保存流程事件。

状态流程为：生成草稿 → awaiting_user_confirmation → 用户确认 → approved → 初始化与建模。任何 Prompt 或契约修改都需要新确认；不提供“跳过确认”的开关。

## 2. 创建待审阅版本

先由执行者根据当前任务生成完整十四章 `draft_prompt.md`，不得直接把模板复制成与任务不符的结果。创建规划目录：

```bash
python3 "$SKILL_DIR/scripts/prompt_workflow.py" prepare project_name --output ./work --prompt ./draft_prompt.md
```

命令只生成规划文件，不创建 `components.json`、`preview` 或截图。它打印两个文件的 SHA-256，供本次审阅绑定。

默认技术契约位于 `assets/templates/prompt_contract.json`。需要限制为长方体时，复制该文件，将 `allowed_template_ids` 改为 `[10009001]`，`representation_mode` 改为 `cuboid_only`。其他子集使用 `restricted_primitives`；`component_budget_max` 为可选正整数，没有确认硬上限时保持 `null`。传入修改后的文件：

```bash
python3 "$SKILL_DIR/scripts/prompt_workflow.py" prepare project_name --output ./work --prompt ./draft_prompt.md --contract ./task_contract.json
```

随后把工程目录里的实际 `prompt.md` 与 `prompt_contract.json` 展示给用户，询问是否确认并停止。不要在同一轮擅自记录确认。

## 3. 记录已经发生的用户确认

只有后续真实用户回复明确同意当前版本时才执行。`user_confirmation.txt` 必须保存该条真实回复原文，`--user-message-ref` 指向实际会话中的可核对消息编号或引用。不能制造“用户已确认”文本、伪造消息引用或把模型自己的答复当作用户回复。

```bash
python3 "$SKILL_DIR/scripts/prompt_workflow.py" record-confirmation ./work/project_name --user-message-file ./user_confirmation.txt --user-message-ref <实际消息引用> --prompt-sha256 <用户审阅版本的Prompt哈希> --contract-sha256 <用户审阅版本的契约哈希>
python3 "$SKILL_DIR/scripts/prompt_workflow.py" check ./work/project_name
python3 "$SKILL_DIR/scripts/init_archive.py" project_name --output ./work
```

原始确认请求里的哈希必须与当前文件一致。初始化拒绝覆盖已存在的模型，同时允许已确认的规划文件留在目录中。

**记录函数不能认证用户身份，也不能理解某条回复是否真的构成同意。消息原文、引用和哈希提供可核查线索；宿主必须对照真实会话。可修改本地文件的程序能绕过此机制，不能把它描述为防篡改或不可绕过的安全授权。**

## 4. 修改与重新确认

```bash
python3 "$SKILL_DIR/scripts/prompt_workflow.py" revise ./work/project_name --prompt ./revised_prompt.md
# 技术要求也变动时增加 --contract ./revised_contract.json。
```

`revise` 递增修订号，删除旧确认，状态回到待用户确认，并清空旧人工验收状态。旧模型和截图暂时保留供对比，不算当前修订已经完成。

重新展示并得到真实确认后记录新确认。已经初始化的工程须显式同步：

```bash
python3 "$SKILL_DIR/scripts/prompt_workflow.py" sync-manifest ./work/project_name
python3 "$SKILL_DIR/scripts/prompt_workflow.py" check ./work/project_name
```

`sync-manifest` 只同步获批基元、坐标和 Prompt 哈希，不会把球体改成长方体，不会自动重建模型。已有组件违背新约束时，检查仍会失败，必须修正。之后重新生成预览、截图并重新验收。

## 5. 检查覆盖范围

| 入口 | 检查 |
|---|---|
| `init_archive.py` | 完整 Prompt、技术契约、真实确认记录字段与哈希匹配；拒绝未确认初始化 |
| `build_scene_data.py` | 上述检查，加清单一致性、组件允许基元/有限变换/数量上限 |
| `capture_views.mjs` | 先调用上述构建入口；截图日志绑定 Prompt 与契约哈希 |
| `validate_archive.py` | 把缺失、未确认、修改、不一致作为自动错误 |
| `verify_artifacts.py` | 必需规划产物、确认一致性，且只认可当前 Prompt 的截图事件 |
| `package_archive.py` | 先检查确认，再运行严格模型及产物验收 |

`analyze_fragmentation.py` 等只读诊断工具不要求确认，以便检查已有问题。`status` 可读取状态；`check` 返回非零表示不能继续。

## 6. Windows

在 PowerShell 中使用已安装的 `python` 代替文档的 `python3`，将 `$SKILL_DIR` 换成实际 Skill 路径。截图脚本默认在 Windows 调用 `python`，其他系统调用 `python3`。有多个 Python 环境时，可设置 `GPT2GIA_PYTHON` 为单个解释器的完整路径；不要在该值里添加命令行参数。

核心流程、验证与测试只用 Python 标准库。真实截图沿用原包的 Node.js 后端，需要环境中已有 Playwright 与可用浏览器，或 `@napi-rs/canvas`。二者都不可用时返回阻塞，不会用绘图替代模型渲染。已有系统 Chromium 时，可设置 `GPT2GIA_CHROMIUM_EXECUTABLE` 为其可执行文件路径，避免依赖 Playwright 自带的浏览器目录。

## 7. 旧模型工程

旧工程没有 Prompt 状态时，新脚本会拒绝直接继续。不要伪填 approved。先备份旧工程，把实际要继续的任务整理成十四章 Prompt，并从原工程明确允许基元与预算要求，生成技术契约。

在独立的 `review_staging` 目录中通过 `prepare` 生成规划文件，展示后等待真实用户确认，再记录确认。把由该流程生成的 `prompt.md`、`prompt_contract.json`、`prompt_state.json`、`prompt_log.jsonl` 四个文件复制到已备份的旧工程，随后运行 `sync-manifest`；补入新版 Schema 和预览资源，重新生成预览及截图。不要手写批准状态。

旧工程若含 Z-up 几何，必须同时迁移位置、尺寸、旋转矩阵、场景边界、地标、比例轴与接口，不能只改 manifest 标签。**新版不会自动迁移用户的旧模型，也不会重新确认旧工程。** 内置两个示例的换基是本次独立修正，不代表任意用户工程已完成迁移。


## 8. 浏览器截图加载方式

Playwright 后端直接把内置 `index.html`、`styles.css`、最新 `scene_data.js` 和同一个 `viewer.js` 装入内存页面，再选择实际检查视角并截图；日志标记 `transport: inline_assets`。它不启动本地 HTTP 服务，也不依赖 `file://` 导航。网页文件本身仍完整交付，供用户正常打开或托管。此方式没有使用另一套绘图代码或生成图。

## 8. v2.4.0 基元复用声明

新建/修订且允许 `10009010` 或 `10009011` 的任务，使用本版 `assets/templates/prompt_contract.json` 中的 `wireframe_policy`，并将 `references/primitive-recipes.prompt.md` 的适用规则融入 Prompt 第二章。规则存在性检查不能代替语义判断或用户确认。

旧契约的可选字段缺省只用于读取旧的已确认工程；本版 prepare/revise 不允许新建含线框但漏写该策略的任务。迁移时复制新契约并保留原来的基元限制、表示模式和数量预算，修订 Prompt，执行 revise，展示变化并等待真实用户确认。不能为了通过检查而直接改已确认文件或伪造新批准。

不含线框的子集任务不强求线框策略文本，也不能为节省数量突破已确认的类型限制。
