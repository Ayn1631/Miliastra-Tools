# 验证与修正

## 目录

1. 自动检查
2. 人工检查
3. 错误码
4. 通过条件

## 1. 自动检查

验证器检查：

- 文件结构、字段、ID、颜色、数值和变换契约。
- 场景原点、包围盒、尺度参照、相机、锚点、区域和深度层契约。
- 所有组是否被分配到且只分配到一个主深度层，组中心是否位于声明的视线距离范围。
- 环境/多物件场景是否具有足够的远近层级。
- 重复集合的原型、实例成员、拓扑策略和引用完整性。
- 表面内容审核状态、宿主组、显著度、策略和目标组件引用。
- 组件使用的基元是否在全局及所属组允许范围内。
- `primitive_priority` 是否是允许基元的完整、无重复有序排列。
- 重复组件、可直接合并的轴对齐长方体。
- 连续组的近似包围盒连接图。
- 微型组件占比、重复尺度、规则步长排列和尺度带数量。
- 每组基元预算。
- 多视图的视图登记、共享地标、轮廓约束、融合方法与冲突处理。
- 逐视图遮挡图是否有反向矛盾、循环和无依据隐藏结构。
- 真实比例证据、实际组包围盒尺寸和轴向比例残差。
- 对象/机械拆解树、组唯一归属、接口与运动轴。
- 低模总组件、调色板、主结构/细节占比、组预算与深度层 LOD。

自动空间检查基于旋转后 AABB，只用于发现高概率问题，不能替代截图检查。

## 2. 人工检查

打开真实截图逐项判断：

- `REPRESENTATION_MISMATCH`：局部形状是否选错基元。
- `INTENT_COVERAGE_FAILURE`：几何角色、闭合/开放与覆盖关系是否满足。
- `SILHOUETTE_MISMATCH`：正、侧、背、俯视和透视的轮廓、比例与参考是否一致。
- `SCENE_COORDINATE_MISMATCH`：场景边界、锚点、区域、地面和组件世界坐标是否一致。
- `DEPTH_HIERARCHY_COLLAPSE`：前中远景是否具有不同职责、遮挡、投影占比和细节密度。
- `REPETITION_CONTRACT_ERROR`：重复物件是否保持不变量，只在声明范围内变化。
- `SURFACE_CONTENT_MISMATCH`：文字、符号、图案和贴图参考是否按显著度与可读性正确处理。
- `PRIMITIVE_PRIORITY_VIOLATION`：实际基元选择是否遵循优先级，越级是否有明显几何收益和记录。
- `MULTIVIEW_FUSION_INCOMPLETE`：多图是否真正共享地标、轮廓约束与冲突处理。
- `OCCLUSION_INFERENCE_CONFLICT`：遮挡图是否合理，隐藏几何是否有其他视图、对称、延续、机械模板或保守未知依据。
- `REAL_SCALE_UNSUPPORTED`：绝对尺度是否有真实标尺，实际尺寸/比例是否在容差内。
- `DECOMPOSITION_CONTRACT_ERROR`：对象层级与机械功能、接口、运动轴是否符合证据。
- `LOW_POLY_STYLE_VIOLATION`：轮廓、大平面、颜色、组件、细节与 LOD 是否满足低模契约。
- `OUTPUT_SUBSTITUTION`：截图是否由当前档案的内置预览代码真实渲染，而非生成图片。检查 `build_log.jsonl` 中的 `playwright_browser` 或 `viewer_canvas` 后端记录。

在 `validation.json` 的 `manual_reviews` 中填写 `passed` 或 `failed`，并提供具体证据。不要只写“看起来没问题”。

## 3. 错误码

| 错误码 | 优先修正方式 |
|---|---|
| `OVER_FRAGMENTATION` | 合并低价值小组件，改用更贴合的基元 |
| `GRID_FRAGMENTATION` | 取消固定步长采样，重建主轮廓 |
| `SCALE_HIERARCHY_COLLAPSE` | 补回主结构和中型连接，减少同尺度碎片 |
| `DISCONNECTED_ASSEMBLY` | 调整位置/尺寸或添加有语义的连接件 |
| `REDUNDANT_PRIMITIVES` | 删除重复件或无损合并 |
| `TRANSFORM_CONTRACT_ERROR` | 修正几何中心、尺度、旋转顺序或非有限数值 |
| `SCENE_PLAN_INCOMPLETE` | 补齐世界坐标、尺度、相机、锚点、区域及审核状态 |
| `SCENE_COORDINATE_MISMATCH` | 统一组件边界、锚点、区域与声明坐标 |
| `DEPTH_HIERARCHY_COLLAPSE` | 重排距离、职责、遮挡和细节等级 |
| `REPETITION_CONTRACT_ERROR` | 补齐原型、实例、排列、变化范围和不变量 |
| `SURFACE_CONTENT_MISMATCH` | 按显著度重选几何化、简化、色块或省略策略 |
| `PRIMITIVE_PRIORITY_VIOLATION` | 修正优先级排列或为必要越级提供证据 |
| `MULTIVIEW_FUSION_INCOMPLETE` | 补齐共享地标、轮廓约束、融合结果和冲突决策 |
| `OCCLUSION_INFERENCE_CONFLICT` | 拆细遮挡组、消除循环，并为隐藏结构补充可信来源 |
| `REAL_SCALE_UNSUPPORTED` | 补充真实标尺/误差，或降级为 `relative_only` |
| `DECOMPOSITION_CONTRACT_ERROR` | 按功能与运动边界重建层级、唯一组归属和接口 |
| `LOW_POLY_STYLE_VIOLATION` | 收紧组件/颜色/细节/LOD 预算并重建大轮廓 |
| `ARTIFACT_INCOMPLETE` | 补齐档案、网页、真实截图和报告 |

## 4. 通过条件

- 自动错误为 0。
- 所有人工检查为 `passed`。
- 每个组有阶段截图，最终五视图与联系表存在且为有效 PNG。
- `self_check.md` 最终状态为 `PASSED`。
- 严格验证、产物核验和打包命令全部成功。


## Prompt 前置验收

初始化、数据构建和模型打包要求当前 Prompt 已确认。模型校验与产物核验会报告缺失、未确认、被修改或不一致的 Prompt 契约；截图入口先调用受检查的预览构建脚本。十四章检查只检查架构与正文存在，完整性、用户意图和确认真实性仍需对照实际会话人工审核。

新修订不得沿用旧的人工验收状态；`revise` 会使 `validation.json` 回到 PENDING。截图日志中的 Prompt 和契约哈希必须与当前版本一致。

## 线框与复用验收

新建/修订允许线框的 Prompt 会检查第二章是否明确适用类型、压扁成环/矩形框、线厚不随缩放改变和预览未标定。对应错误码为 `PROMPT_WIREFRAME_POLICY_REQUIRED`、`PROMPT_WIREFRAME_TECHNIQUE_MISSING`。结构契约不允许把 thickness_scales_with_object 改成 true 或凭空填写实际厚度。

人工检查增加：环框类型是否合适；未采用原生单基元是否有实际理由；是否把线框当实体或将压扁量当线厚；侧面/斜视是否有双层轮廓；输出是否仍保留原生 template_id 和一个组件。审核证据可写入既有 `PRIMITIVE_PRIORITY_VIOLATION`、`REPRESENTATION_MISMATCH` 检查项，不把“看起来闭合”当作实体碰撞通过。

自动检查只检规则存在性与结构化契约，不能判断每个分段环是否值得替换。固定像素描边不证明游戏线厚或实际投影准确；AABB 不含未标定线厚。
