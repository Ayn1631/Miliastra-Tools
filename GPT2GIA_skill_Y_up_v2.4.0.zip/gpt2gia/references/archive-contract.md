# 元件档案契约

## 目录

1. components.json
2. assembly.json
3. scene_plan.json
4. reference_analysis.json
5. decomposition.json
6. style_profile.json
7. manifest.json
8. 验证与日志
9. Prompt 与用户确认

## 1. components.json

```json
{
  "schema_version": "2.2.0",
  "components": [{
    "id": "body_core_001",
    "group_id": "body",
    "template_id": 10009002,
    "position": [0.0, 0.0, 1.2],
    "rotation": [0.0, 0.0, 0.0],
    "scale": [1.4, 0.9, 0.7],
    "color": "#D8B58A",
    "parent_id": null,
    "tags": ["primary"],
    "evidence_ids": ["body_front", "body_side"]
  }]
}
```

`id` 唯一；`group_id` 必须存在于 `assembly.json`；`parent_id` 仅表达语义父级，不改变组件的世界空间变换。`evidence_ids` 可选，用于追溯 `reference_analysis.json` 中实际决定该组件的融合地标。

## 2. assembly.json

```json
{
  "schema_version": "2.2.0",
  "groups": [{
    "group_id": "body",
    "label": "主体",
    "geometry_role": "volume",
    "closure": "closed",
    "continuity": "continuous",
    "attachment": "connected",
    "allowed_template_ids": [10009001, 10009002],
    "primitive_priority": [10009002, 10009001],
    "primitive_priority_notes": "球体优先表达主体体量，长方体仅用于方形连接。",
    "primitive_budget": {"min": 1, "max": 20}
  }],
  "relationships": []
}
```

关系类型：`covers`、`attaches_to`、`connects`、`supports`、`mirrors`。关系两端使用组 ID。

`primitive_priority` 必须与 `allowed_template_ids` 包含完全相同的 ID，顺序表示从默认首选到最后备选。

## 3. scene_plan.json

必须记录：

- `scene_scope`、世界原点、地面高度、场景边界和尺度参照。
- 主相机位置、目标、视场角和深度层。
- 命名锚点、空间区域及其负责的组。
- 重复物件是否存在；若存在，记录原型实例、全部实例成员、排列、间距、变化与不变量。
- 文字、符号、图案或贴图参考是否存在；若存在，记录显著度、阅读目标、处理策略、预算与实际组件。

组件使用世界空间变换。`scene_plan.json` 只负责规划、归属和验证，不对组件施加隐式父变换。

## 4. reference_analysis.json

必须记录：

- 输入模式与每张视图的来源标签、方向、投影、可靠度和主体范围。
- 跨视图地标观测、融合方法、三维约束点与置信度。
- 每个主要视图的轮廓约束，以及冲突视图的解决依据。
- 逐视图有向遮挡关系和大面积隐藏结构的推断依据/处理动作。
- 尺度状态：`absolute_recovered`、`absolute_estimated` 或 `relative_only`。
- 每个尺度目标的组、恢复包围盒尺寸、标尺来源、误差和轴向比例约束。

## 5. decomposition.json

必须记录：

- `generic` 或 `mechanical_equipment` profile。
- 适用拆解模板与 `system → module → subassembly → part → detail` 层级。
- 每个装配组唯一归属的拆解节点。
- 机械角色、可见性、运动、可拆卸性和拆分证据。
- 节点间固定、旋转、滑动、嵌套、流体、电气或柔性接口。

## 6. style_profile.json

必须记录：

- 低模/Blockbench-YSM/风格化基元等风格模式。
- 轮廓、大平面、曲面、对称与细节策略。
- 平涂调色板和颜色上限。
- 全局组件、主结构、细节、轮廓误差和最小投影特征预算。
- 与场景深度层一一对应的 LOD，以及每个组的组件/颜色覆盖预算。
- 必须禁止的均匀小格、像素噪点和无理由细分等模式。

## 7. manifest.json

必须记录：

- 项目名、版本、单位和坐标系。
- `origin: geometric_center`。
- 旋转单位与顺序、变换顺序。
- 全局允许基元、表达模式与用户约束。
- 参考视图、假设、预期截图规格和必需视角。

## 8. 验证与日志

- `validation.json` 保存自动检查和人工检查；程序重新运行时保留同错误码的人工状态与证据。
- `fragmentation.json` 保存每组微型组件比例、尺度带、规则网格迹象和连接分量。
- `build_log.jsonl` 每行一个 JSON 事件，记录创建、验证、截图与修正。
- `self_check.md` 记录逐轮问题和最终状态。
- `summary.md` 记录视图融合、遮挡、比例恢复、对象拆解、低模预算、场景坐标、远近层级、重复集合、表面内容、基元统计、颜色、截图索引和剩余问题。


## 9. Prompt 与用户确认

- `prompt.md`：实际提交给用户的完整十四章任务 Prompt，不是模板占位文件。
- `prompt_contract.json`：已提交审核的技术契约，包含 Y-up 坐标、基元集合、表达模式、连续浮点规则和可选数量上限。
- `prompt_state.json`：修订号、状态、两个文件的 SHA-256 和真实用户确认的引用记录。
- `prompt_log.jsonl`：Prompt 草拟、确认、修订与同步事件。
- `manifest.prompt_workflow`：当前模型采用的 Prompt 与技术契约哈希。

上述文件均为必需产物。截图日志也记录当前 Prompt 和技术契约哈希，旧版本截图不能满足新版本的验收要求。更改内容后必须重新确认、同步清单并重建预览与截图；章节和哈希检查不等于自动审查文本语义或认证用户身份。流程见 `prompt-workflow.md`。

## 线框复用（v2.4.0）

组件 Schema 保持 2.2.0，不添加可调线厚字段。`10009010` 与 `10009011` 保留为单个原生组件，其内部边数不计为额外组件。线框 scale 描述路径整体尺度，不调整固有线厚。

Prompt 契约 1.0.0 通过可选 `wireframe_policy` 作向后兼容扩展。本版允许线框的新建/修订任务必须携带该字段；旧已确认档案不会被静默升级。模板保持原文；新的技巧片段只用于生成的新 Prompt。
