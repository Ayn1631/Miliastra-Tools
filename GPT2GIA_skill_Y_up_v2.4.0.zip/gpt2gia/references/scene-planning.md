# 场景、重复物件与表面内容规划

## 目录

1. 场景坐标
2. 相机与远近层级
3. 重复物件
4. 文字、符号与贴图参考
5. 基元优先级

## 1. 场景坐标

先建立场景，后建立物件。`scene_plan.json` 是空间布局的权威规划，组件仍保存世界空间变换。

必须声明：

- `scene_scope`：`single_object`、`multi_object` 或 `environment`。
- `world_origin`：稳定的语义原点，例如主体落地点、建筑中心或道路交点。
- `ground_y`：有地面时记录高度；无地面对象可为 `null`。
- `scene_bounds`：预计容纳全部可见组件的世界空间边界。
- `scale_reference`：已知尺寸、人物身高、用户单位或从参考图推断的尺度依据。
- `anchors`：主体中心、道路节点、建筑入口、重复阵列起点等可复用定位点。
- `zones`：按功能或空间分区的世界空间范围。

不要把相机目标当作世界原点。不要通过连续“向右再加 2 米”的临场累加规划整个场景。每个组至少属于一个深度层；环境场景中的主要组还应属于一个区域或锚点。

`scene_bounds` 必须包住所有组件的旋转后边界；边界用于验证，不用于强制裁切。

`scale_reference` 只描述场景坐标依据，必须与 `reference_analysis.json.scale_recovery` 一致。绝对尺度的标尺、误差和实际包围盒残差记录在 `reference_analysis.json`；没有可靠标尺时必须使用 `relative_only`。

## 2. 相机与远近层级

深度使用主相机视线上的有符号距离，不使用组件尺寸或到原点的距离：

```text
view_depth = dot(group_center - camera_position, normalize(camera_target - camera_position))
```

每个深度层声明：

- `layer_id` 与唯一 `order`。
- `distance_range`：沿主视线的近、远距离。
- `group_ids`：该层主要负责的组；同一组只归入一个主层。
- `purpose`：`framing`、`primary_subject`、`context`、`horizon` 或 `transition`。
- `detail_level`：`high`、`medium`、`low` 或 `silhouette_only`。
- `target_screen_fraction`：期望投影占画面的比例区间，供截图人工检查。
- `occlusion_policy`：该层允许或禁止遮挡哪些主体。

`environment` 至少需要三个有内容的层，分别承担近、中、远职责；不强制使用固定英文名，但 `order` 和距离必须单调递增。`multi_object` 至少需要两个层。`single_object` 至少需要一个 `subject` 层。

远近层级不只是缩放：

- 前景负责框景、引导、局部遮挡和高对比细节。
- 中景承载主叙事对象与最高辨识度。
- 远景负责天际线、尺度感、色块和低频轮廓，不堆高密度微型组件。
- 相邻层通过道路、地形、柱列、光带或尺度渐变形成过渡，避免三排互不相关的物件。

## 3. 重复物件

若没有重复对象，设置 `repeat_policy.status: not_present`；若存在，设置为 `planned` 并建立 `sets`。

每个重复集合包含：

- `repeat_id`、`prototype_instance_id`。
- 两个或更多 `instances`；每个实例列出实际 `member_component_ids`。
- `placement_mode`：`linear`、`grid`、`radial`、`path`、`scatter` 或 `explicit`。
- `topology_policy`：`shared` 表示各实例保持与原型相同的基元类型计数；`variant` 允许声明式结构变化。
- `spacing`：最小间距和节奏说明。
- `variation`：稳定随机种子、允许的位置/旋转/缩放/颜色变化范围。
- `invariants`：轮廓、朝向、功能接口、配色标志等不可变化特征。

所有实例都必须展开为普通世界空间组件，保证预览器和下游工具无需隐式实例化。重复规则用于追踪来源、控制变化和验证，不替代 `components.json`。

不要让自然物件完全复制粘贴；也不要为了“自然”而无限随机。变化只能发生在声明范围内，并保持原型的关键辨识特征。

## 4. 文字、符号与贴图参考

纯基元档案没有位图纹理或 UV。先审核表面内容，再选择策略：

| 内容与可见性 | 首选策略 |
|---|---|
| 近景、必须逐字可读的文字 | `primitive_geometry`：用平面、薄长方体等构成少量笔画 |
| 高辨识图标、徽记、方向符号 | `simplified_symbol`：保留外轮廓和语义 |
| 中景图案、材质大色块 | `color_block_geometry`：拆成低频色区 |
| 远景贴图或不可读文字 | `dominant_color_plane`：只保留主色与明暗分区 |
| 对任何必需视图都无贡献 | `omit`：必须写明省略理由 |

禁止：

- 把整张参考图、人物截图或场景照片放在平面上冒充三维结构。
- 把原文替换成模型臆造的其他文字。
- 把低分辨率噪点逐像素转成小基元。
- 在用户要求精确位图时声称纯基元档案可以无损保存。

每项记录 `content_type`、宿主组、原始语义、显著度、阅读目标、策略、组件预算与目标组件 ID。高显著度内容不可使用 `omit`。

## 5. 基元优先级

优先级是每个组的上下文规则，不存在对所有对象通用的一张固定总表。

先执行硬筛选：

1. 是否满足实体/开放面/框架意图。
2. 是否具有所需厚度、截面、收束或主轴。
3. 是否会破坏连接、覆盖或可行的变换。
4. 是否属于用户和组允许的基元范围。

再按 `primitive_priority` 从前到后选择第一个足够表达局部形状的候选。排序时依次重视：

1. 轮廓和拓扑匹配。
2. 连续性与连接可靠性。
3. 使用一个合适基元替代密集采样的能力。
4. 对重复实例和后续编辑的稳定性。
5. 组件预算。

低优先级不是禁止项。只有当它相对更高优先级明显改善轮廓、连接、厚度或几何意图时才使用，并在组的 `primitive_priority_notes` 中记录适用特征或越级原因。
