# GPT2GIA v2.4.0 使用说明

## 替换旧版

保留旧包备份，使用本包的 `gpt2gia` 目录整体替换旧目录，避免新脚本与旧模板混用。让执行宿主重新读取 `SKILL.md` 和 `agents/openai.yaml`。本包只修改文件，不会远程替你安装或保证宿主自动加载。

## 正常的首次行为

执行者先完整读取新模板，按当前任务生成十四章 `prompt.md`，同时给出 `prompt_contract.json`，交用户审核。本轮结束时状态为 `awaiting_user_confirmation`，没有 `components.json`、三维预览或模型截图。

用户明确同意当前版本后，执行者记录真实回复与消息引用，再初始化和建模。用户要求改动时重新提交审核，旧确认不能继续使用。完整命令见 `references/prompt-workflow.md`。

## 基元与数值

默认可使用目录中的全部 11 种基元。用户明确要求单一长方体时，契约限制为 `[10009001]` 和 `cuboid_only`。优化基元数量优先考虑可合并的大块、直接适配的球/柱/锥等，不牺牲关键轮廓或接口。

统一 Y-up：X 左右、Y 高度、Z 进深。位置、旋转和缩放保持连续浮点，不固定四位小数，不做默认 0.01 量化。内置预览轴向不构成外部 GIA 编码标定。

## 自测

在 Skill 根目录执行：

```bash
python -m unittest discover -s tests -v
```

Python 3.10 或更新版本即可运行核心代码。测试中的 JavaScript 几何对照和截图入口拦截需要 Node.js；没有 Node.js 时这两项会明确跳过。真实截图还需要 Playwright 与浏览器，或原有 Canvas 后端，详情见流程文档。

测试生成的确认记录只存在于临时测试目录，不能用作任何用户任务的确认依据。

## 限制

这套机制防止经过内置入口的流程跳步，不认证本地文件中用户回复的身份，也不能阻止外部程序直接改文件。宿主必须对照真实会话，不得自批。

当前静态纯色基元格式不提供真实透明、泛光、体积光或动画；这些能力限制已写入模板使用规则，原模板目标未被删除。预览继续沿用 Canvas 面排序，复杂遮挡和精确碰撞仍需人工判断。

旧模型工程不会自动迁移。尤其是含旧 Z-up 数据的工程，不能只修改 manifest 的坐标标签。迁移流程见 `references/prompt-workflow.md` 第 7 节。

## 新增：单基元成环、成框

完整细圆环优先 `10009011` 局部 Y 压扁；完整同色细矩形框优先 `10009010` 沿一轴压扁。两者都只计 1 个组件。**线厚不随缩放改变**；粗厚、缺边或不同边颜色/厚度时按实际形状选择实体方案。

必读 `references/primitive-recipes.md`，生成 Prompt 时把 `references/primitive-recipes.prompt.md` 的适用内容编入第二章。`assets/recipes/wireframe_examples.json` 提供六组独立数值示例，不是可直接声称验收通过的完整工程。

本版新建/修订且允许线框的任务必须带有默认 `wireframe_policy` 并明确上述规则，漏写会被 prepare/revise 阻止。已有 v2.3.0 已确认工程保留旧契约，不自动补签；应用新规则须使用新的默认契约文件，保留原任务类型/预算后 revise、重新确认，再 sync-manifest。旧预览器不会自动替换，更新已有工程资源须留备份并重做截图验收。

固定像素描边仅是示意，尚未测得游戏真实线厚，不声称已模拟真实截面/碰撞。原十四章用户模板保持逐字节不变。

## 可选浏览器验证

本次六组技巧输入使用 Python Playwright 和系统 Chromium 实际渲染，记录保存在 `tests/render_checks/wireframe_recipes/`。可在安装了相应依赖的环境重跑：

```bash
python tests/render_recipe_checks.py --chromium <浏览器可执行文件路径>
```

省略 `--chromium` 时使用环境变量、系统 Chromium 或 Playwright 默认浏览器。此脚本只做隔离技巧验证，不写用户项目确认记录，也不代表游戏内实测。
