(() => {
  "use strict";

  const scene = window.GPT2GIA_SCENE || {};
  const components = scene.components?.components || [];
  const manifest = scene.manifest || {};
  const canvas = document.getElementById("viewport");
  const context = canvas.getContext("2d", { alpha: false });
  const query = new URLSearchParams(location.search);
  const state = {
    view: query.get("view") || "perspective",
    debug: query.get("debug") === "1",
    yaw: -0.78,
    pitch: 0.48,
    zoom: 1,
    usePlannedCamera: true,
    dragging: false,
    lastX: 0,
    lastY: 0,
  };

  // 线框只缩放路径，不缩放描边。2.2 是屏幕像素代理，不是游戏中的米制线厚。
  const WIREFRAME_PREVIEW = Object.freeze({
    mode: "uncalibrated_screen_space_stroke",
    strokeWidthPx: 2.2,
    thicknessScalesWithObject: false,
    physicalThickness: null,
  });
  window.GPT2GIA_PREVIEW_INFO = Object.freeze({ wireframe: WIREFRAME_PREVIEW });

  function wireStrokeWidthPx() {
    // 不接收 component.scale，避免把整体缩放或压扁量误作调线厚。
    return WIREFRAME_PREVIEW.strokeWidthPx;
  }

  const primitiveNames = new Map(
    (scene.catalog?.primitives || []).map((item) => [item.template_id, item.name_zh])
  );
  const clamp = (value, low, high) => Math.max(low, Math.min(high, value));
  const add = (a, b) => a.map((value, index) => value + b[index]);
  const sub = (a, b) => a.map((value, index) => value - b[index]);
  const mul = (a, scalar) => a.map((value) => value * scalar);
  const dot = (a, b) => a.reduce((sum, value, index) => sum + value * b[index], 0);
  const cross = (a, b) => [
    a[1] * b[2] - a[2] * b[1],
    a[2] * b[0] - a[0] * b[2],
    a[0] * b[1] - a[1] * b[0],
  ];
  const normalize = (value) => {
    const length = Math.sqrt(dot(value, value)) || 1;
    return mul(value, 1 / length);
  };

  function boxGeometry(wire = false) {
    const vertices = [
      [-0.5, -0.5, -0.5], [0.5, -0.5, -0.5], [0.5, 0.5, -0.5], [-0.5, 0.5, -0.5],
      [-0.5, -0.5, 0.5], [0.5, -0.5, 0.5], [0.5, 0.5, 0.5], [-0.5, 0.5, 0.5],
    ];
    const faces = wire ? [] : [
      [0, 3, 2, 1], [4, 5, 6, 7], [0, 1, 5, 4],
      [1, 2, 6, 5], [2, 3, 7, 6], [3, 0, 4, 7],
    ];
    const edges = [
      [0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6],
      [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7],
    ];
    return { vertices, faces, edges, wire };
  }

  function prismGeometry(sides, wire = false) {
    const vertices = [];
    for (const y of [-0.5, 0.5]) {
      for (let index = 0; index < sides; index += 1) {
        const angle = Math.PI / 2 + (index * Math.PI * 2) / sides;
        vertices.push([Math.cos(angle) * 0.5, y, Math.sin(angle) * 0.5]);
      }
    }
    const faces = [];
    if (!wire) {
      faces.push([...Array(sides).keys()].reverse());
      faces.push([...Array(sides).keys()].map((index) => index + sides));
      for (let index = 0; index < sides; index += 1) {
        const next = (index + 1) % sides;
        faces.push([index, next, next + sides, index + sides]);
      }
    }
    const edges = [];
    for (let index = 0; index < sides; index += 1) {
      const next = (index + 1) % sides;
      edges.push([index, next], [index + sides, next + sides], [index, index + sides]);
    }
    return { vertices, faces, edges, wire };
  }

  function pyramidGeometry(sides) {
    const vertices = [];
    for (let index = 0; index < sides; index += 1) {
      const angle = Math.PI / 2 + (index * Math.PI * 2) / sides;
      vertices.push([Math.cos(angle) * 0.5, -0.25, Math.sin(angle) * 0.5]);
    }
    vertices.push([0, 0.75, 0]);
    const apex = sides;
    const faces = [[...Array(sides).keys()].reverse()];
    const edges = [];
    for (let index = 0; index < sides; index += 1) {
      const next = (index + 1) % sides;
      faces.push([index, next, apex]);
      edges.push([index, next], [index, apex]);
    }
    return { vertices, faces, edges, wire: false };
  }

  function sphereGeometry() {
    const columns = 20;
    const rows = 10;
    const vertices = [];
    for (let row = 0; row <= rows; row += 1) {
      const phi = (row / rows) * Math.PI;
      for (let column = 0; column < columns; column += 1) {
        const theta = (column / columns) * Math.PI * 2;
        vertices.push([
          Math.sin(phi) * Math.cos(theta) * 0.5,
          Math.cos(phi) * 0.5,
          Math.sin(phi) * Math.sin(theta) * 0.5,
        ]);
      }
    }
    const faces = [];
    const edges = [];
    for (let row = 0; row < rows; row += 1) {
      for (let column = 0; column < columns; column += 1) {
        const next = (column + 1) % columns;
        const a = row * columns + column;
        const b = row * columns + next;
        const c = (row + 1) * columns + next;
        const d = (row + 1) * columns + column;
        faces.push([a, b, c, d]);
        edges.push([a, b], [a, d]);
      }
    }
    return { vertices, faces, edges, wire: false };
  }

  function planeGeometry() {
    return {
      vertices: [[-0.5, 0, -0.5], [0.5, 0, -0.5], [0.5, 0, 0.5], [-0.5, 0, 0.5]],
      faces: [[0, 1, 2, 3]],
      edges: [[0, 1], [1, 2], [2, 3], [3, 0]],
      wire: false,
    };
  }

  function geometryFor(templateId) {
    switch (templateId) {
      case 10009001: return boxGeometry(false);
      case 10009002: return sphereGeometry();
      case 10009003: return planeGeometry();
      case 10009004: return prismGeometry(3);
      case 10009005: return prismGeometry(5);
      case 10009006: return pyramidGeometry(3);
      case 10009007: return pyramidGeometry(5);
      case 10009008: return prismGeometry(24);
      case 10009009: return pyramidGeometry(24);
      case 10009010: return boxGeometry(true);
      case 10009011: return prismGeometry(24, true);
      default: return boxGeometry(false);
    }
  }

  function rotateXYZ(point, rotation) {
    let [x, y, z] = point;
    const [rx, ry, rz] = rotation.map((value) => (value * Math.PI) / 180);
    let nextY = y * Math.cos(rx) - z * Math.sin(rx);
    let nextZ = y * Math.sin(rx) + z * Math.cos(rx);
    y = nextY; z = nextZ;
    let nextX = x * Math.cos(ry) + z * Math.sin(ry);
    nextZ = -x * Math.sin(ry) + z * Math.cos(ry);
    x = nextX; z = nextZ;
    nextX = x * Math.cos(rz) - y * Math.sin(rz);
    nextY = x * Math.sin(rz) + y * Math.cos(rz);
    return [nextX, nextY, z];
  }

  function transformVertex(vertex, component) {
    const scaled = vertex.map((value, axis) => value * component.scale[axis]);
    return add(rotateXYZ(scaled, component.rotation), component.position);
  }

  const meshes = components.map((component) => {
    const geometry = geometryFor(component.template_id);
    return {
      component,
      ...geometry,
      world: geometry.vertices.map((vertex) => transformVertex(vertex, component)),
    };
  });

  function sceneBounds() {
    const points = meshes.flatMap((mesh) => mesh.world);
    if (!points.length) return { center: [0, 0, 0], radius: 1 };
    const minimum = [Infinity, Infinity, Infinity];
    const maximum = [-Infinity, -Infinity, -Infinity];
    for (const point of points) {
      for (let axis = 0; axis < 3; axis += 1) {
        minimum[axis] = Math.min(minimum[axis], point[axis]);
        maximum[axis] = Math.max(maximum[axis], point[axis]);
      }
    }
    const center = mul(add(minimum, maximum), 0.5);
    let radius = 0.5;
    for (const point of points) {
      const delta = sub(point, center);
      radius = Math.max(radius, Math.sqrt(dot(delta, delta)));
    }
    return { center, radius };
  }

  const bounds = sceneBounds();
  const plannedCamera = scene.scene_plan?.camera_plan || {};
  const validCameraVector = (value) =>
    Array.isArray(value) && value.length === 3 && value.every(Number.isFinite);

  function cameraForView() {
    const r = bounds.radius / state.zoom;
    const center = bounds.center;
    if (state.view === "front") return { position: add(center, [0, 0, -r * 3.2]), target: center, up: [0, 1, 0] };
    if (state.view === "right") return { position: add(center, [r * 3.2, 0, 0]), target: center, up: [0, 1, 0] };
    if (state.view === "back") return { position: add(center, [0, 0, r * 3.2]), target: center, up: [0, 1, 0] };
    if (state.view === "top_or_isometric") return { position: add(center, [r * 0.9, r * 2.8, -r * 1.15]), target: center, up: [0, 1, 0] };
    if (
      state.usePlannedCamera &&
      validCameraVector(plannedCamera.position) &&
      validCameraVector(plannedCamera.target)
    ) {
      const target = [...plannedCamera.target];
      const offset = mul(sub(plannedCamera.position, target), 1 / state.zoom);
      return { position: add(target, offset), target, up: [0, 1, 0] };
    }
    const planar = Math.cos(state.pitch) * r * 3.15;
    return {
      position: add(center, [
        Math.cos(state.yaw) * planar,
        Math.sin(state.pitch) * r * 3.15,
        Math.sin(state.yaw) * planar,
      ]),
      target: center,
      up: [0, 1, 0],
    };
  }

  function cameraBasis(camera) {
    const forward = normalize(sub(camera.target, camera.position));
    const right = normalize(cross(forward, camera.up));
    const up = normalize(cross(right, forward));
    return { forward, right, up };
  }

  function project(point, camera, basis) {
    const relative = sub(point, camera.position);
    const depth = dot(relative, basis.forward);
    const fov = clamp(Number(plannedCamera.fov_degrees) || 45, 2, 178);
    const focal = canvas.height / (2 * Math.tan((fov * Math.PI) / 360));
    return {
      x: canvas.width * 0.5 + (dot(relative, basis.right) * focal) / Math.max(depth, 1e-4),
      y: canvas.height * 0.5 - (dot(relative, basis.up) * focal) / Math.max(depth, 1e-4),
      depth,
    };
  }

  function colorShade(hex, factor) {
    const number = Number.parseInt(hex.slice(1), 16);
    const channels = [number >> 16, (number >> 8) & 255, number & 255];
    const adjusted = channels.map((value) => Math.round(clamp(value * factor, 0, 255)));
    return `rgb(${adjusted.join(",")})`;
  }

  function drawGrid(camera, basis) {
    const extent = Math.max(2, Math.ceil(bounds.radius * 1.8));
    const plannedGround = scene.scene_plan?.coordinate_plan?.ground_y;
    if (plannedGround === null) return;
    const groundY = Number.isFinite(plannedGround) ? plannedGround : 0;
    context.save();
    context.lineWidth = 1;
    for (let value = -extent; value <= extent; value += Math.max(0.5, Math.ceil(extent / 12))) {
      for (const line of [
        [[-extent, groundY, value], [extent, groundY, value]],
        [[value, groundY, -extent], [value, groundY, extent]],
      ]) {
        const a = project(line[0], camera, basis);
        const b = project(line[1], camera, basis);
        if (a.depth <= 0 || b.depth <= 0) continue;
        context.strokeStyle = value === 0 ? "rgba(126,166,220,.24)" : "rgba(121,148,184,.09)";
        context.beginPath();
        context.moveTo(a.x, a.y);
        context.lineTo(b.x, b.y);
        context.stroke();
      }
    }
    context.restore();
  }

  function drawScene() {
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    const width = Math.max(1, Math.floor(canvas.clientWidth * ratio));
    const height = Math.max(1, Math.floor(canvas.clientHeight * ratio));
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }
    const gradient = context.createLinearGradient(0, 0, 0, canvas.height);
    gradient.addColorStop(0, "#152238");
    gradient.addColorStop(0.62, "#0d1523");
    gradient.addColorStop(1, "#080d15");
    context.fillStyle = gradient;
    context.fillRect(0, 0, canvas.width, canvas.height);

    const camera = cameraForView();
    const basis = cameraBasis(camera);
    drawGrid(camera, basis);
    const faces = [];
    const lines = [];
    for (const mesh of meshes) {
      const projected = mesh.world.map((point) => project(point, camera, basis));
      for (const face of mesh.faces) {
        const points = face.map((index) => mesh.world[index]);
        const normal = normalize(cross(sub(points[1], points[0]), sub(points[2], points[0])));
        const center = mul(points.reduce((sum, point) => add(sum, point), [0, 0, 0]), 1 / points.length);
        const light = normalize([0.45, 1, -0.7]);
        const shade = 0.58 + 0.42 * Math.abs(dot(normal, light));
        faces.push({
          points: face.map((index) => projected[index]),
          depth: face.reduce((sum, index) => sum + projected[index].depth, 0) / face.length,
          color: colorShade(mesh.component.color, shade),
          id: mesh.component.id,
        });
      }
      if (mesh.wire || state.debug) {
        for (const edge of mesh.edges) {
          lines.push({
            points: edge.map((index) => projected[index]),
            depth: (projected[edge[0]].depth + projected[edge[1]].depth) * 0.5,
            color: mesh.wire ? mesh.component.color : "rgba(9,16,28,.48)",
            width: mesh.wire ? wireStrokeWidthPx() : 0.75,
          });
        }
      }
    }
    faces.sort((a, b) => b.depth - a.depth);
    for (const face of faces) {
      if (face.points.some((point) => point.depth <= 0)) continue;
      context.beginPath();
      context.moveTo(face.points[0].x, face.points[0].y);
      for (const point of face.points.slice(1)) context.lineTo(point.x, point.y);
      context.closePath();
      context.fillStyle = face.color;
      context.fill();
      context.strokeStyle = "rgba(255,255,255,.075)";
      context.lineWidth = 0.55;
      context.stroke();
    }
    lines.sort((a, b) => b.depth - a.depth);
    for (const line of lines) {
      if (line.points.some((point) => point.depth <= 0)) continue;
      context.beginPath();
      context.moveTo(line.points[0].x, line.points[0].y);
      context.lineTo(line.points[1].x, line.points[1].y);
      context.strokeStyle = line.color;
      context.lineWidth = line.width;
      context.stroke();
    }
    window.renderReady = true;
  }

  function setView(view) {
    state.view = view;
    document.querySelectorAll("[data-view]").forEach((button) => {
      button.classList.toggle("active", button.dataset.view === view);
    });
    drawScene();
  }

  document.getElementById("project-name").textContent = manifest.project_name || "GPT2GIA";
  const counts = new Map();
  for (const component of components) {
    const name = primitiveNames.get(component.template_id) || String(component.template_id);
    counts.set(name, (counts.get(name) || 0) + 1);
  }
  const depthLayers = scene.scene_plan?.camera_plan?.depth_layers?.length || 0;
  const repeatSets = scene.scene_plan?.repeat_policy?.sets?.length || 0;
  document.getElementById("scene-stats").textContent =
    `${components.length} 个组件 · ${scene.assembly?.groups?.length || 0} 个组 · ${depthLayers} 个深度层 · ${repeatSets} 个重复集合`;
  const wireNote = components.some((component) => [10009010, 10009011].includes(component.template_id))
    ? "　| 线框为固定像素示意，游戏线厚尚未标定" : "";
  document.getElementById("legend").textContent =
    (counts.size ? [...counts].map(([name, count]) => `${name} × ${count}`).join("　") : "空档案") + wireNote;
  document.querySelectorAll("[data-view]").forEach((button) => {
    button.addEventListener("click", () => {
      if (button.dataset.view === "perspective") state.usePlannedCamera = true;
      setView(button.dataset.view);
    });
  });
  document.getElementById("debug-toggle").addEventListener("click", (event) => {
    state.debug = !state.debug;
    event.currentTarget.classList.toggle("active", state.debug);
    drawScene();
  });
  canvas.addEventListener("pointerdown", (event) => {
    state.dragging = true;
    state.lastX = event.clientX;
    state.lastY = event.clientY;
    canvas.setPointerCapture(event.pointerId);
  });
  canvas.addEventListener("pointermove", (event) => {
    if (!state.dragging) return;
    state.view = "perspective";
    state.usePlannedCamera = false;
    state.yaw += (event.clientX - state.lastX) * 0.008;
    state.pitch = clamp(state.pitch + (event.clientY - state.lastY) * 0.006, -1.35, 1.35);
    state.lastX = event.clientX;
    state.lastY = event.clientY;
    setView("perspective");
  });
  canvas.addEventListener("pointerup", () => { state.dragging = false; });
  canvas.addEventListener("wheel", (event) => {
    event.preventDefault();
    state.zoom = clamp(state.zoom * Math.exp(-event.deltaY * 0.001), 0.45, 4);
    drawScene();
  }, { passive: false });
  window.addEventListener("resize", drawScene);
  window.setGPT2GIAView = setView;
  setView(state.view);
})();
